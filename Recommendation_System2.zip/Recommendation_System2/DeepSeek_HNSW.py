# -*- coding: utf-8 -*-
import os
import json
import logging
import pickle
import sqlite3
import gc
import time
import psutil
import numpy as np
import pandas as pd
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.translate.meteor_score import meteor_score
from rouge_score import rouge_scorer
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from sklearn.metrics import mean_squared_error
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
import detoxify
import hnswlib
from tqdm import tqdm
from fuzzywuzzy import fuzz
from typing import Dict, List, Tuple, Any

# Setup directories and logging
BASE_DIR = "/home/f223085/iqra/pkkaDeepSeek/last"
RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(BASE_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

nltk.download('punkt', quiet=True)
nltk.download('wordnet', quiet=True)
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")
file_handler = logging.FileHandler(os.path.join(BASE_DIR, "recommender_resume_fixed.log"))
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Configuration class
class Config:
    DATA_PATH = "/home/f223085/iqra/pd.csv"
    MODEL_NAME = "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B"
    MODEL_DIR = os.path.join(BASE_DIR, "fine_tuned_model")
    EMBEDDINGS_PATH = os.path.join(BASE_DIR, "case_embeddings.npy")
    DISEASE_EMBEDDINGS_PATH = os.path.join(BASE_DIR, "disease_embeddings.npy")
    INDEX_MAPPING_PATH = os.path.join(BASE_DIR, "index_mapping.pkl")
    TOKENIZED_DATA_PATH = os.path.join(BASE_DIR, "tokenized_dataset.pkl")
    DB_PATH = os.path.join(BASE_DIR, "user_profiles.db")
    TRAIN_EVAL_PATH = os.path.join(BASE_DIR, "train_eval_results.json")
    PLOTS_DIR = os.path.join(BASE_DIR, "plots")
    CASE_HNSW_PATH = os.path.join(RESULTS_DIR, "case_hnsw_index.bin")
    DISEASE_HNSW_PATH = os.path.join(RESULTS_DIR, "disease_hnsw_index.bin")
    MAX_LENGTH = 128
    TOP_K = 3
    EXPLORATORY_K = 10
    BATCH_SIZE = 4
    SIMILARITY_THRESHOLD = 0.5
    SAMPLE_FRAC = 1.0
    TOXICITY_MODEL = None
    EMBEDDING_DIM = None
    HNSW_M = 16  # HNSW parameter: number of bi-directional links
    HNSW_EF_CONSTRUCTION = 200  # HNSW parameter: size of dynamic list for construction
    HNSW_EF_SEARCH = 100  # HNSW parameter: size of dynamic list for search
    CONDITION_INTRO = "You may have {} (confidence: {:.2f})."
    DOCTOR_RECOMMENDATION = "Dr. {}, a {} in {}, rated {} stars. Chosen for expertise in {}."
    EXPLORATORY_INTRO = "Other doctors you might consider in {}:"
    GENERAL_ADVICE = "Rest and medication may help, but consult a doctor for proper diagnosis."
    GREETING = "Hello {}, we're here to help with your health needs in {}."
    ANALYZING = "Analyzing your input to find the best care options in {}..."
    FALLBACK_MESSAGE = "We couldn't find {} in {} with our strict criteria, but here are top-rated doctors nearby."
    disease_specialist_dict = {
        "heart attack": "cardiologist",
        "diabetes": "general physician",
        "eczema": "general physician",
        "appendicitis": "general physician",
        "asthma": "general physician",
        "pneumonia": "general physician",
        "influenza": "infectious disease specialist",
        "strep throat": "infectious disease specialist",
        "alzheimer": "neurologist",
        "stroke": "general physician",
        "tuberculosis": "general physician",
        "unknown": "general physician"
    }
    DISEASE_ADVICE = {
        "heart attack": "Seek immediate emergency care. Call an ambulance for chest pain.",
        "diabetes": "Monitor blood sugar and consult a general physician for management.",
        "eczema": "Use moisturizers and avoid irritants. See a general physician for treatment.",
        "general physician": "Schedule a routine check-up for tests and screenings."
    }

    @staticmethod
    def init_toxicity_model():
        try:
            Config.TOXICITY_MODEL = detoxify.Detoxify('original')
            logger.info("Detoxify model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Detoxify model: {e}")
            with open(os.path.join(BASE_DIR, "disease_log.txt"), "a") as f:
                f.write(f"Failed to load Detoxify: {e}\n")

# Initialize environment
def init_environment():
    os.makedirs("/home/f223085/hf", exist_ok=True)
    NLTK_DATA_DIR = "/home/f223085/nltk_data"
    os.makedirs(NLTK_DATA_DIR, exist_ok=True)
    os.environ["http_proxy"] = "http://192.168.150.150:3128"
    os.environ["https_proxy"] = "http://192.168.150.150:3128"
    try:
        nltk.download('wordnet', download_dir=NLTK_DATA_DIR, quiet=True)
        logger.info(f"NLTK data downloaded to {NLTK_DATA_DIR}")
    except Exception as e:
        logger.error(f"Failed to download NLTK data: {e}")
    logger.info("Environment initialized.")

# Initialize database
def init_database():
    try:
        with sqlite3.connect(Config.DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS patients (
                    patient_id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL,
                    gender TEXT,
                    city TEXT,
                    symptoms TEXT,
                    ratings TEXT
                )
            """)
            patients = [
                (1, "Iqra", "Female", "Chiniot", "[]", "{}"),
                (2, "Moafi", "Female", "Lahore", "[]", "{}"),
                (3, "Sumair", "Male", "Karachi", "[]", "{}"),
                (4, "Anwar", "0", "Peshawar", "[]", "{}"),
                (5, "Hassan", "Male", "Unknown", "[]", "{}")
            ]
            cursor.executemany("INSERT OR IGNORE INTO patients VALUES (?, ?, ?, ?, ?, ?)", patients)
            conn.commit()
        logger.info("Database initialized.")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")

# Preprocess data
# Assuming Config, BASE_DIR, and logger are defined in V1.py
def preprocess_data():
    try:
        df = pd.read_csv(Config.DATA_PATH)
        logger.info(f"Imported {len(df)} rows from {Config.DATA_PATH}")
        logger.info(f"Available columns in dataset: {df.columns.tolist()}")
        if df.empty:
            raise ValueError("Empty dataset.")

        # Required columns (only enforce critical ones)
        critical_columns = ["Processed_Symptoms", "Processed_Disease"]
        missing_critical = [col for col in critical_columns if col not in df.columns]
        if missing_critical:
            logger.error(f"Critical columns missing: {missing_critical}")
            raise ValueError(f"Critical columns missing: {missing_critical}")

        # Handle optional columns dynamically
        if "City" in df.columns:
            df["City"] = df["City"].str.lower().fillna("unknown")
        if "Rating" in df.columns:
            df["Rating"] = df["Rating"].astype(str).str.replace(r'[^\d.]', '', regex=True).replace('', np.nan).astype(float)
        if "Processed_Treatment" in df.columns:
            df["Processed_Treatment"] = df["Processed_Treatment"].fillna("Consultation")
        if "Specialist" in df.columns:
            df["Specialist"] = df["Specialist"].apply(lambda x: x if x in Config.disease_specialist_dict.values() else "general physician")
            valid_specialists = list(Config.disease_specialist_dict.values())
            df = df[df["Specialist"].isin(valid_specialists)]
            logger.info(f"After specialist filter: {len(df)} rows.")
            logger.info(f"Validated Specialist column: {df['Specialist'].value_counts().to_dict()}")

        # Drop rows with missing critical columns
        df = df.dropna(subset=critical_columns)
        logger.info(f"After dropna: {len(df)} rows.")

        # Filter valid diseases
        valid_diseases = list(Config.disease_specialist_dict.keys())
        df = df[df["Processed_Disease"].isin(valid_diseases)]
        logger.info(f"After filtering diseases: {len(df)} rows.")

        # Sampling
        if Config.SAMPLE_FRAC < 1.0:
            df = df.sample(frac=Config.SAMPLE_FRAC, random_state=42).reset_index()
            logger.info(f"After sampling (frac={Config.SAMPLE_FRAC}): {len(df)} rows.")
        else:
            df = df.reset_index()
            logger.info(f"No sampling applied: {len(df)} rows.")

        # Log city-specialist counts if columns exist
        if "City" in df.columns and "Specialist" in df.columns:
            for city in df['City'].drop_duplicates():
                for specialist in df['Specialist'].drop_duplicates():
                    count = ((df['City'] == city) & (df['Specialist'] == specialist)).sum()
                    if count > 0:
                        logger.info(f"{city.capitalize()} {specialist}s: {count}")

        # Create index mapping
        index_mapping = dict(enumerate(df['index']))
        with open(os.path.join(BASE_DIR, "index_mapping.pkl"), "wb") as f:
            pickle.dump(index_mapping, f)
        df.to_pickle(os.path.join(BASE_DIR, "processed_data.pkl"))

        # Doctor similarity matrix (use Name since it exists)
        interaction_matrix = df.pivot_table(
            index="Processed_Symptoms", columns="Name", values="Rating" if "Rating" in df.columns else None,
            aggfunc='mean', fill_value=0
        )
        doctor_similarity = cosine_similarity(interaction_matrix.T)
        doctor_similarity_df = pd.DataFrame(
            doctor_similarity, index=interaction_matrix.columns, columns=interaction_matrix.columns
        )
        doctor_similarity_df.to_pickle(os.path.join(BASE_DIR, "doctor_similarity.pkl"))
        logger.info("Data processed successfully.")
        return df, doctor_similarity_df, index_mapping
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        return pd.DataFrame(), pd.DataFrame(), {}
    except Exception as e:
        logger.error(f"Error in preprocess_data: {e}")
        raise
    
# Normalize symptoms
def normalize_symptoms(symptoms: str) -> str:
    symptoms = symptoms.lower().strip()
    if not symptoms:
        return ""
    normalized = [s.strip() for s in symptoms.split(",") if s.strip()]
    normalized_str = ", ".join(sorted(normalized))
    logger.info(f"Normalized symptoms: '{symptoms}' -> '{normalized_str}'")
    return normalized_str

# Load model and tokenizer
def load_tokenizer_and_model():
    try:
        if not os.path.exists(Config.MODEL_DIR):
            logger.error(f"Fine-tuned model not found at {Config.MODEL_DIR}.")
            raise FileNotFoundError("Fine-tuned model missing.")

        tokenizer = AutoTokenizer.from_pretrained(
            Config.MODEL_DIR, cache_dir="/home/f223085/hf", local_files_only=True
        )
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        logger.info(f"Available CUDA devices: {torch.cuda.device_count()}")
        model = AutoModelForCausalLM.from_pretrained(
            Config.MODEL_DIR,
            cache_dir="/home/f223085/hf",
            torch_dtype=torch.float16,
            low_cpu_mem_usage=False,
            local_files_only=True
        )
        Config.EMBEDDING_DIM = model.config.hidden_size
        model.to(device)
        model.eval()
        logger.info(f"Loaded fine-tuned model on {device}")
        return tokenizer, model, device
    except FileNotFoundError as e:
        logger.error(f"Model or tokenizer files missing: {e}")
        raise
    except Exception as e:
        logger.error(f"Error loading tokenizer or model: {e}")
        raise

# Load embeddings and create HNSW indices
def load_embeddings(df: pd.DataFrame):
    try:
        case_embeddings = np.load(Config.EMBEDDINGS_PATH)
        disease_embeddings = np.load(Config.DISEASE_EMBEDDINGS_PATH)
        logger.info(f"Loaded embeddings: case {case_embeddings.shape}, disease {disease_embeddings.shape}")

        if os.path.exists(Config.INDEX_MAPPING_PATH):
            with open(Config.INDEX_MAPPING_PATH, "rb") as f:
                index_mapping = pickle.load(f)
        else:
            logger.warning("No index mapping found, creating sequential indices")
            index_mapping = {i: i for i in range(len(df))}

        # Validate index_mapping and case_embeddings size
        valid_indices = []
        skipped_indices = []
        for i, orig_idx in index_mapping.items():
            if i < case_embeddings.shape[0] and orig_idx in df['index'].values:
                valid_indices.append(i)
            else:
                skipped_indices.append((i, orig_idx))
                logger.warning(f"Invalid index {i} or original index {orig_idx} not in DataFrame")

        if skipped_indices:
            logger.info(f"Skipped {len(skipped_indices)} invalid indices: {skipped_indices[:5]}{'...' if len(skipped_indices) > 5 else ''}")

        if not valid_indices:
            logger.error("No valid indices in index_mapping, rebuilding mapping")
            valid_indices = list(range(min(case_embeddings.shape[0], len(df))))
            index_mapping = {i: df['index'].iloc[i] for i in valid_indices}

        # Filter embeddings and DataFrame
        if case_embeddings.shape[0] < len(df):
            logger.warning(f"case_embeddings size {case_embeddings.shape[0]} smaller than DataFrame {len(df)}, filtering DataFrame")
            valid_orig_indices = [index_mapping[i] for i in valid_indices]
            df_filtered = df[df['index'].isin(valid_orig_indices)].reset_index(drop=True)
            case_embeddings = case_embeddings[valid_indices]
            index_mapping = {i: df_filtered['index'].iloc[i] for i in range(len(df_filtered))}
            df = df_filtered
            logger.info(f"Filtered DataFrame to {len(df)} rows to match embeddings")
        else:
            case_embeddings = case_embeddings[valid_indices]
            logger.info(f"Filtered case_embeddings to {len(valid_indices)} rows")

        if case_embeddings.shape[0] != len(df):
            logger.error(f"Embedding size mismatch after filtering: {case_embeddings.shape[0]} vs DataFrame {len(df)}")
            raise ValueError("Embedding size mismatch")

        # Create HNSW indices
        dim = case_embeddings.shape[1]
        num_elements_case = case_embeddings.shape[0]
        num_elements_disease = disease_embeddings.shape[0]

        # Case embeddings index
        case_index = hnswlib.Index(space='cosine', dim=dim)
        case_index.init_index(max_elements=num_elements_case, ef_construction=Config.HNSW_EF_CONSTRUCTION, M=Config.HNSW_M)
        case_index.add_items(case_embeddings, np.arange(num_elements_case))
        case_index.set_ef(Config.HNSW_EF_SEARCH)
        case_index.save_index(Config.CASE_HNSW_PATH)
        logger.info(f"Saved case HNSW index to {Config.CASE_HNSW_PATH}")

        # Disease embeddings index
        disease_index = hnswlib.Index(space='cosine', dim=dim)
        disease_index.init_index(max_elements=num_elements_disease, ef_construction=Config.HNSW_EF_CONSTRUCTION, M=Config.HNSW_M)
        disease_index.add_items(disease_embeddings, np.arange(num_elements_disease))
        disease_index.set_ef(Config.HNSW_EF_SEARCH)
        disease_index.save_index(Config.DISEASE_HNSW_PATH)
        logger.info(f"Saved disease HNSW index to {Config.DISEASE_HNSW_PATH}")

        with open(Config.INDEX_MAPPING_PATH, "wb") as f:
            pickle.dump(index_mapping, f)
        df.to_pickle(os.path.join(BASE_DIR, "processed_data.pkl"))

        logger.info(f"Final embeddings: case {case_embeddings.shape}, disease {disease_embeddings.shape}")
        return case_embeddings, disease_embeddings, index_mapping, df, case_index, disease_index
    except FileNotFoundError as e:
        logger.error(f"Embeddings not found: {e}")
        raise
    except Exception as e:
        logger.error(f"Error loading embeddings or creating HNSW indices: {e}")
        raise

# Extract semantic features
def extract_semantic_features(text: str, model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
                              device: torch.device) -> np.ndarray:
    try:
        with torch.no_grad():
            inputs = tokenizer(
                text, return_tensors="pt", max_length=Config.MAX_LENGTH,
                truncation=True, padding=True
            ).to(device)
            outputs = model(**inputs, output_hidden_states=True)
            features = torch.mean(outputs.hidden_states[-1], dim=1).cpu().numpy().flatten()
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        return features
    except Exception as e:
        logger.error(f"Error extracting features: {e}")
        return np.zeros(Config.EMBEDDING_DIM)

# DCG and NDCG
def dcg_score(scores: List[float], k: int) -> float:
    scores = np.array(scores[:k])
    if len(scores) == 0:
        return 0.0
    return np.sum((2 ** scores - 1) / np.log2(np.arange(2, len(scores) + 2)))

def ndcg_score(scores: List[float], ideal_scores: List[float], k: int) -> float:
    if not scores or not ideal_scores:
        return 0.0
    actual_dcg = dcg_score(scores, k)
    ideal_dcg = dcg_score(sorted(ideal_scores, reverse=True), k)
    return actual_dcg / ideal_dcg if ideal_dcg > 0 else 0.0

# Average precision
def average_precision(pred_doctors: List[str], gt_doctors: List[str]) -> float:
    relevant = set(gt_doctors)
    if not relevant:
        return 0.0
    precisions = []
    hits = 0
    for i, doctor in enumerate(pred_doctors, 1):
        if doctor in relevant:
            hits += 1
            precisions.append(hits / i)
    return np.mean(precisions) if precisions else 0.0

# Compute metrics
def compute_metrics(predictions: List[Dict], df: pd.DataFrame, city: str, target_specialist: str,
                    model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device,
                    doctor_similarity_df: pd.DataFrame, top_k: int = Config.TOP_K) -> Dict[str, float]:
    precision_scores, recall_scores, ndcg_scores, map_scores, hit_rates, mrr_scores = [], [], [], [], [], []
    bleu_scores, rouge_scores, meteor_scores, ctr_scores = [], [], [], []
    coverage_set = set()
    cold_start_precision, novelty_scores, serendipity_scores, diversity_scores = [], [], [], []
    explainability_scores, inference_times, toxicity_scores = [], [], []
    mse_scores, rmse_scores = [], []
    hallucination_rates, personalization_scores, robustness_scores, business_alignment_scores = [], [], [], []

    item_popularity = df["Name"].value_counts() / len(df)
    item_popularity = item_popularity / item_popularity.sum()

    scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    smooth = SmoothingFunction()

    for pred in predictions:
        start_time = time.time()
        pred_doctors = [rec["doctor"] for rec in pred["recommendations"]]
        city = city.lower()
        expected_doctors = df[df["Specialist"] == target_specialist]["Name"].tolist()
        if city != "unknown":
            city_specific = df[(df["City"] == city) & (df["Specialist"] == target_specialist)]["Name"].tolist()
            if city_specific:
                expected_doctors = city_specific
        coverage_set.update(pred_doctors)

        inference_time = time.time() - start_time
        inference_times.append(inference_time)

        if not expected_doctors:
            logger.warning(f"No expected doctors for {city}, {target_specialist}, using top-rated specialists")
            expected_doctors = df[df["Specialist"] == target_specialist].sort_values(by="Rating", ascending=False)["Name"].head(10).tolist()

        relevant = set()
        for pred_doc in pred_doctors[:top_k]:
            for exp_doc in expected_doctors:
                if fuzz.ratio(pred_doc.lower(), exp_doc.lower()) > 80:
                    relevant.add(pred_doc)

        precision = len(relevant) / top_k if top_k > 0 else 0.0
        recall = len(relevant) / len(expected_doctors) if expected_doctors else 0.0
        precision_scores.append(precision)
        recall_scores.append(recall)

        scores = [1.0 if d in relevant else 0.0 for d in pred_doctors[:top_k]]
        ideal_scores = [1.0] * min(len(expected_doctors), top_k)
        ndcg_scores.append(ndcg_score(scores, ideal_scores, top_k))

        ap = average_precision(pred_doctors, expected_doctors)
        map_scores.append(ap)

        hit = 1.0 if relevant else 0.0
        hit_rates.append(hit)

        for i, doctor in enumerate(pred_doctors, 1):
            if doctor in relevant:
                mrr_scores.append(1.0 / i)
                break
        else:
            mrr_scores.append(0.0)

        if pred["condition"].lower() == "general check-up":
            cold_start_precision.append(precision)

        pred_text = " ".join([rec["recommendation_text"] for rec in pred["recommendations"]])
        expected_text = f"Recommended {target_specialist} in {city} for {pred['condition'].lower()}"
        if expected_text and pred_text:
            bleu_scores.append(sentence_bleu([expected_text.split()], pred_text.split(), weights=(0.5, 0.5, 0, 0), smoothing_function=smooth.method1))
            rouge_result = scorer.score(expected_text, pred_text)
            rouge_scores.append(rouge_result['rougeL'].fmeasure)
            meteor_scores.append(meteor_score([expected_text.split()], pred_text.split()))

        clicks = sum(df[df["Name"] == d]["Rating"].iloc[0] / 5.0 for d in pred_doctors[:top_k] if d in df["Name"].values)
        ctr_scores.append(clicks / top_k if top_k > 0 else 0.0)

        novelty = sum(1 - item_popularity.get(d, 0.0) for d in pred_doctors[:top_k]) / top_k if top_k > 0 else 0.0
        novelty_scores.append(novelty)

        past_symptoms = pred.get("past_symptoms", [])
        if past_symptoms:
            serendipity = 1 - max(cosine_similarity([extract_semantic_features(pred_text, model, tokenizer, device)],
                                                   [extract_semantic_features(" ".join(past_symptoms), model, tokenizer, device)])[0][0], 0)
        else:
            serendipity = novelty
        serendipity_scores.append(serendipity)

        if len(pred_doctors) > 1:
            sim_sum = 0.0
            count = 0
            for i in range(len(pred_doctors[:top_k])):
                for j in range(i + 1, len(pred_doctors[:top_k])):
                    if pred_doctors[i] in doctor_similarity_df.index and pred_doctors[j] in doctor_similarity_df.index:
                        sim_sum += doctor_similarity_df.loc[pred_doctors[i], pred_doctors[j]]
                        count += 1
            diversity = 1 - (sim_sum / count if count > 0 else 0.0)
        else:
            diversity = 1.0
        diversity_scores.append(diversity)

        explainability = len(pred_text.split()) / 50.0
        explainability_scores.append(min(explainability, 1.0))

        if Config.TOXICITY_MODEL:
            toxicity_result = Config.TOXICITY_MODEL.predict(pred_text)
            toxicity_scores.append(toxicity_result['toxicity'])

        pred_ratings = [df[df["Name"] == d]["Rating"].iloc[0] for d in pred_doctors[:top_k] if d in df["Name"].values]
        gt_ratings = [df[df["Name"] == d]["Rating"].iloc[0] for d in expected_doctors if d in df["Name"].values]
        if pred_ratings and gt_ratings:
            mse = mean_squared_error([np.mean(gt_ratings)] * len(pred_ratings), pred_ratings)
            rmse = np.sqrt(mse)
            mse_scores.append(mse)
            rmse_scores.append(rmse)

        hallucinations = sum(1 for d in pred_doctors if d not in df["Name"].values)
        hallucination_rates.append(hallucinations / top_k if top_k > 0 else 0.0)

        pred_condition = pred["condition"].lower()
        pred_embedding = extract_semantic_features(pred_condition, model, tokenizer, device)
        gt_embedding = extract_semantic_features("routine check-up" if pred_condition == "general check-up" else pred_condition, model, tokenizer, device)
        personalization = cosine_similarity([pred_embedding], [gt_embedding])[0][0]
        personalization_scores.append(personalization)

        rephrased = " ".join(pred_condition.split()[::-1])
        rephrased_emb = extract_semantic_features(rephrased, model, tokenizer, device)
        robustness = cosine_similarity([pred_embedding], [rephrased_emb])[0][0]
        robustness_scores.append(robustness)

        business_alignment = np.mean([df[df["Name"] == d]["Rating"].iloc[0] for d in pred_doctors[:top_k] if d in df["Name"].values]) / 5.0 if pred_doctors else 0.0
        business_alignment_scores.append(business_alignment)

    process = psutil.Process()
    memory_usage = process.memory_info().rss / (1024 ** 2)

    metrics = {
        "precision@k": float(np.mean(precision_scores)) if precision_scores else 0.0,
        "recall@k": float(np.mean(recall_scores)) if recall_scores else 0.0,
        "f1@k": float(2 * np.mean(precision_scores) * np.mean(recall_scores) / (
            np.mean(precision_scores) + np.mean(recall_scores))) if precision_scores and recall_scores and (
            np.mean(precision_scores) + np.mean(recall_scores)) > 0 else 0.0,
        "ndcg@k": float(np.mean(ndcg_scores)) if ndcg_scores else 0.0,
        "map": float(np.mean(map_scores)) if map_scores else 0.0,
        "hit_rate@k": float(np.mean(hit_rates)) if hit_rates else 0.0,
        "mrr": float(np.mean(mrr_scores)) if mrr_scores else 0.0,
        "bleu": float(np.mean(bleu_scores)) if bleu_scores else 0.0,
        "rougeL": float(np.mean(rouge_scores)) if rouge_scores else 0.0,
        "meteor": float(np.mean(meteor_scores)) if meteor_scores else 0.0,
        "ctr": float(np.mean(ctr_scores)) if ctr_scores else 0.0,
        "coverage": float(len(coverage_set) / len(df["Name"].unique())) if len(df["Name"].unique()) > 0 else 0.0,
        "cold_start_precision": float(np.mean(cold_start_precision)) if cold_start_precision else 0.0,
        "novelty": float(np.mean(novelty_scores)) if novelty_scores else 0.0,
        "serendipity": float(np.mean(serendipity_scores)) if serendipity_scores else 0.0,
        "diversity": float(np.mean(diversity_scores)) if diversity_scores else 0.0,
        "explainability_score": float(np.mean(explainability_scores)) if explainability_scores else 0.0,
        "avg_inference_time": float(np.mean(inference_times)) if inference_times else 0.0,
        "toxicity_score": float(np.mean(toxicity_scores)) if toxicity_scores else 0.0,
        "mse": float(np.mean(mse_scores)) if mse_scores else 0.0,
        "rmse": float(np.mean(rmse_scores)) if rmse_scores else 0.0,
        "hallucination_rate": float(np.mean(hallucination_rates)) if hallucination_rates else 0.0,
        "personalization_score": float(np.mean(personalization_scores)) if personalization_scores else 0.0,
        "robustness_score": float(np.mean(robustness_scores)) if robustness_scores else 0.0,
        "business_alignment_score": float(np.mean(business_alignment_scores)) if business_alignment_scores else 0.0,
        "memory_usage_MB": float(memory_usage)
    }

    with open(os.path.join(BASE_DIR, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    logger.info(f"Metrics computed: {metrics}")
    return metrics

# Inference function with HNSW
def inference(patient_data: Dict, df: pd.DataFrame, doctor_similarity_df: pd.DataFrame,
              case_embeddings: np.ndarray, disease_embeddings: np.ndarray,
              model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device,
              index_mapping: Dict[int, int], case_index: hnswlib.Index, disease_index: hnswlib.Index) -> Dict[str, Any]:
    try:
        name = patient_data.get("name", "Unknown")
        symptoms = normalize_symptoms(patient_data.get("symptoms", ""))
        city_filter = patient_data.get("city", "").strip().lower()
        logger.info(f"Processing patient: {name}, symptoms={symptoms}, city_filter={city_filter}")
        recommendations = []
        seen_doctors = set()

        try:
            with sqlite3.connect(Config.DB_PATH) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT symptoms, ratings FROM patients WHERE name = ?", (name,))
                result = cursor.fetchone()
                past_symptoms = json.loads(result[0]) if result else []
                ratings = json.loads(result[1]) if result else {}
        except sqlite3.Error as db_e:
            logger.error(f"Database query failed for {name}: {db_e}")
            past_symptoms = []
            ratings = {}

        predicted_diseases = []
        disease_confidences = []

        print(Config.GREETING.format(name, city_filter.capitalize()))
        print(Config.ANALYZING.format(city_filter.capitalize()))

        if not symptoms:
            logger.info(f"No symptoms for {name}, using cold start")
            target_specialist = Config.disease_specialist_dict["unknown"]
            filtered_df = df[df["Specialist"] == target_specialist].copy()
            if city_filter and city_filter != "unknown":
                filtered_df = filtered_df[filtered_df["City"] == city_filter]
            if filtered_df.empty:
                logger.warning(f"No {target_specialist}s in {city_filter}, using all cities")
                print(Config.FALLBACK_MESSAGE.format(target_specialist, city_filter.capitalize()))
                filtered_df = df[df["Specialist"] == target_specialist].copy()
            top_doctors = filtered_df.sort_values(by="Rating", ascending=False).head(Config.TOP_K)
            for _, doctor in top_doctors.iterrows():
                if doctor["Name"].lower() not in seen_doctors:
                    recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                        doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                        "general check-up"
                    )
                    recommendation_text += f" Selected based on high patient ratings ({doctor['Rating']}) and verified practice in {doctor['City']}."
                    recommendations.append({
                        "doctor": doctor["Name"],
                        "specialist": doctor["Specialist"],
                        "city": doctor["City"],
                        "rating": float(doctor["Rating"]),
                        "recommendation_text": recommendation_text,
                        "disease": "general check-up"
                    })
                    seen_doctors.add(doctor["Name"].lower())

            exploratory_df = df[df["Specialist"] != target_specialist].copy()
            if city_filter and city_filter != "unknown":
                exploratory_df = exploratory_df[exploratory_df["City"] == city_filter]
            exploratory_df = exploratory_df.sort_values(by="Rating", ascending=False)
            exploratory_count = 0
            for _, doctor in exploratory_df.iterrows():
                if doctor["Name"].lower() not in seen_doctors and exploratory_count < Config.EXPLORATORY_K:
                    recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                        doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                        f"{doctor['Specialist']} expertise"
                    )
                    recommendation_text += f" Selected based on high patient ratings ({doctor['Rating']}) and verified practice in {doctor['City']}."
                    recommendations.append({
                        "doctor": doctor["Name"],
                        "specialist": doctor["Specialist"],
                        "city": doctor["City"],
                        "rating": float(doctor["Rating"]),
                        "recommendation_text": recommendation_text,
                        "disease": "exploratory"
                    })
                    seen_doctors.add(doctor["Name"].lower())
                    exploratory_count += 1
                if exploratory_count >= Config.EXPLORATORY_K:
                    break

            response = {
                "name": name,
                "condition": "General check-up",
                "disease_confidences": [("general check-up", 1.0)],
                "recommendations": recommendations,
                "advice": Config.DISEASE_ADVICE.get("general physician", Config.GENERAL_ADVICE),
                "past_symptoms": past_symptoms
            }
            logger.info(f"Cold start recommendations for {name}: {[rec['doctor'] for rec in recommendations]}")
            return response

        query_input = f"Symptoms: {symptoms}. Age: adult. Severity: moderate."
        query_embedding = extract_semantic_features(query_input, model, tokenizer, device)
        logger.info(f"Query embedding shape: {query_embedding.shape}")

        # HNSW-based disease prediction
        if query_embedding.shape[0] > 0:
            try:
                labels, distances = disease_index.knn_query(query_embedding.reshape(1, -1), k=Config.TOP_K)
                similarities = 1 - distances[0]  # Convert distances to similarities
                logger.info(f"Top {Config.TOP_K} disease similarities: {list(zip(labels[0], similarities))}")
                unique_diseases = sorted(df["Processed_Disease"].unique().tolist())
                for idx, sim in zip(labels[0], similarities):
                    if idx < len(unique_diseases):
                        disease = unique_diseases[idx]
                        confidence = float(sim)
                        if confidence >= Config.SIMILARITY_THRESHOLD:
                            predicted_diseases.append(disease)
                            disease_confidences.append((disease, confidence))
                if not predicted_diseases:
                    logger.warning(f"No diseases matched for {name} with symptoms {symptoms}, using fallback")
                    predicted_diseases = ["unknown"]
                    disease_confidences = [("unknown", 0.0)]
            except Exception as e:
                logger.error(f"HNSW disease query error for {name}: {e}")
                predicted_diseases = ["unknown"]
                disease_confidences = [("unknown", 0.0)]
        else:
            logger.error(f"Invalid query embedding for {name}, using fallback")
            predicted_diseases = ["unknown"]
            disease_confidences = [("unknown", 0.0)]

        for disease in predicted_diseases[:Config.TOP_K]:
            target_specialist = Config.disease_specialist_dict.get(disease, "general physician")
            filtered_df = df[(df["Processed_Disease"] == disease) & (df["Specialist"] == target_specialist)].copy()
            if city_filter and city_filter != "unknown":
                filtered_df_city = filtered_df[filtered_df["City"] == city_filter]
                if filtered_df_city.empty:
                    logger.warning(f"No {target_specialist}s for {disease} in {city_filter}, trying all cities")
                    filtered_df = df[(df["Processed_Disease"] == disease) & (df["Specialist"] == target_specialist)].copy()
            if filtered_df.empty:
                logger.warning(f"No doctors for {disease} and {target_specialist}, relaxing disease filter")
                filtered_df = df[df["Specialist"] == target_specialist].copy()
                if city_filter and city_filter != "unknown":
                    filtered_df_city = filtered_df[filtered_df["City"] == city_filter]
                    if filtered_df_city.empty:
                        logger.warning(f"No {target_specialist}s in {city_filter}, using all cities")
                        print(Config.FALLBACK_MESSAGE.format(target_specialist, city_filter.capitalize()))
                        filtered_df = df[df["Specialist"] == target_specialist].copy()
            logger.info(f"Filtered_df size for {disease}, {target_specialist}: {len(filtered_df)}")
            top_doctors = filtered_df.sort_values(by="Rating", ascending=False).head(Config.TOP_K)
            for _, doctor in top_doctors.iterrows():
                if doctor["Name"].lower() not in seen_doctors:
                    recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                        doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                        f"{target_specialist} expertise for {disease}"
                    )
                    recommendation_text += f" Selected based on high patient ratings ({doctor['Rating']}) and verified practice in {doctor['City']}."
                    recommendations.append({
                        "doctor": doctor["Name"],
                        "specialist": doctor["Specialist"],
                        "city": doctor["City"],
                        "rating": float(doctor["Rating"]),
                        "recommendation_text": recommendation_text,
                        "disease": disease
                    })
                    seen_doctors.add(doctor["Name"].lower())

            if len([rec for rec in recommendations if rec["disease"] == disease]) < Config.TOP_K and query_embedding.shape[0] > 0:
                try:
                    labels, distances = case_index.knn_query(query_embedding.reshape(1, -1), k=Config.TOP_K)
                    similarities = 1 - distances[0]
                    logger.info(f"Top {Config.TOP_K} case similarities: {list(zip(labels[0], similarities))}")
                    for idx, _ in zip(labels[0], similarities):
                        if idx in index_mapping:
                            df_idx = index_mapping[idx]
                            if df_idx in df['index'].values:
                                doctor_row = df[df['index'] == df_idx].iloc[0]
                                if doctor_row["Specialist"] == target_specialist and doctor_row["Name"].lower() not in seen_doctors:
                                    recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                                        doctor_row["Name"], doctor_row["Specialist"], doctor_row["City"], doctor_row["Rating"],
                                        f"{target_specialist} expertise for {disease}"
                                    )
                                    recommendation_text += f" Selected based on high patient ratings ({doctor_row['Rating']}) and verified practice in {doctor_row['City']}."
                                    recommendations.append({
                                        "doctor": doctor_row["Name"],
                                        "specialist": doctor_row["Specialist"],
                                        "city": doctor_row["City"],
                                        "rating": float(doctor_row["Rating"]),
                                        "recommendation_text": recommendation_text,
                                        "disease": disease
                                    })
                                    seen_doctors.add(doctor_row["Name"].lower())
                                    if len([rec for rec in recommendations if rec["disease"] == disease]) >= Config.TOP_K:
                                        break
                            else:
                                logger.warning(f"Invalid index {df_idx} for embedding {idx}, skipping")
                        else:
                            logger.warning(f"Invalid embedding idx {idx}, skipping")
                except ValueError as e:
                    logger.warning(f"HNSW case query failed for {disease}: {e}")
                    top_doctors_fallback = df[df["Specialist"] == target_specialist].sort_values(by="Rating", ascending=False).head(Config.TOP_K)
                    for _, doctor in top_doctors_fallback.iterrows():
                        if doctor["Name"].lower() not in seen_doctors:
                            recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                                doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                                f"{target_specialist} expertise for {disease}"
                            )
                            recommendation_text += f" Selected based on high patient ratings ({doctor['Rating']}) and verified practice in {doctor['City']}."
                            recommendations.append({
                                "doctor": doctor["Name"],
                                "specialist": doctor["Specialist"],
                                "city": doctor["City"],
                                "rating": float(doctor["Rating"]),
                                "recommendation_text": recommendation_text,
                                "disease": disease
                            })
                            seen_doctors.add(doctor["Name"].lower())

        exploratory_df = df[df["Specialist"] != Config.disease_specialist_dict.get(predicted_diseases[0], "general physician")].copy()
        if city_filter and city_filter != "unknown":
            exploratory_df = exploratory_df[exploratory_df["City"] == city_filter]
        exploratory_df = exploratory_df.sort_values(by="Rating", ascending=False)
        exploratory_count = 0
        for _, doctor in exploratory_df.iterrows():
            if doctor["Name"].lower() not in seen_doctors and exploratory_count < Config.EXPLORATORY_K:
                recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                    doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                    f"{doctor['Specialist']} expertise"
                )
                recommendation_text += f" Selected based on high patient ratings ({doctor['Rating']}) and verified practice in {doctor['City']}."
                recommendations.append({
                    "doctor": doctor["Name"],
                    "specialist": doctor["Specialist"],
                    "city": doctor["City"],
                    "rating": float(doctor["Rating"]),
                    "recommendation_text": recommendation_text,
                    "disease": "exploratory"
                })
                seen_doctors.add(doctor["Name"].lower())
                exploratory_count += 1
            if exploratory_count >= Config.EXPLORATORY_K:
                break

        past_symptom_weight = 0.0
        if past_symptoms and symptoms:
            past_embedding = extract_semantic_features(" ".join(past_symptoms), model, tokenizer, device)
            past_symptom_weight = float(cosine_similarity([past_embedding], [query_embedding])[0][0])
            logger.info(f"Past symptom similarity score for {name}: {past_symptom_weight:.2f}")

        for rec in recommendations:
            doctor_name = rec["doctor"]
            rating_bonus = float(ratings.get(doctor_name, 0.0)) / 5.0
            rec["score"] = float(rec["rating"]) + (rating_bonus * 0.3) + (past_symptom_weight * 0.2)

        recommendations = sorted(recommendations, key=lambda x: x["score"], reverse=True)

        advice = Config.DISEASE_ADVICE.get(predicted_diseases[0], Config.GENERAL_ADVICE)
        response = {
            "name": name,
            "condition": f"Multiple conditions possible" if len(predicted_diseases) > 1 else predicted_diseases[0].capitalize(),
            "disease_confidences": disease_confidences,
            "recommendations": recommendations,
            "advice": advice,
            "past_symptoms": past_symptoms
        }

        logger.info(f"Recommendations for {name}: {[rec['doctor'] for rec in recommendations]}")
        return response
    except Exception as e:
        logger.error(f"Error in inference for {name}: {e}")
        return {
            "name": name,
            "condition": "unknown",
            "disease_confidences": [],
            "recommendations": [],
            "advice": Config.GENERAL_ADVICE,
            "past_symptoms": []
        }

# Plot visualizations
def plot_visualizations(df: pd.DataFrame, case_embeddings: np.ndarray, metrics: Dict[str, float]):
    os.makedirs(Config.PLOTS_DIR, exist_ok=True)
    plots = []

    training_data = [
        {'loss': 9.167, 'grad_norm': 1.65517495222473, 'learning_rate': 0.0002830507846271, 'epoch': 0.17},
        {'loss': 4.934, 'grad_norm': 1.805, 'learning_rate': 0.0002661016949154, 'epoch': 0.34},
        {'loss': 4.0932, 'grad_norm': 2.147407293319702, 'learning_rate': 0.00024915254237288135, 'epoch': 0.51},
        {'loss': 3.7052, 'grad_norm': 2.4243781334381104, 'learning_rate': 0.00023220338983050845, 'epoch': 0.68},
        {'loss': 3.5349, 'grad_norm': 3.3309762088928223, 'learning_rate': 0.0002152542372881351, 'epoch': 0.85},
        {'loss': 3.391, 'grad_norm': 2.4204895863189697, 'learning_rate': 0.0001983050847457627, 'epoch': 1.02},
        {'loss': 3.3183, 'grad_norm': 2.4626454132995605, 'learning_rate': 0.0001813559322033898, 'epoch': 1.18},
        {'loss': 3.1755, 'grad_norm': 3.7217094561234, 'learning_rate': 0.00016440677966101692, 'epoch': 1.35},
        {'loss': 3.2133, 'grad_norm': 2.6664648056030273, 'learning_rate': 0.00014745762711864405, 'epoch': 1.52},
        {'loss': 3.1098, 'grad_norm': 3.109283685684204, 'learning_rate': 0.00013050847457627118, 'epoch': 1.69},
        {'loss': 3.0918, 'grad_norm': 2.8029, 'learning_rate': 0.0001135593220338983, 'epoch': 1.86},
        {'loss': 3.0737, 'grad_norm': 2.845672369003296, 'learning_rate': 9.661016949152541e-05, 'epoch': 2.03},
        {'loss': 3.0587, 'grad_norm': 2.999819755554199, 'learning_rate': 7.966101694915254e-05, 'epoch': 2.2},
        {'loss': 2.9961, 'grad_norm': 2.6304784178320544, 'learning_rate': 6.271186440677965e-05, 'epoch': 2.37},
        {'loss': 2.9748, 'grad_norm': 2.769517660140991, 'learning_rate': 4.576271186440678e-05, 'epoch': 2.54},
        {'loss': 2.0214, 'grad_norm': 2.9226834774017334, 'learning_rate': 2.8813559322033896e-05, 'epoch': 2.71},
        {'loss': 2.9924, 'grad_norm': 2.7975263595581055, 'learning_rate': 1.1864406779661016e-05, 'epoch': 2.88}
    ]

    eval_data = [
        {'eval_loss': 3.250072717666626, 'eval_accuracy': 0.06725958766036687, 'eval_precision': 0.03675097346218405,
         'eval_recall': 0.06725958866036687, 'eval_f1': 0.046023797680514055, 'eval_perplexity': 643.5369872520871, 'epoch': 1.0},
        {'eval_loss': 2.9628424644470215, 'eval_accuracy': 0.06503699418399111, 'eval_precision': 0.049946783464359896,
         'eval_recall': 0.06503699418399111, 'eval_f1': 0.04872880275336565, 'eval_perplexity': 813.9467927623219, 'epoch': 2.0},
        {'eval_loss': 2.894439697265625, 'eval_accuracy': 0.06670372429127293, 'eval_precision': 0.0523183867882114,
         'eval_recall': 0.06670372429127293, 'eval_f1': 0.050252139229936064, 'eval_perplexity': 850.7546598767408, 'epoch': 3.0},
    ]

    sns.set_style("darkgrid")
    palette = sns.color_palette("husl", 3)

    plt.figure(figsize=(8, 6))
    plt.plot([d['epoch'] for d in training_data], [d['loss'] for d in training_data], marker='o', color=palette[0], label="Training Loss")
    plt.plot([d['epoch'] for d in eval_data], [d['eval_loss'] for d in eval_data], marker='^', color=palette[1], label="Evaluation Loss")
    plt.title("Training and Evaluation Loss vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.grid(True)
    loss_path = os.path.join(Config.PLOTS_DIR, "loss_curve.png")
    plt.savefig(loss_path)
    plt.close()
    plots.append(loss_path)

    plt.figure(figsize=(8, 6))
    plt.plot([d['epoch'] for d in training_data], [d['grad_norm'] for d in training_data], marker='o', color=palette[0])
    plt.title("Gradient Norm vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Gradient Norm")
    plt.grid(True)
    grad_norm_path = os.path.join(Config.PLOTS_DIR, "grad_norm.png")
    plt.savefig(grad_norm_path)
    plt.close()
    plots.append(grad_norm_path)

    plt.figure(figsize=(8, 6))
    plt.plot([d['epoch'] for d in training_data], [d['learning_rate'] for d in training_data], marker='o', color='orange')
    plt.title("Learning Rate vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Learning Rate")
    plt.grid(True)
    lr_path = os.path.join(Config.PLOTS_DIR, "learning_rate.png")
    plt.savefig(lr_path)
    plt.close()
    plots.append(lr_path)

    plt.figure(figsize=(8, 6))
    plt.plot([d['epoch'] for d in eval_data], [d['eval_accuracy'] for d in eval_data], marker='o', color=palette[0])
    plt.title("Evaluation Accuracy vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.grid(True)
    eval_accuracy_path = os.path.join(Config.PLOTS_DIR, "eval_accuracy.png")
    plt.savefig(eval_accuracy_path)
    plt.close()
    plots.append(eval_accuracy_path)

    plt.figure(figsize=(10, 6))
    plt.plot([d['epoch'] for d in eval_data], [d['eval_precision'] for d in eval_data], marker='o', label='Precision', color=palette[0])
    plt.plot([d['epoch'] for d in eval_data], [d['eval_recall'] for d in eval_data], marker='^', label='Recall', color=palette[1])
    plt.plot([d['epoch'] for d in eval_data], [d['eval_f1'] for d in eval_data], marker='s', label='F1', color=palette[2])
    plt.title("Evaluation Metrics vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Score")
    plt.legend()
    plt.grid(True)
    eval_prf_path = os.path.join(Config.PLOTS_DIR, "eval_prf.png")
    plt.savefig(eval_prf_path)
    plt.close()
    plots.append(eval_prf_path)

    plt.figure(figsize=(8, 6))
    plt.plot([d['epoch'] for d in eval_data], [d['eval_perplexity'] for d in eval_data], marker='o', color=palette[0])
    plt.title("Evaluation Perplexity vs. Epoch")
    plt.xlabel("Epoch")
    plt.ylabel("Perplexity")
    plt.grid(True)
    eval_perplexity_path = os.path.join(Config.PLOTS_DIR, "eval_perplexity.png")
    plt.savefig(eval_perplexity_path)
    plt.close()
    plots.append(eval_perplexity_path)

    plt.figure(figsize=(10, 6))
    plt.bar(['Precision@k', 'Recall@k', 'F@k'], [metrics.get('precision@k', 0), metrics.get('recall@k', 0), metrics.get('f1@k', 0)], color=[palette[0], palette[1], palette[2]])
    plt.title("Recommendation Metrics")
    plt.ylabel("Score")
    plt.grid(True)
    prf_k_path = os.path.join(Config.PLOTS_DIR, "prf_k.png")
    plt.savefig(prf_k_path)
    plt.close()
    plt.figure(figsize=(8, 6))
    plt.bar(['NDCG@k', 'MAP'], [metrics.get('ndcg@k', 0), metrics.get('map', 0)], color=[palette[palette[0]], palette[1]])
    plt.title("Ranking Metrics")
    plt.ylabel("Score")
    plt.grid(True)
    ndcg_map_path = os.path.join(Config.PLOTS_DIR, "ndcg_map.png")
    plt.savefig(ndcg_map_path)
    plt.close()
    plots.append(ndcg_map_path)

    plt.figure(figsize=(8, 6))
    plt.bar(['Hit Rate@k', 'MRR'], [metrics.get('hit_rate@k', 0), metrics.get('mrr', 0)], color=[palette[0], palette[1]])
    plt.title("Hit Rate and MRR")
    plt.ylabel("Score")
    plt.grid(True)
    hit_mrr_path = os.path.join(Config.PLOTS_DIR, "hit_mrr.png")
    plt.savefig(hit_mrr_path)
    plt.close()
    plots.append(hit_mrr_path)

    plt.figure(figsize=(10, 6))
    plt.bar(['BLEU', 'ROUGE-L', 'METEOR'], [metrics.get('bleu', 0), metrics.get('rougeL', 0), metrics.get('meteor', 0)], color=[palette[0], palette[1], palette[2]])
    plt.title("Text Generation Metrics")
    plt.ylabel("Score")
    plt.grid(True)
    text_metrics_path = os.path.join(Config.PLOTS_DIR, "text_metrics.png")
    plt.savefig(text_metrics_path)
    plt.close()
    plots.append(text_metrics_path)

    plt.figure(figsize=(12, 6))
    plt.bar(['Coverage', 'Novelty', 'Serendipity', 'Diversity'], [metrics.get('coverage', 0), metrics.get('novelty', 0), metrics.get('serendipity', 0), metrics.get('diversity', 0)], color=[palette[0], palette[1], palette[2], 'green'])
    plt.title("Additional Metrics")
    plt.ylabel("Score")
    plt.grid(True)
    additional_metrics_path = os.path.join(Config.PLOTS_DIR, "additional_metrics.png")
    plt.savefig(additional_metrics_path)
    plt.close()
    plots.append(additional_metrics_path)

    plt.figure(figsize=(8, 6))
    sns.histplot(data=df, x='Rating', bins=10, kde=True, color=palette[0])
    plt.title("Doctor Rating Distribution")
    plt.xlabel("Rating")
    plt.ylabel("Count")
    plt.grid(True)
    rating_hist_path = os.path.join(Config.PLOTS_DIR, "rating_hist.png")
    plt.savefig(rating_hist_path)
    plt.close()
    plots.append(rating_hist_path)

    plt.figure(figsize=(8, 6))
    sns.countplot(data=df, x="Specialist", hue="specialist", palette="viridis")
    plt.title("Specialist Distribution")
    plt.xlabel("Specialist")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.grid(True)
    specialist_plot_path = os.path.join(Config.PLOTS_DIR, "specialist_plot.png")
    plt.savefig(specialist_plot_path)
    plt.close()
    plots.append(specialist_plot_path)

    plt.figure(figsize=(10, 8))
    try:
        sample_size = min(100, case_embeddings.shape[0])
        tsne = TSNE(n_components=2, random_state=42, perplexity=min(5, sample_size-1))
        tsne_embeddings = tsne.fit_transform(case_embeddings[:sample_size])
        sns.scatterplot(x=tsne_embeddings[:, 0], y=tsne_embeddings[:, 1], hue=df['Specialist'].iloc[:sample_size].values, palette="viridis")
        plt.title("t-SNE Plot of Case Embeddings")
        plt.xlabel("t-SNE Component 1")
        plt.ylabel("t-SNE Component 2")
        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.grid(True)
        tsne_path = os.path.join(Config.PLOTS_DIR, "tsne_embeddings.png")
        plt.savefig(tsne_path, bbox_inches='tight')
        plt.close()
        plots.append(tsne_path)
    except Exception as e:
        logger.error(f"Failed to generate t-SNE plot: {e}")

    plt.figure(figsize=(8, 6))
    plt.bar(['Cold Start Precision'], [metrics.get('cold_start_precision', 0)], color=palette[0])
    plt.title("Cold Start Precision")
    plt.ylabel("Score")
    plt.grid(True)
    cold_start_path = os.path.join(Config.PLOTS_DIR, "cold_start_precision.png")
    plt.savefig(cold_start_path)
    plt.close()
    plots.append(cold_start_path)

    logger.info(f"Generated {len(plots)} plots in {Config.PLOTS_DIR}")
    return plots

### **Main function**
def main():
    try:
        init_environment()
        logger.info("Environment initialized.")
        init_database()
        df, doctor_similarity_df, index_mapping = preprocess_data()
        logger.info(f"Unique cities in dataset: {sorted(df['City'].str.lower().unique().tolist())}")
        logger.info(f"Unique specialists in dataset: {sorted(df['Specialist'].unique().tolist())}")

        tokenizer, model, device = load_tokenizer_and_model()
        case_embeddings, disease_embeddings, index_mapping, df, case_index, disease_index = load_embeddings(df)
        Config.init_toxicity_model()

        patient_data = [
            {"name": "Anwar", "symptoms": "", "city": "Peshawar"},
            {"name": "Iqra", "symptoms": "chest pain shortness breath sweating queasiness", "city": "Chiniot"},
            {"name": "Sumair", "symptoms": "frequent urination increased thirst blurred vision lassitude", "city": "Karachi"},
            {"name": "Moafi", "symptoms": "red patch itchy skin edema", "city": "Lahore"}
        ]

        predictions = []
        for patient in tqdm(patient_data, desc="Processing patients"):
            response = inference(
                patient, df, doctor_similarity_df, case_embeddings, disease_embeddings,
                model, tokenizer, device, index_mapping, case_index, disease_index
            )
            predictions.append(response)

            print(f"\nResults for {patient['name']}:")
            print(f"Condition: {response['condition']}")
            for disease, confidence in response['disease_confidences']:
                print(Config.CONDITION_INTRO.format(disease.capitalize(), confidence))
            print("\nRecommended Doctors:")
            top_k_recs = [rec for rec in response['recommendations'] if rec['disease'] != 'exploratory'][:Config.TOP_K]
            for rec in top_k_recs:
                print(rec['recommendation_text'])
            exploratory_recs = [rec for rec in response['recommendations'] if rec['disease'] == 'exploratory']
            if exploratory_recs:
                print(f"\n{Config.EXPLORATORY_INTRO.format(patient['city'])}")
                for rec in exploratory_recs[:Config.EXPLORATORY_K]:
                    print(rec['recommendation_text'])
            print(f"\nAdvice: {response['advice']}\n")

        metrics = compute_metrics(
            predictions, df, patient['city'],
            Config.disease_specialist_dict.get(predictions[0]['condition'].lower(), 'general physician'),
            model, tokenizer, device, doctor_similarity_df
        )

        plots = plot_visualizations(df, case_embeddings, metrics)

        logger.info("Processing completed successfully.")
        with open(os.path.join(BASE_DIR, "predictions.json"), "w") as f:
            json.dump(predictions, f, indent=2)
        return predictions, metrics, plots

    except Exception as e:
        logger.error(f"Error in main: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Main error: {e}\n")
        raise

if __name__ == "__main__":
    main()