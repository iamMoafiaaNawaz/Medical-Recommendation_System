import os
import sqlite3
import json
import time
import logging
import gc
import random
import base64
from io import BytesIO
from collections import defaultdict
from typing import Dict, List, Tuple, Optional
import pandas as pd
import numpy as np
import nltk
from nltk.translate.bleu_score import sentence_bleu
from rouge_score import rouge_scorer
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from torch.utils.data import Dataset
from transformers.trainer import Trainer, EvalPrediction
from sklearn.metrics import precision_score, recall_score, f1_score, mean_squared_error, roc_curve, auc, precision_recall_curve
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments
from huggingface_hub import login
from peft import get_peft_model, LoraConfig
import detoxify
from tqdm import tqdm

# Download NLTK data
nltk.download('punkt', quiet=True)
nltk.download('wordnet', quiet=True)

# Configure logging
BASE_DIR = "/home/f223085/iqra/pkkaDeepSeek/last"
os.makedirs(BASE_DIR, exist_ok=True)
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
file_handler = logging.FileHandler(os.path.join(BASE_DIR, "recommender.log"))
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Configuration class
class Config:
    HF_TOKEN = "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"
    DATA_PATH = "/home/f223085/iqra/pd.csv"
    MODEL_NAME = "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B"
    MODEL_DIR = os.path.join(BASE_DIR, "fine_tuned_model")
    EMBEDDINGS_PATH = os.path.join(BASE_DIR, "case_embeddings.npy")
    DB_PATH = os.path.join(BASE_DIR, "user_profiles.db")
    MAX_LENGTH = 128
    NUM_EPOCHS = 3
    TRAIN_BATCH_SIZE = 2
    LEARNING_RATE = 3e-4
    TOP_K = 5
    BATCH_SIZE = 4
    SIMILARITY_THRESHOLD = 0.7
    TOXICITY_MODEL = None
    EMBEDDING_DIM = None
    LORA_R = 16
    LORA_ALPHA = 32
    LORA_DROPOUT = 0.1

    @staticmethod
    def init_toxicity_model():
        try:
            Config.TOXICITY_MODEL = detoxify.Detoxify('original')
            logger.info("Detoxify model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Detoxify model: {e}")
            with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                f.write(f"Failed to load Detoxify model: {e}\n")

# Initialize environment
def init_environment():
    os.makedirs("/home/f223085/hf_cache", exist_ok=True)
    os.makedirs("/home/f223085/nltk_data", exist_ok=True)
    os.environ["http_proxy"] = "http://192.168.150.150:3128"
    os.environ["https_proxy"] = "http://192.168.150.150:3128"
    nltk.download('wordnet', download_dir="/home/f223085/nltk_data", quiet=True)
    logger.info("NLTK wordnet downloaded successfully.")

# Initialize user profile database
def init_database():
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                name TEXT UNIQUE,
                gender TEXT,
                city TEXT,
                past_symptoms TEXT,
                ratings TEXT
            )
        """)
        users = [
            ("1", "Iqra", "Female", "Chiniot", "[]", "{}"),
            ("2", "Moafi", "Female", "Lahore", "[]", "{}"),
            ("3", "Sumair", "Male", "Quetta", "[]", "{}"),
            ("4", "Anwar", "Male", "Peshawar", "[]", "{}")
        ]
        cursor.executemany("INSERT OR IGNORE INTO users VALUES (?, ?, ?, ?, ?, ?)", users)
        conn.commit()
    logger.info("User profile database initialized.")

# Load and preprocess data
def preprocess_data() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    try:
        df = pd.read_csv(Config.DATA_PATH)
        if df.empty:
            raise ValueError("Dataset is empty.")
        logger.info(f"Dataset loaded with {len(df)} rows.")
    except FileNotFoundError as e:
        logger.error(f"File {Config.DATA_PATH} not found: {e}")
        raise

    required_columns = [
        "CommonAgeGroup", "Sex", "Severity", "Specialist", "Name", "Address/Details",
        "City", "Rating", "Mapped_Category", "Processed_Symptoms", "Processed_Disease",
        "Processed_Treatment"
    ]
    if not all(col in df.columns for col in required_columns):
        raise ValueError("Missing required columns in pd.csv.")

    df = df.dropna(subset=["Processed_Symptoms", "Processed_Disease", "Processed_Treatment"])
    df["Rating"] = df["Rating"].astype(float)
    df = df.sample(frac=0.5, random_state=42)
    df.to_pickle(os.path.join(BASE_DIR, "processed_data.pkl"))

    interaction_matrix = df.pivot_table(
        index="Processed_Symptoms", columns="Name", values="Rating", aggfunc='mean', fill_value=0
    )
    doctor_similarity = cosine_similarity(interaction_matrix.T)
    doctor_similarity_df = pd.DataFrame(
        doctor_similarity, index=interaction_matrix.columns, columns=interaction_matrix.columns
    )
    logger.info("Dataset processed and doctor similarity matrix created.")
    return df, doctor_similarity_df, interaction_matrix

# Custom dataset for fine-tuning
class MedicalDataset(Dataset):
    def __init__(self, df: pd.DataFrame, tokenizer: AutoTokenizer, max_length: int):
        self.df = df
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]
        input_text = (
            f"Symptoms: {row['Processed_Symptoms']}. Age: {row['CommonAgeGroup']}. "
            f"Sex: {row['Sex']}. Severity: {row['Severity']}."
        )
        target_text = (
            f"Condition: {row['Processed_Disease']}. Doctor: {row['Name']}. "
            f"Treatment: {row['Processed_Treatment']}. Specialist: {row['Specialist']}."
        )
        inputs = self.tokenizer(
            input_text, max_length=self.max_length, padding="max_length",
            truncation=True, return_tensors="pt"
        )
        targets = self.tokenizer(
            target_text, max_length=self.max_length, padding="max_length",
            truncation=True, return_tensors="pt"
        )
        labels = targets["input_ids"].clone()
        labels[labels == self.tokenizer.pad_token_id] = -100
        return {
            "input_ids": inputs["input_ids"].squeeze(),
            "attention_mask": inputs["attention_mask"].squeeze(),
            "labels": labels.squeeze()
        }

# Custom Trainer
class CustomTrainer(Trainer):
    def compute_metrics(self, eval_pred: EvalPrediction) -> Dict[str, float]:
        predictions, label_ids = eval_pred.predictions, eval_pred.label_ids
        if isinstance(predictions, tuple):
            predictions = predictions[0]

        # Convert to numpy arrays for easier manipulation
        predictions = np.array(predictions)
        label_ids = np.array(label_ids)

        # Compute classification metrics
        if predictions.ndim == 3:  # Shape: (batch_size, seq_len, vocab_size)
            predictions_class = np.argmax(predictions, axis=-1)  # Shape: (batch_size, seq_len)
        else:
            predictions_class = predictions
        predictions_class = predictions_class.flatten()
        label_ids_flat = label_ids.flatten()

        # Filter valid indices (exclude -100 padding tokens)
        valid_indices = label_ids_flat != -100
        predictions_class = predictions_class[valid_indices]
        label_ids_flat = label_ids_flat[valid_indices]

        metrics = {
            "accuracy": float(np.mean(predictions_class == label_ids_flat)) if len(predictions_class) > 0 else 0.0,
            "precision": float(precision_score(label_ids_flat, predictions_class, average="weighted", zero_division=0)) if len(predictions_class) > 0 else 0.0,
            "recall": float(recall_score(label_ids_flat, predictions_class, average="weighted", zero_division=0)) if len(predictions_class) > 0 else 0.0,
            "f1": float(f1_score(label_ids_flat, predictions_class, average="weighted", zero_division=0)) if len(predictions_class) > 0 else 0.0
        }

        # Compute perplexity
        if len(valid_indices) > 0 and np.any(valid_indices):
            try:
                logits = torch.tensor(predictions, dtype=torch.float32)
                labels = torch.tensor(label_ids, dtype=torch.long)

                if logits.ndim == 3 and labels.ndim == 2:
                    batch_size, seq_len, vocab_size = logits.shape
                    if labels.shape[0] != batch_size:
                        logger.warning(f"Labels batch size {labels.shape[0]} does not match logits batch size {batch_size}. Skipping perplexity.")
                        metrics["perplexity"] = float('inf')
                    else:
                        # Flatten only valid tokens
                        valid_mask = labels != -100
                        logits_flat = logits[valid_mask].view(-1, vocab_size)
                        labels_flat = labels[valid_mask].view(-1)

                        if logits_flat.shape[0] == 0:
                            metrics["perplexity"] = float('inf')
                        else:
                            loss_fct = torch.nn.CrossEntropyLoss(ignore_index=-100)
                            loss = loss_fct(logits_flat, labels_flat).item()
                            metrics["perplexity"] = float(np.exp(loss))
                else:
                    logger.warning(f"Unexpected shapes: logits {logits.shape}, labels {labels.shape}. Skipping perplexity.")
                    metrics["perplexity"] = float('inf')
            except Exception as e:
                logger.error(f"Perplexity computation failed: {e}")
                metrics["perplexity"] = float('inf')
        else:
            metrics["perplexity"] = float('inf')

        return metrics

# Load tokenizer and model
def load_tokenizer_and_model():
    login(token=Config.HF_TOKEN)
    tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_NAME, cache_dir="/home/f223085/hf_cache")
    model = AutoModelForCausalLM.from_pretrained(
        Config.MODEL_NAME, cache_dir="/home/f223085/hf_cache",
        device_map="cuda" if torch.cuda.is_available() else "cpu",
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else torch.float16,
        low_cpu_mem_usage=True
    )
    model.gradient_checkpointing_enable()
    lora_config = LoraConfig(
        r=Config.LORA_R, lora_alpha=Config.LORA_ALPHA,
        target_modules=[f"model.layers.{i}.self_attn.q_proj" for i in range(24, 28)] +
                       [f"model.layers.{i}.self_attn.v_proj" for i in range(24, 28)],
        lora_dropout=Config.LORA_DROPOUT, bias="none", task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_config)
    for name, param in model.named_parameters():
        if "lora" in name.lower():
            param.requires_grad = True
        else:
            param.requires_grad = False
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    logger.info(f"Trainable params: {trainable_params} | Total params: {total_params} | Trainable%: {100 * trainable_params / total_params:.4f}")
    model.train()
    Config.EMBEDDING_DIM = model.config.hidden_size
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return tokenizer, model, device

# Fine-tune model
def fine_tune_model(model: AutoModelForCausalLM, tokenizer: AutoTokenizer, df: pd.DataFrame,
                    learning_rate: float, device: torch.device) -> CustomTrainer:
    try:
        train_size = int(0.8 * len(df))
        if train_size == 0 or len(df) - train_size < 50:
            raise ValueError("Dataset too small for train-validation split.")
        train_df = df[:train_size]
        val_df = df[train_size:].sample(n=min(50, len(df[train_size:])), random_state=42)
        train_dataset = MedicalDataset(train_df, tokenizer, Config.MAX_LENGTH)
        val_dataset = MedicalDataset(val_df, tokenizer, Config.MAX_LENGTH)

        use_bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        use_fp16 = torch.cuda.is_available() and not use_bf16

        training_args = TrainingArguments(
            output_dir=os.path.join(BASE_DIR, "results"),
            per_device_train_batch_size=Config.TRAIN_BATCH_SIZE,
            per_device_eval_batch_size=Config.TRAIN_BATCH_SIZE,
            num_train_epochs=Config.NUM_EPOCHS,
            learning_rate=learning_rate,
            eval_strategy="epoch",
            save_strategy="epoch",
            logging_steps=100,
            save_total_limit=1,
            report_to="none",
            gradient_accumulation_steps=8,
            fp16=use_fp16,
            bf16=use_bf16,
            load_best_model_at_end=True,
            metric_for_best_model="eval_f1",
            optim="adamw_8bit",
            dataloader_num_workers=4,
            dataloader_pin_memory=True,
            max_grad_norm=0.5,
            torch_compile=False,
            resume_from_checkpoint=True  # Resume from latest checkpoint
        )

        trainer = CustomTrainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            compute_metrics=lambda eval_pred: CustomTrainer.compute_metrics(None, eval_pred)
        )

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            logger.info(f"GPU memory before training: {torch.cuda.memory_allocated(device) / 1e9:.2f} GB")

        trainer.train()
        logger.info(f"Peak GPU memory during training: {torch.cuda.max_memory_allocated(device) / 1e9:.2f} GB")

        eval_results = trainer.evaluate()
        with open(os.path.join(BASE_DIR, "train_eval_results.json"), "w") as f:
            json.dump(eval_results, f, indent=2)
        model.save_pretrained(Config.MODEL_DIR)
        tokenizer.save_pretrained(Config.MODEL_DIR)
        logger.info("Fine-tuned LoRA model and tokenizer saved.")
        return trainer
    except Exception as e:
        logger.error(f"Failed to fine-tune model: {e}")
        raise

# Extract semantic features
def extract_semantic_features(text: str, model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
                             device: torch.device) -> np.ndarray:
    with torch.no_grad():
        inputs = tokenizer(
            text, return_tensors="pt", max_length=Config.MAX_LENGTH,
            truncation=True, padding=True
        ).to(device)
        outputs = model(**inputs, output_hidden_states=True)
        features = torch.mean(outputs.hidden_states[-1], dim=1).cpu().numpy().flatten()
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return features

# Generate embeddings
def generate_case_embeddings(df: pd.DataFrame, model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
                            device: torch.device) -> np.ndarray:
    model.eval()
    embeddings = []
    for i in tqdm(range(0, len(df), Config.BATCH_SIZE), desc="Generating case embeddings"):
        batch_df = df[i:i + Config.BATCH_SIZE]
        batch_embeddings = []
        for _, row in batch_df.iterrows():
            input_text = (
                f"Symptoms: {row['Processed_Symptoms']}. Age: {row['CommonAgeGroup']}. "
                f"Sex: {row['Sex']}. Severity: {row['Severity']}."
            )
            embedding = extract_semantic_features(input_text, model, tokenizer, device)
            batch_embeddings.append(embedding)
        embeddings.extend(batch_embeddings)
        logger.info(f"Processed embedding batch {i // Config.BATCH_SIZE + 1}")
    embeddings = np.array(embeddings, dtype=np.float32)
    np.save(Config.EMBEDDINGS_PATH, embeddings)
    logger.info(f"Generated embeddings with shape: {embeddings.shape}")
    return embeddings

def generate_disease_embeddings(df: pd.DataFrame, model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
                               device: torch.device) -> np.ndarray:
    model.eval()
    unique_diseases = df["Processed_Disease"].unique()
    disease_embeddings = []
    for disease in tqdm(unique_diseases, desc="Generating disease embeddings"):
        input_text = f"Disease: {disease}"
        embedding = extract_semantic_features(input_text, model, tokenizer, device)
        disease_embeddings.append(embedding)
    disease_embeddings = np.array(disease_embeddings, dtype=np.float32)
    np.save(os.path.join(BASE_DIR, "disease_embeddings.npy"), disease_embeddings)
    return disease_embeddings

# Preprocess input
def preprocess_input(patient_data: Dict) -> str:
    symptoms = patient_data["symptom"].lower().strip()
    history = patient_data.get("history", "").lower().strip()
    labs = patient_data.get("labs", "").lower().strip()
    return f"Symptoms: {symptoms}. History: {history}. Labs: {labs}"

# Compute metrics
def compute_metrics(recommendations: Dict, df: pd.DataFrame, case_embeddings: np.ndarray,
                    model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device,
                    top_k: int = Config.TOP_K) -> Tuple[Dict, List, List, List]:
    y_true = []
    y_pred = []
    y_scores = []
    latencies = []
    toxicities = []
    ranks = []
    recommended_items = set()
    total_items = len(df["Processed_Disease"].unique())
    item_popularity = df["Processed_Disease"].value_counts().to_dict()
    similarities = []
    personalization_scores = []
    robustness_scores = []
    ctr_simulations = []
    bleu_scores = []
    rouge_scores = []
    meteor_scores = []
    cold_start_metrics = {"precision": [], "recall": [], "f1": []}

    scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)

    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for name, rec in recommendations.items():
            symptoms = rec["symptoms"]
            predicted_conditions = [cond["Condition"] for cond in rec["likely_conditions"]]
            predicted_treatments = [cond["Treatment"] for cond in rec["likely_conditions"]]
            scores = [cond["Score"] for cond in rec["likely_conditions"]]
            actual_conditions = df[df["Processed_Symptoms"].str.lower() == symptoms.lower()]["Processed_Disease"].values
            actual_treatments = df[df["Processed_Symptoms"].str.lower() == symptoms.lower()]["Processed_Treatment"].values
            actual_condition = actual_conditions[0] if len(actual_conditions) > 0 else "Unknown"
            actual_treatment = actual_treatments[0] if len(actual_treatments) > 0 else "Unknown"

            y_true.append(actual_condition)
            y_pred.append(predicted_conditions[:top_k] if predicted_conditions else ["Unknown"])
            y_scores.append(scores[:top_k] if scores else [0.0] * top_k)
            latencies.append(rec["latency"])

            if Config.TOXICITY_MODEL:
                for cond in rec["likely_conditions"][:top_k]:
                    try:
                        toxicities.append(float(Config.TOXICITY_MODEL.predict(cond["Treatment"])["toxicity"]))
                    except Exception:
                        toxicities.append(0.0)

            for i, cond in enumerate(predicted_conditions[:top_k], 1):
                if cond == actual_condition:
                    ranks.append(i)
                    break
            else:
                ranks.append(0)

            recommended_items.update(predicted_conditions[:top_k])
            similarities.extend([item_popularity.get(cond, 1) / sum(item_popularity.values()) for cond in predicted_conditions[:top_k]])

            cursor.execute("SELECT past_symptoms FROM users WHERE name=?", (name,))
            result = cursor.fetchone()
            past_symptoms = json.loads(result[0]) if result else []
            personalization_scores.append(len(set(predicted_conditions[:top_k]).intersection(set(past_symptoms))) / top_k if past_symptoms else 0)

            variations = [symptoms, symptoms.replace(",", ", "), symptoms.upper()]
            robust_preds = []
            for var in variations:
                norm_text = preprocess_input({"symptom": var, "history": "", "labs": ""})
                emb = extract_semantic_features(norm_text, model, tokenizer, device)
                sims = cosine_similarity([emb], case_embeddings)[0]
                top_idx = np.argsort(sims)[-top_k:][::-1]
                robust_preds.append([df.iloc[i]["Processed_Disease"] for i in top_idx])
            robustness_scores.append(float(np.mean([len(set(predicted_conditions[:top_k]).intersection(set(rp))) / top_k for rp in robust_preds])))

            ctr_simulations.append(random.random() < 0.1 * len(predicted_conditions[:top_k]))

            if actual_treatment != "Unknown":
                for pred_treatment in predicted_treatments[:top_k]:
                    ref_tokens = nltk.word_tokenize(actual_treatment.lower())
                    pred_tokens = nltk.word_tokenize(pred_treatment.lower())
                    bleu_scores.append(sentence_bleu([ref_tokens], pred_tokens, weights=(0.5, 0.5)))
                    rouge = scorer.score(actual_treatment, pred_treatment)
                    rouge_scores.append(rouge['rouge1'].f1)
                    meteor_scores.append((bleu_scores[-1] + rouge_scores[-1]) / 2)

            if name == "Anwar" and not past_symptoms:
                relevant = len(set(predicted_conditions[:top_k]).intersection(set([actual_condition])))
                cold_start_metrics["precision"].append(relevant / top_k)
                cold_start_metrics["recall"].append(relevant / 1.0 if actual_condition != "Unknown" else 0)
                cold_start_metrics["f1"].append(2 * (relevant / top_k * relevant) / (relevant / top_k + relevant) if relevant > 0 else 0)

    def dcg(scores, k):
        return sum([(2 ** rel - 1) / np.log2(i + 2) for i, rel in enumerate(scores[:k])])

    precision_k = float(np.mean([len(set(p[:top_k]).intersection({t})) / top_k for p, t in zip(y_pred, y_true)]))
    recall_k = float(np.mean([len(set(p[:top_k]).intersection({t})) / 1 for p, t in zip(y_pred, y_true) if t != "Unknown"] or [0.0]))
    f1 = float(f1_score(
        [t for t in y_true if t != "Unknown"],
        [p[0] for p in y_pred if p and p[0] != "Unknown"],
        average="weighted",
        zero_division=0
    ) if any(t != "Unknown" for t in y_true) else 0)
    mse = float(mean_squared_error([1 if t != "Unknown" else 0.0 for t in y_true], [1 if p[0] != "Unknown" else 0 for p in y_pred]))
    ndcg_k = float(np.mean([dcg([1 if p == t else 0 for p in pred[:top_k]], top_k) / dcg([1] * top_k) for pred, t in zip(y_pred, y_true)]))
    map_k = float(np.mean([sum([1 / (i + 1) for i, p in enumerate(pred[:top_k]) if p == t]) / top_k for pred, t in zip(y_pred, y_true)]))
    hit_rate_k = float(np.mean([1 if t in p[:top_k] else 0 for p, t in zip(y_pred, y_true)]))
    mrr = float(np.mean([1 / r if r > 0 else 0 for r in ranks]))
    coverage = float(len(recommended_items) / total_items)
    novelty = float(1 - np.mean(similarities) if similarities else 0.0)
    diversity = float(1 - np.mean([
        cosine_similarity([case_embeddings[i]], [case_embeddings[j]])[0][0]
        for i in range(len(case_embeddings))
        for j in range(i + 1, min(len(case_embeddings), i + 10))
        if j < len(case_embeddings)
    ]) if len(case_embeddings) > 1 else 0.0)
    serendipity = float(novelty * diversity)
    avg_toxicity = float(np.mean(toxicities) if toxicities else 0.0)
    hallucination_rate = float(np.mean([1 if p[0] not in df["Processed_Disease"].values else 0.0 for p in y_pred]))
    personalization = float(np.mean(personalization_scores) if personalization_scores else 0.0)
    robustness = float(np.mean(robustness_scores) if robustness_scores else 0.0)
    ctr = float(np.mean(ctr_simulations) if ctr_simulations else 0.0)
    avg_bleu = float(np.mean(bleu_scores) if bleu_scores else 0.0)
    avg_rouge = float(np.mean(rouge_scores) if rouge_scores else 0.0)
    avg_meteor = float(np.mean(meteor_scores) if meteor_scores else 0.0)
    cold_start_precision = float(np.mean(cold_start_metrics["precision"]) if cold_start_metrics["precision"] else 0.0)
    cold_start_recall = float(np.mean(cold_start_metrics["recall"]) if cold_start_metrics["recall"] else 0.0)
    cold_start_f1 = float(np.mean(cold_start_metrics["f1"]) if cold_start_metrics["f1"] else 0.0)
    explainability = float(0.05)  # Placeholder

    metrics = {
        "precision@k": precision_k,
        "recall@k": recall_k,
        "f1_score": f1,
        "mse": mse,
        "rmse": float(np.sqrt(mse)),
        "ndcg@k": ndcg_k,
        "map@k": map_k,
        "hit_rate_k": hit_rate_k,
        "mrr": mrr,
        "coverage": coverage,
        "novelty": novelty,
        "serendipity": serendipity,
        "diversity": diversity,
        "toxicity": avg_toxicity,
        "hallucination_rate": hallucination_rate,
        "personalization": personalization,
        "robustness": robustness,
        "ctr": ctr,
        "bleu": avg_bleu,
        "rouge": avg_rouge,
        "meteor": avg_meteor,
        "cold_start_precision": cold_start_precision,
        "cold_start_recall": cold_start_recall,
        "cold_start_f1": cold_start_f1,
        "explainability": explainability,
        "avg_latency": float(np.mean(latencies)) if latencies else 0.0
    }

    with open(os.path.join(BASE_DIR, "inference_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=4)
    return metrics, y_true, y_pred, y_scores

# Inference with collaborative filtering
def inference(patient_data: List[Dict], model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
              df: pd.DataFrame, doctor_similarity_df: pd.DataFrame, case_embeddings: np.ndarray,
              disease_embeddings: np.ndarray, device: torch.device) -> Dict:
    model.eval()
    recommendations = {}
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for patient in patient_data:
            name = patient["name"]
            symptoms = patient.get("symptom", "").strip()
            city_filter = patient.get("city", "").lower().strip()
            print(f"\nHello {name}, we're here to help with your {'symptoms (' + symptoms + ')' if symptoms else 'city (' + city_filter + ')'}.")
            print("Analyzing your input to find the best care options...")

            start_time = time.time()
            logger.info(f"Processing patient: {name}, Symptoms: {symptoms}, City: {city_filter}")

            likely_conditions = []
            other_conditions = []
            seen_conditions = set()
            seen_doctors = []

            cursor.execute("SELECT past_symptoms FROM users WHERE name=?", (name,))
            result = cursor.fetchone()
            past_symptoms = json.loads(result[0]) if result else []

            # NEW: Handle city-only input
            if not symptoms and city_filter:
                # Top k doctors from the specified city
                city_doctors = df[df["City"].str.lower() == city_filter].sort_values(by="Rating", ascending=False)
                for _, row in city_doctors.head(Config.TOP_K).iterrows():
                    if row["Name"] not in seen_doctors:
                        seen_doctors.append(row["Name"])
                        seen_conditions.add(row["Processed_Disease"])
                        likely_conditions.append({
                            "Condition": row["Processed_Disease"],
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(row["Rating"]) / 5.0  # Normalize rating to [0,1]
                        })
                
                # Top k doctors from other cities
                other_city_doctors = df[df["City"].str.lower() != city_filter].sort_values(by="Rating", ascending=False)
                for _, row in other_city_doctors.head(Config.TOP_K).iterrows():
                    if row["Name"] not in seen_doctors:
                        seen_doctors.append(row["Name"])
                        seen_conditions.add(row["Processed_Disease"])
                        other_conditions.append({
                            "Condition": row["Processed_Disease"],
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(row["Rating"]) / 5.0 * 0.9  # Slightly lower score for other cities
                        })
            # END NEW

            # Existing symptom-based logic
            elif symptoms:
                norm_text = preprocess_input(patient)
                patient_embedding = extract_semantic_features(norm_text, model, tokenizer, device)
                similarities = cosine_similarity([patient_embedding], case_embeddings)[0]
                top_indices = np.argsort(similarities)[-Config.TOP_K*2:][::-1]
                similar_cases = df.iloc[top_indices]

                filtered_cases = similar_cases[similar_cases["City"].str.lower() == city_filter] if city_filter else similar_cases
                if filtered_cases.empty and city_filter:
                    filtered_cases = df[df["City"].str.lower() == city_filter].sample(n=min(len(df), Config.TOP_K), random_state=42) if len(df) > 0 else df

                for idx in filtered_cases.sort_values(by="Rating", ascending=False).index:
                    row = df.iloc[idx]
                    if row["Processed_Disease"] not in seen_conditions and row["Name"] not in seen_doctors:
                        seen_conditions.add(row["Processed_Disease"])
                        seen_doctors.append(row["Name"])
                        likely_conditions.append({
                            "Condition": row["Processed_Disease"],
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(similarities[idx]) if idx in top_indices else 0.5
                        })
                        if len(likely_conditions) >= Config.TOP_K:
                            break

                disease_sims = cosine_similarity([patient_embedding], disease_embeddings)[0]
                top_disease_idx = np.argsort(disease_sims)[-3:][::-1]
                unique_diseases = df["Processed_Disease"].unique()
                for idx in top_disease_idx:
                    disease = unique_diseases[idx]
                    if disease not in seen_conditions:
                        seen_conditions.add(disease)
                        disease_rows = df[
                            (df["Processed_Disease"] == disease) &
                            (df["City"].str.lower() == city_filter if city_filter else True)
                        ]
                        if not disease_rows.empty:
                            row = disease_rows.sort_values(by="Rating", ascending=False).iloc[0]
                            if row["Name"] not in seen_doctors:
                                seen_doctors.append(row["Name"])
                                other_conditions.append({
                                    "Condition": disease,
                                    "Doctor": row["Name"],
                                    "Treatment": row["Processed_Treatment"],
                                    "Specialist": row["Specialist"],
                                    "Rating": float(row["Rating"]),
                                    "Address": row["Address/Details"],
                                    "City": row["City"],
                                    "Score": float(disease_sims[idx]) * 0.8
                                })

            # Collaborative filtering for additional recommendations
            cf_conditions = []
            content_doctors = [cond["Doctor"] for cond in likely_conditions]
            for doctor in content_doctors:
                if doctor in doctor_similarity_df.columns:
                    similar_doctors = doctor_similarity_df[doctor].sort_values(ascending=False).index.tolist()
                    for sim_doc in similar_doctors[:3]:
                        if sim_doc != doctor and sim_doc not in seen_doctors:
                            sim_row = df[df["Name"] == sim_doc]
                            if city_filter:
                                sim_row = sim_row[sim_row["City"].str.lower() == city_filter]
                            if not sim_row.empty:
                                sim_row = sim_row.iloc[0]
                                condition = sim_row["Processed_Disease"]
                                if condition not in seen_conditions:
                                    seen_conditions.add(condition)
                                    seen_doctors.append(sim_row["Name"])
                                    cf_conditions.append({
                                        "Condition": condition,
                                        "Doctor": sim_doc,
                                        "Treatment": sim_row["Processed_Treatment"],
                                        "Specialist": sim_row["Specialist"],
                                        "Rating": float(sim_row["Rating"]),
                                        "Address": sim_row["Address/Details"],
                                        "City": sim_row["City"],
                                        "Score": float(doctor_similarity_df.loc[doctor, sim_doc]) * 0.9
                                    })

            print("Selecting the best doctors and treatments for you...")
            print("Done! Here are your personalized recommendations.")

            likely_conditions_names = list(dict.fromkeys([cond["Condition"] for cond in likely_conditions]))
            other_conditions_names = list(dict.fromkeys([cond["Condition"] for cond in other_conditions + cf_conditions]))
            specialists = defaultdict(list)
            for cond in likely_conditions + other_conditions + cf_conditions:
                specialists[cond["Specialist"]].append(cond["Doctor"])

            # NEW: Updated output for city-only case
            if not symptoms and city_filter:
                print(f"\nTop Doctors in {city_filter.capitalize()}:")
                print(", ".join([cond['Doctor'] for cond in likely_conditions]) if likely_conditions else "No doctors found in this city.")
                print(f"\nTop Doctors in Other Cities:")
                print(", ".join([cond['Doctor'] for cond in other_conditions]) if other_conditions else "No additional doctors found.")
            else:
                print("\nConditions That May Match Your Symptoms:")
                print(", ".join(likely_conditions_names) if likely_conditions_names else "No specific conditions found.")
                print("\nOther Conditions You May Be Suffering From:")
                print(", ".join(other_conditions_names) if other_conditions_names else "Unknown")
                print("\nRecommended Specialists:")
                printed_specialists = set()
                if symptoms:
                    for symptom in symptoms.split(","):
                        symptom = symptom.strip()
                        if symptom:
                            symptom_conditions = df[
                                df["Processed_Symptoms"].str.contains(symptom.lower(), case=False, na=False)
                            ]["Processed_Disease"].tolist()
                            for cond in sorted(set(symptom_conditions)):
                                for spec, docs in specialists.items():
                                    for doc in docs:
                                        recommendation = f"For {symptom}, we recommend consulting a {spec} like {doc} in {city_filter or 'any city'}."
                                        if recommendation not in printed_specialists:
                                            print(f"- {recommendation}")
                                            printed_specialists.add(recommendation)
            # END NEW

            print(f"\nTop Doctor Recommendations in {city_filter.capitalize() if city_filter else 'Any City'}:")
            for cond in likely_conditions:
                print(f"Condition: {cond['Condition']}")
                print(f"Doctor: {cond['Doctor']} ({cond['Specialist']})")
                print(f"Treatment: {cond['Treatment']}")
                print(f"Rating: {cond['Rating']} stars")
                print(f"Location: {cond['Address']}, {cond['City']}")
                print("-" * 40)

            if other_conditions + cf_conditions:
                print(f"\nAdditional Recommendations in {'Other Cities' if not symptoms and city_filter else city_filter.capitalize() if city_filter else 'Any City'}:")
                for cond in other_conditions + cf_conditions:
                    print(f"Condition: {cond['Condition']}")
                    print(f"Doctor: {cond['Doctor']} ({cond['Specialist']})")
                    print(f"Treatment: {cond['Treatment']}")
                    print(f"Rating: {cond['Rating']} stars")
                    print(f"Location: {cond['Address']}, {cond['City']}")
                    print("-" * 40)

            cursor.execute("SELECT past_symptoms, ratings FROM users WHERE name=?", (name,))
            user_data = cursor.fetchone()
            if user_data:
                past_symptoms = json.loads(user_data[0])
                ratings = json.loads(user_data[1])
                if symptoms:
                    past_symptoms.append(symptoms)
                for cond in likely_conditions + other_conditions + cf_conditions:
                    ratings[cond["Doctor"]] = ratings.get(cond["Doctor"], float(cond["Rating"]))
                cursor.execute(
                    "UPDATE users SET past_symptoms=?, ratings=? WHERE name=?",
                    (json.dumps(past_symptoms), json.dumps(ratings), name)
                )
                conn.commit()

            recommendations[name] = {
                "symptoms": symptoms,
                "city": city_filter,
                "likely_conditions": likely_conditions,
                "other_conditions": other_conditions + cf_conditions,
                "latency": float(time.time() - start_time)
            }
    return recommendations

# Plot visualizations
def plot_visualizations(
    trainer: CustomTrainer, y_true: List, y_pred: List, y_scores: List,
    df: pd.DataFrame, interaction_matrix: pd.DataFrame, case_embeddings: np.ndarray,
    learning_rates: List[float], metrics: Dict
) -> Dict[str, str]:
    plots_dir = os.path.join(BASE_DIR, "plots")
    os.makedirs(plots_dir, exist_ok=True)

    def plot_to_base64():
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        buf.seek(0)
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        plt.close()
        return img_base64

    plots = {}
    log_history = trainer.state.log_history

    sns.set_style("darkgrid")
    palette = sns.color_palette("husl", 3)

    # 1. Training and Validation Loss Curves
    train_losses = [log["loss"] for log in log_history if "loss" in log]
    val_losses = [log["eval_loss"] for log in log_history if "eval_loss" in log]
    epochs = list(range(1, len(val_losses) + 1))
    plt.figure(figsize=(10, 6))
    sns.lineplot(x=epochs[:len(train_losses)], y=train_losses, label="Training Loss", color=palette[0], linewidth=2.5)
    sns.lineplot(x=epochs, y=val_losses, label="Validation Loss", color=palette[1], linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Training and Validation Loss per Epoch")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "loss_curve.png"))
    plots["loss_curve"] = plot_to_base64()

    # 2. Training and Validation Accuracy Curves
    train_acc = [log["accuracy"] for log in log_history if "accuracy" in log]
    val_acc = [log["eval_accuracy"] for log in log_history if "eval_accuracy" in log]
    plt.figure(figsize=(10, 6))
    sns.lineplot(x=epochs[:len(train_acc)], y=train_acc, label="Training Accuracy", color=palette[0], linewidth=2.5)
    sns.lineplot(x=epochs, y=val_acc, label="Validation Accuracy", color=palette[1], linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title("Training and Validation Accuracy per Epoch")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "accuracy_curve.png"))
    plots["accuracy"] = plot_to_base64()

    # 3. Precision@k-Recall Curve
    y_true_binary = [1 if t != "Unknown" else 0 for t in y_true]
    y_scores_flat = [s[0] if s else 0.0 for s in y_scores]
    precision, recall, _ = precision_recall_curve(y_true_binary, y_scores_flat)
    plt.figure(figsize=(8, 6))
    sns.lineplot(x=recall, y=precision, color=palette[0], linewidth=2.5)
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision@k-Recall Curve")
    plt.savefig(os.path.join(plots_dir, "precision_recall_curve.png"))
    plots["precision_recall"] = plot_to_base64()

    # 4. ROC Curve
    fpr, tpr, _ = roc_curve(y_true_binary, y_scores_flat)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(8, 6))
    sns.lineplot(x=fpr, y=tpr, color=palette[0], linewidth=2.5, label=f"ROC Curve (AUC: {roc_auc:.2f})")
    plt.plot([0, 1], [0, 1], color='gray', linestyle='--', alpha=0.5)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "roc_curve.png"))
    plots["roc_curve"] = plot_to_base64()

    # 5. Cumulative Gain and DCG
    dcg_scores = []
    for scores in y_scores:
        dcg_k = sum([(2 ** s - 1) / np.log2(i + 2) for i, s in enumerate(scores[:Config.TOP_K])])
        dcg_scores.append(dcg_k)
    plt.figure(figsize=(8, 6))
    sns.histplot(x=dcg_scores, color=palette[0])
    plt.xlabel("DCG@k")
    plt.ylabel("Frequency")
    plt.title("Distribution of DCG@k")
    plt.savefig(os.path.join(plots_dir, "dcg_hist.png"))
    plots["dcg"] = plot_to_base64()

    # 6. MAP Plot
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, [metrics["map@k"] for _ in epochs], color=palette[0], label="MAP@k", linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("MAP@k")
    plt.title("Mean Average Precision @k Over Epochs")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "map_k_curve.png"))
    plots["map_k"] = plot_to_base64()

    # 7. Perplexity Curve
    perplexities = [log["eval_perplexity"] for log in log_history if "eval_perplexity" in log]
    plt.figure(figsize=(10, 6))
    sns.lineplot(x=epochs[:len(perplexities)], y=perplexities, label="Perplexity", color=palette[1], linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("Perplexity")
    plt.title("Perplexity per Epoch")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "perplexity_curve.png"))
    plots["perplexity"] = plot_to_base64()

    # 8. Training Time per Epoch
    training_times = [log.get("training_time", 0.1) for log in log_history if "epoch" in log]
    plt.figure(figsize=(10, 6))
    sns.lineplot(x=epochs[:len(training_times)], y=training_times, label="Training Time", color=palette[1], linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("Time (seconds)")
    plt.title("Training Time per Epoch")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "training_time_plot.png"))
    plots["training_time"] = plot_to_base64()

    # 9. Loss Breakdown
    plt.figure(figsize=(10, 6))
    sns.lineplot(x=epochs[:len(val_losses)], y=val_losses, label="Total Loss", color=palette[0], linewidth=2.5)
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Loss Breakdown (Collaborative Filtering)")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "loss_breakdown.png"))
    plots["loss_breakdown"] = plot_to_base64()

    # 10. Top@k-N Recommendations
    top_n_metrics = {"Precision@k": metrics["precision@k"], "Recall@k": metrics["recall@k"], "Hit Rate@k": metrics["hit_rate_k"]}
    plt.figure(figsize=(8, 6))
    sns.barplot(x=list(top_n_metrics.keys()), y=list(top_n_metrics.values()), color=palette[0])
    plt.ylabel("Value")
    plt.title("Top-5@k Recommendation Metrics")
    plt.savefig(os.path.join(plots_dir, "top_n_metrics.png"))
    plots["top_n"] = plot_to_base64()

    # 11. Heatmap of interactions
    plt.figure(figsize=(10, 8))
    sns.heatmap(interaction_matrix.head(50), cmap="Blues", annot=False)
    plt.xlabel("Doctors")
    plt.ylabel("Symptoms")
    plt.title("Heatmap of User@k-Item Interactions")
    plt.savefig(os.path.join(plots_dir, "heatmap_plot.png"))
    plots["heatmap"] = plot_to_base64()

    # 12. t@k-SNE visualization
    if len(case_embeddings) > 2:
        tsne = TSNE(n_components=2, random_state=42, n_jobs=-1)
        embeddings_2d = tsne.fit_transform(case_embeddings[:500])
        plt.figure(figsize=(8, 6))
        sns.scatterplot(x=embeddings_2d[:, 0], y=embeddings_2d[:, 1], s=10, color=palette[1], alpha=0.8)
        plt.xlabel("Component 1")
        plt.ylabel("Component 2")
        plt.title("t@k-SNE Visualization of Case Embeddings")
        plt.savefig(os.path.join(plots_dir, "tsne_k_plot.png"))
        plots["tsne_k"] = plot_to_base64()

    # 13. Learning rate curve
    plt.figure(figsize=(8, 6))
    sns.lineplot(x=range(len(learning_rates)), y=learning_rates, label="Learning Rate", color=palette[0], linewidth=2.5)
    plt.xlabel("Iterations")
    plt.ylabel("Learning Rate")
    plt.title("Learning Rate Schedule")
    plt.legend()
    plt.savefig(os.path.join(plots_dir, "learning_rate_plot.png"))
    plots["learning_rate"] = plot_to_base64()

    # 14. Diversity plot
    diversity_scores = [metrics["diversity"] for _ in range(5)]
    plt.figure(figsize=(8, 6))
    sns.barplot(x=list(range(5)), y=diversity_scores, color=palette[0])
    plt.xlabel("Sample")
    plt.ylabel("Diversity Score")
    plt.title("Recommendation Diversity")
    plt.savefig(os.path.join(plots_dir, "diversity_plot.png"))
    plots["diversity_plot"] = plot_to_base64()

    # 15. Cold start evaluation
    cold_start_metrics = {
        "Precision@k": metrics["cold_start_precision"],
        "Recall@k": metrics["cold_start_recall"],
        "F1": metrics["cold_start_f1"]
    }
    plt.figure(figsize=(8, 6))
    sns.barplot(x=list(cold_start_metrics.keys()), y=list(cold_start_metrics.values()), color=palette[0])
    plt.ylabel("Score")
    plt.title("Cold Start Evaluation (Anwar)")
    plt.savefig(os.path.join(plots_dir, "cold_start_plot.png"))
    plots["cold_start"] = plot_to_base64()

    return plots

def main():
    try:
        init_environment()
        Config.init_toxicity_model()
        init_database()
        df, doctor_similarity_df, interaction_matrix = preprocess_data()
        tokenizer, model, device = load_tokenizer_and_model()
        trainer = fine_tune_model(model, tokenizer, df, Config.LEARNING_RATE, device)
        case_embeddings = generate_case_embeddings(df, model, tokenizer, device)
        disease_embeddings = generate_disease_embeddings(df, model, tokenizer, device)
        patient_data = [
            {"name": "Iqra", "symptom": "fever, cough", "city": "Chiniot"},
            {"name": "Moafi", "symptom": "headache, fatigue", "city": "Lahore"},
            {"name": "Sumair", "symptom": "sore throat, fever", "city": "Quetta"},
            {"name": "Anwar", "symptom": "chest pain, shortness of breath", "city": "Peshawar"}
        ]

        recommendations = inference(
            patient_data, model, tokenizer, df, doctor_similarity_df, case_embeddings,
            disease_embeddings, device
        )
        metrics, y_true, y_pred, y_scores = compute_metrics(
            recommendations, df, case_embeddings, model, tokenizer, device
        )
        plots = plot_visualizations(
            trainer, y_true, y_pred, y_scores, df, interaction_matrix, case_embeddings,
            [Config.LEARNING_RATE] * trainer.state.global_step, metrics
        )
        with open(os.path.join(BASE_DIR, "recommendations.json"), "w") as f:
            json.dump(recommendations, f, indent=4)
        logger.info("Recommendation pipeline completed successfully.")
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        raise

if __name__ == "__main__":
    main()