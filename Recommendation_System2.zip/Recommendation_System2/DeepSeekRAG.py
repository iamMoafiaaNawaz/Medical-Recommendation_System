import os
import json
import logging
import numpy as np
import pandas as pd
import torch
import requests
import xml.etree.ElementTree as ET
from transformers import AutoTokenizer, AutoModelForCausalLM
from typing import Dict, List, Any, Tuple, Union
import re
import faiss
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import mean_squared_error
from sklearn.manifold import TSNE
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.translate.meteor_score import meteor_score
from rouge_score import rouge_scorer
from fuzzywuzzy import fuzz
import psutil
import gc
import time
import sqlite3
from tqdm import tqdm
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import hashlib

# === Configuration and Setup ===
BASE_DIR = "/home/f223085/iqra/pkkaDeepSeek/last"
RAGIQ_DIR = os.path.join(BASE_DIR, "ragIq")
FALLBACK_DIR = "/tmp/ragIq"
RESULTS_DIR = None  # Will be set after directory creation
PLOTS_DIR = None    # Will be set after directory creation

# Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
file_handler = logging.FileHandler(os.path.join(BASE_DIR, "recommender_rag.log"))
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Verify and create directories
try:
    if not os.path.exists(BASE_DIR):
        os.makedirs(BASE_DIR, exist_ok=True)
        logger.info(f"Created BASE_DIR: {BASE_DIR}")
    if not os.access(BASE_DIR, os.W_OK):
        logger.error(f"No write permission for {BASE_DIR}. Using fallback directory: {FALLBACK_DIR}")
        RAGIQ_DIR = FALLBACK_DIR
    os.makedirs(RAGIQ_DIR, exist_ok=True)
    logger.info(f"Ensured RAGIQ_DIR exists: {RAGIQ_DIR}")
    RESULTS_DIR = RAGIQ_DIR
    PLOTS_DIR = RAGIQ_DIR
except Exception as e:
    logger.error(f"Failed to create {RAGIQ_DIR}: {e}. Using fallback directory: {FALLBACK_DIR}")
    try:
        os.makedirs(FALLBACK_DIR, exist_ok=True)
        RESULTS_DIR = FALLBACK_DIR
        PLOTS_DIR = FALLBACK_DIR
        logger.info(f"Using fallback directory: {FALLBACK_DIR}")
    except Exception as e2:
        logger.error(f"Failed to create fallback directory {FALLBACK_DIR}: {e2}")
        raise RuntimeError(f"Cannot create output directories: {e2}")

class Config:
    MODEL_PATH = os.path.join(BASE_DIR, "fine_tuned_model")
    DOCTORS_CSV = "/home/f223085/iqra/pd.csv"
    CASE_EMBEDDINGS = os.path.join(BASE_DIR, "case_embeddings.npy")
    DB_PATH = os.path.join(BASE_DIR, "user_profiles.db")
    MAX_LENGTH = 128
    TOP_K = 3
    EXPLORATORY_K = 10
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 50
    SIMILARITY_THRESHOLD = 0.5
    EMBEDDING_DIM = 768
    PUBMED_API = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    PUBMED_FETCH_API = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
    MEDLINEPLUS_API = "https://wsearch.nlm.nih.gov/ws/query"
    PUBMED_API_KEY = "d1427457eb2913e95966a02aa634542e1307"
    TOXICITY_MODEL = None
    DISEASE_ADVICE = {
        "cardiologist": "Seek immediate emergency care for heart-related symptoms like chest pain or shortness of breath.",
        "endocrinologist": "Consult for diabetes or hormonal issues; monitor blood sugar and follow a balanced diet.",
        "dermatologist": "Use moisturizers and avoid triggers for skin conditions; consult for persistent symptoms.",
        "general physician": "Schedule a routine check-up for tests and screenings."
    }
    DOCTOR_RECOMMENDATION = "Dr. {}, a {} in {}, rated {} stars. Chosen for expertise in {}."
    GENERAL_ADVICE = "Rest and medication may help, but consult a doctor for proper diagnosis."
    GREETING = "Hello {}, we're here to help with your health needs in {}."
    ANALYZING = "Analyzing your input to find the best care options in {}..."
    FALLBACK_MESSAGE = "We couldn't find {} in {} with our strict criteria, but here are top-rated doctors nearby."

    @staticmethod
    def init_toxicity_model():
        try:
            from detoxify import Detoxify
            Config.TOXICITY_MODEL = Detoxify('original')
            logger.info("Detoxify model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Detoxify model: {e}")

# === Environment and Data Initialization ===
def init_environment():
    nltk_data_dir = os.path.join(BASE_DIR, "nltk_data")
    os.makedirs(nltk_data_dir, exist_ok=True)
    nltk.download('punkt', download_dir=nltk_data_dir, quiet=True)
    nltk.download('wordnet', download_dir=nltk_data_dir, quiet=True)
    logger.info(f"NLTK data downloaded to {nltk_data_dir}")

def init_database():
    try:
        with sqlite3.connect(Config.DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS patients (
                    patient_id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE NOT NULL,
                    gender TEXT,
                    city TEXT,
                    symptoms TEXT,
                    ratings TEXT
                )
            """)
            patients = [
                (1, "Iqra", "Female", "Chiniot", "[]", "{}"),
                (2, "Moafi", "Female", "Lahore", "[]", "{}"),
                (3, "Sumair", "Male", "Karachi", "[]", "{}"),
                (4, "TestUser", "Unknown", "Chiniot", "[]", "{}")
            ]
            cursor.executemany("INSERT OR IGNORE INTO patients VALUES (?, ?, ?, ?, ?, ?)", patients)
            conn.commit()
        logger.info("Database initialized.")
    except sqlite3.Error as e:
        logger.error(f"Database initialization failed: {e}")
        raise

# === Document Extraction via APIs ===
def fetch_external_data() -> Tuple[List[Dict], List[Dict]]:
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    
    try:
        doctor_data = pd.read_csv(Config.DOCTORS_CSV)
        required_columns = ['Name', 'Specialist', 'City', 'Rating']
        if not all(col in doctor_data.columns for col in required_columns):
            raise ValueError(f"pd.csv missing required columns: {required_columns}")
        doctor_data = doctor_data[required_columns].to_dict('records')
        logger.info(f"Loaded {len(doctor_data)} doctors")
    except Exception as e:
        logger.error(f"Error loading pd.csv: {e}")
        doctor_data = [
            {"Name": "Dr. Ahmed", "Specialist": "cardiologist", "City": "Karachi", "Rating": 4.5},
            {"Name": "Dr. Sana", "Specialist": "endocrinologist", "City": "Lahore", "Rating": 4.2},
            {"Name": "Dr. Ali", "Specialist": "dermatologist", "City": "Chiniot", "Rating": 4.0},
            {"Name": "Dr. Khan", "Specialist": "general physician", "City": "Chiniot", "Rating": 4.3}
        ]
        logger.warning("Using fallback doctor data.")
    
    disease_docs = []
    diseases = ["heart attack", "diabetes", "eczema", "unknown"]
    
    for disease in diseases:
        for attempt in range(3):
            try:
                params = {
                    "db": "pubmed",
                    "term": f"{disease} treatment",
                    "retmax": 2,
                    "retmode": "xml",
                    "api_key": Config.PUBMED_API_KEY
                }
                response = session.get(Config.PUBMED_API, params=params, timeout=30)
                response.raise_for_status()
                root = ET.fromstring(response.content)
                ids = [id_elem.text for id_elem in root.findall(".//Id")]
                if not ids:
                    break
                fetch_params = {
                    "db": "pubmed",
                    "id": ",".join(ids),
                    "retmode": "xml",
                    "api_key": Config.PUBMED_API_KEY
                }
                fetch_response = session.get(Config.PUBMED_FETCH_API, params=fetch_params, timeout=30)
                fetch_response.raise_for_status()
                fetch_root = ET.fromstring(fetch_response.content)
                for article in fetch_root.findall(".//Article"):
                    title = article.find("ArticleTitle").text if article.find("ArticleTitle") is not None else ""
                    abstract_elem = article.find(".//AbstractText")
                    abstract = abstract_elem.text if abstract_elem is not None else ""
                    content = f"{title}. {abstract}"
                    if content.strip():
                        disease_docs.append({"disease": disease, "content": content, "source": "PubMed"})
                break
            except Exception as e:
                logger.error(f"PubMed API error for {disease} (attempt {attempt+1}/3): {e}")
                time.sleep(2 ** attempt)
                if attempt == 2:
                    logger.warning(f"Max retries reached for PubMed API on {disease}")
    
    for disease in diseases:
        for attempt in range(3):
            try:
                params = {"db": "healthTopics", "term": disease, "retmode": "xml"}
                response = session.get(Config.MEDLINEPLUS_API, params=params, timeout=30)
                response.raise_for_status()
                root = ET.fromstring(response.content)
                for topic in root.findall(".//document"):
                    summary = topic.find(".//content[@name='summary']").text if topic.find(".//content[@name='summary']") is not None else ""
                    if summary.strip():
                        disease_docs.append({"disease": disease, "content": summary, "source": "MedlinePlus"})
                break
            except Exception as e:
                logger.error(f"MedlinePlus API error for {disease} (attempt {attempt+1}/3): {e}")
                time.sleep(2 ** attempt)
                if attempt == 2:
                    logger.warning(f"Max retries reached for MedlinePlus API on {disease}")
    
    if len(disease_docs) < 4:
        logger.warning("Insufficient medical documents fetched. Using fallback disease data.")
        fallback_docs = [
            {"disease": "heart attack", "content": "Heart attack treatment involves immediate medical care, including medications and procedures like angioplasty.", "source": "Fallback"},
            {"disease": "diabetes", "content": "Diabetes management includes insulin therapy, lifestyle changes, and regular blood sugar monitoring.", "source": "Fallback"},
            {"disease": "eczema", "content": "Eczema treatment includes moisturizers, topical steroids, and avoiding triggers.", "source": "Fallback"},
            {"disease": "unknown", "content": "General check-ups involve routine tests and screenings to assess overall health.", "source": "Fallback"}
        ]
        existing_diseases = {doc["disease"] for doc in disease_docs}
        for doc in fallback_docs:
            if doc["disease"] not in existing_diseases:
                disease_docs.append(doc)
    
    logger.info(f"Fetched {len(disease_docs)} medical documents")
    return doctor_data, disease_docs

# === Document Chunking ===
def chunk_documents(documents: List[Dict]) -> List[Dict]:
    chunks = []
    for doc in documents:
        text = re.sub(r'<[^>]+>', '', doc["content"])
        disease = doc["disease"]
        source = doc["source"]
        start = 0
        while start < len(text):
            end = min(start + Config.CHUNK_SIZE, len(text))
            chunk_text = text[start:end]
            if end < len(text):
                chunk_text = text[start:end + Config.CHUNK_OVERLAP]
            chunks.append({"disease": disease, "chunk": chunk_text, "source": source, "id": f"{disease}_{len(chunks)}"})
            start += Config.CHUNK_SIZE - Config.CHUNK_OVERLAP
    logger.info(f"Created {len(chunks)} document chunks")
    return chunks

# === Model and Embedding Functions ===
def load_tokenizer_and_model() -> Tuple[AutoTokenizer, AutoModelForCausalLM, torch.device]:
    try:
        tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_PATH)
        model = AutoModelForCausalLM.from_pretrained(
            Config.MODEL_PATH, torch_dtype=torch.float16, low_cpu_mem_usage=True
        )
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()
        Config.EMBEDDING_DIM = model.config.hidden_size
        logger.info(f"Loaded model on {device}")
        return tokenizer, model, device
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        raise

def extract_semantic_features(texts: Union[str, List[str]], model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
                              device: torch.device, batch_size: int = 16) -> np.ndarray:
    if isinstance(texts, str):
        texts = [texts]
    
    try:
        embeddings = []
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            with torch.no_grad():
                inputs = tokenizer(
                    batch_texts, return_tensors="pt", max_length=Config.MAX_LENGTH, truncation=True, padding=True
                ).to(device)
                outputs = model(**inputs, output_hidden_states=True)
                batch_embeddings = torch.mean(outputs.hidden_states[-1], dim=1).cpu().numpy()
                embeddings.extend(batch_embeddings)
        embeddings = np.array(embeddings, dtype=np.float32)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        return embeddings
    except Exception as e:
        logger.error(f"Error extracting features: {e}")
        return np.zeros((len(texts), Config.EMBEDDING_DIM), dtype=np.float32)

# === Vector Database Setup with FAISS ===
def setup_vector_database(doc_chunks: List[Dict], model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device) -> tuple:
    if not doc_chunks:
        logger.warning("No document chunks provided. Returning empty FAISS index.")
        index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
        return index, [], [], []

    chunk_texts = [chunk["chunk"] for chunk in doc_chunks]
    chunk_ids = [chunk["id"] for chunk in doc_chunks]
    chunk_metadatas = [{"disease": chunk["disease"], "source": chunk["source"]} for chunk in doc_chunks]
    
    embeddings = extract_semantic_features(chunk_texts, model, tokenizer, device, batch_size=16)
    
    if embeddings.size == 0 or len(embeddings.shape) < 2:
        logger.error("Invalid embeddings shape. Returning empty FAISS index.")
        index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
        return index, [], [], []

    index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
    index.add(embeddings)
    
    logger.info(f"Stored {len(doc_chunks)} chunks in FAISS index")
    return index, chunk_texts, chunk_ids, chunk_metadatas

# === Load Case Embeddings ===
def load_case_embeddings(df: pd.DataFrame, model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device) -> faiss.Index:
    df_hash = hashlib.md5(df.to_json().encode()).hexdigest()
    metadata_path = os.path.join(BASE_DIR, "case_embeddings_metadata.json")
    
    try:
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
        else:
            metadata = {}
        
        if os.path.exists(Config.CASE_EMBEDDINGS) and metadata.get('df_hash') == df_hash:
            case_embeddings = np.load(Config.CASE_EMBEDDINGS, allow_pickle=True).astype(np.float32)
            if case_embeddings.shape[0] == len(df) and case_embeddings.shape[1] == Config.EMBEDDING_DIM:
                index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
                index.add(case_embeddings)
                logger.info(f"Loaded {case_embeddings.shape[0]} case embeddings into FAISS")
                return index
            else:
                logger.warning(f"Case embeddings size {case_embeddings.shape[0]} or dimension {case_embeddings.shape[1]} does not match df size {len(df)} or EMBEDDING_DIM {Config.EMBEDDING_DIM}. Regenerating.")
        else:
            logger.warning(f"Case embeddings file missing or metadata mismatch. Regenerating.")
        
        texts = [f"Doctor: {row['Name']}, {row['Specialist']}" for _, row in df.iterrows()]
        case_embeddings = extract_semantic_features(texts, model, tokenizer, device, batch_size=16)
        np.save(Config.CASE_EMBEDDINGS, case_embeddings)
        
        with open(metadata_path, 'w') as f:
            json.dump({'df_hash': df_hash, 'num_rows': len(df), 'embedding_dim': Config.EMBEDDING_DIM}, f)
        
        index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
        index.add(case_embeddings)
        logger.info(f"Generated and stored {case_embeddings.shape[0]} case embeddings")
        return index
    except Exception as e:
        logger.error(f"Error loading case embeddings: {e}")
        texts = [f"Doctor: {row['Name']}, {row['Specialist']}" for _, row in df.iterrows()]
        case_embeddings = extract_semantic_features(texts, model, tokenizer, device, batch_size=16)
        np.save(Config.CASE_EMBEDDINGS, case_embeddings)
        
        with open(metadata_path, 'w') as f:
            json.dump({'df_hash': df_hash, 'num_rows': len(df), 'embedding_dim': Config.EMBEDDING_DIM}, f)
        
        index = faiss.IndexFlatL2(Config.EMBEDDING_DIM)
        index.add(case_embeddings)
        logger.info(f"Generated and stored {case_embeddings.shape[0]} case embeddings (fallback)")
        return index

# === Data Preprocessing ===
def preprocess_data(doctor_data: List[Dict]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    df = pd.DataFrame(doctor_data)
    df["City"] = df["City"].str.lower().fillna("unknown")
    df["Rating"] = df["Rating"].astype(float).fillna(0.0)
    df["Specialist"] = df["Specialist"].str.lower().fillna("general physician")
    
    interaction_matrix = df.pivot_table(
        index="Specialist", columns="Name", values="Rating", aggfunc='mean', fill_value=0
    )
    doctor_similarity = cosine_similarity(interaction_matrix.T)
    doctor_similarity_df = pd.DataFrame(
        doctor_similarity, index=interaction_matrix.columns, columns=interaction_matrix.columns
    )
    logger.info("Data preprocessed successfully")
    return df, doctor_similarity_df

# === Normalize Symptoms ===
def normalize_symptoms(symptoms: str) -> str:
    symptoms = symptoms.lower().strip()
    if not symptoms:
        return ""
    normalized = [s.strip() for s in symptoms.split(",") if s.strip()]
    normalized_str = ", ".join(sorted(normalized))
    logger.info(f"Normalized symptoms: '{symptoms}' -> '{normalized_str}'")
    return normalized_str

# === DCG and NDCG ===
def dcg_score(scores: List[float], k: int) -> float:
    scores = np.array(scores[:k])
    if len(scores) == 0:
        return 0.0
    return np.sum((2 ** scores - 1) / np.log2(np.arange(2, len(scores) + 2)))

def ndcg_score(scores: List[float], ideal_scores: List[float], k: int) -> float:
    if not scores or not ideal_scores:
        return 0.0
    actual_dcg = dcg_score(scores, k)
    ideal_dcg = dcg_score(sorted(ideal_scores, reverse=True), k)
    return actual_dcg / ideal_dcg if ideal_dcg > 0 else 0.0

# === Average Precision ===
def average_precision(pred_doctors: List[str], gt_doctors: List[str]) -> float:
    relevant = set(gt_doctors)
    if not relevant:
        return 0.0
    precisions = []
    hits = 0
    for i, doctor in enumerate(pred_doctors, 1):
        if doctor in relevant:
            hits += 1
            precisions.append(hits / i)
    return np.mean(precisions) if precisions else 0.0

# === Metrics Implementation ===
def compute_metrics(predictions: List[Dict], df: pd.DataFrame, city: str, target_specialist: str,
                    model: AutoModelForCausalLM, tokenizer: AutoTokenizer, device: torch.device,
                    doctor_similarity_df: pd.DataFrame, top_k: int = Config.TOP_K) -> Dict[str, float]:
    if df is None or df.empty:
        logger.error("DataFrame is None or empty in compute_metrics")
        return {}
    
    precision_scores, recall_scores, ndcg_scores, map_scores, hit_rates, mrr_scores = [], [], [], [], [], []
    bleu_scores, rouge_scores, meteor_scores, ctr_scores = [], [], [], []
    coverage_set = set()
    cold_start_precision, novelty_scores, serendipity_scores, diversity_scores = [], [], [], []
    explainability_scores, inference_times, toxicity_scores = [], [], []
    mse_scores, rmse_scores = [], []
    hallucination_rates, personalization_scores, robustness_scores, business_alignment_scores = [], [], [], []

    item_popularity = df["Name"].value_counts() / len(df)
    item_popularity = item_popularity / item_popularity.sum()

    scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    smooth = SmoothingFunction()

    for pred in predictions:
        start_time = time.time()
        pred_doctors = [rec["doctor"] for rec in pred.get("recommendations", [])]
        city = city.lower()
        expected_doctors = df[df["Specialist"] == target_specialist]["Name"].tolist()
        if city != "unknown":
            city_specific = df[(df["City"] == city) & (df["Specialist"] == target_specialist)]["Name"].tolist()
            if city_specific:
                expected_doctors = city_specific
        coverage_set.update(pred_doctors)

        inference_time = time.time() - start_time
        inference_times.append(inference_time)

        if not expected_doctors:
            logger.warning(f"No doctors found for {city}, {target_specialist}, using top-rated specialists")
            expected_doctors = df[df["Specialist"] == target_specialist].sort_values(by="Rating", ascending=False)["Name"].head(10).tolist()

        relevant = set()
        for pred_doc in pred_doctors[:top_k]:
            for exp_doc in expected_doctors:
                if fuzz.ratio(pred_doc.lower(), exp_doc.lower()) > 80:
                    relevant.add(pred_doc)

        precision = len(relevant) / top_k if top_k > 0 else 0.0
        recall = len(relevant) / len(expected_doctors) if expected_doctors else 0.0
        precision_scores.append(precision)
        recall_scores.append(recall)

        scores = [1.0 if d in relevant else 0.0 for d in pred_doctors[:top_k]]
        ideal_scores = [1.0] * min(len(expected_doctors), top_k)
        ndcg_scores.append(ndcg_score(scores, ideal_scores, top_k))

        ap = average_precision(pred_doctors, expected_doctors)
        map_scores.append(ap)

        hit = 1.0 if relevant else 0.0
        hit_rates.append(hit)

        for i, doctor in enumerate(pred_doctors, 1):
            if doctor in relevant:
                mrr_scores.append(1.0 / i)
                break
        else:
            mrr_scores.append(0.0)

        if pred.get("condition", "").lower() == "general check-up":
            cold_start_precision.append(precision)
            logger.info(f"Cold-start precision for {pred.get('name', 'Unknown')}: {precision}")

        pred_text = " ".join([rec["recommendation_text"] for rec in pred.get("recommendations", [])])
        expected_text = f"Recommended {target_specialist} in {city} for {pred.get('condition', '').lower()}"
        if expected_text and pred_text:
            bleu_scores.append(sentence_bleu([expected_text.split()], pred_text.split(), weights=(0.5, 0.5, 0, 0), smoothing_function=smooth.method1))
            rouge_result = scorer.score(expected_text, pred_text)
            rouge_scores.append(rouge_result['rougeL'].fmeasure)
            meteor_scores.append(meteor_score([expected_text.split()], pred_text.split()))

        clicks = sum(df[df["Name"] == d]["Rating"].iloc[0] / 5.0 for d in pred_doctors[:top_k] if d in df["Name"].values)
        ctr_scores.append(clicks / top_k if top_k > 0 else 0.0)

        novelty = sum(1 - item_popularity.get(d, 0.0) for d in pred_doctors[:top_k]) / top_k if top_k > 0 else 0.0
        novelty_scores.append(novelty)

        past_symptoms = pred.get("past_symptoms", [])
        if past_symptoms:
            pred_emb = extract_semantic_features([pred_text], model, tokenizer, device)[0]
            past_emb = extract_semantic_features([" ".join(past_symptoms)], model, tokenizer, device)[0]
            serendipity = 1 - max(cosine_similarity([pred_emb], [past_emb])[0][0], 0)
        else:
            serendipity = novelty
        serendipity_scores.append(serendipity)

        if len(pred_doctors) > 1:
            sim_sum = 0.0
            count = 0
            for i in range(len(pred_doctors[:top_k])):
                for j in range(i + 1, len(pred_doctors[:top_k])):
                    if pred_doctors[i] in doctor_similarity_df.index and pred_doctors[j] in doctor_similarity_df.index:
                        sim_sum += doctor_similarity_df.loc[pred_doctors[i], pred_doctors[j]]
                        count += 1
            diversity = 1 - (sim_sum / count if count > 0 else 0.0)
        else:
            diversity = 1.0
        diversity_scores.append(diversity)

        explainability = len(pred_text.split()) / 50.0
        explainability_scores.append(min(explainability, 1.0))

        if Config.TOXICITY_MODEL:
            toxicity_result = Config.TOXICITY_MODEL.predict(pred_text)
            toxicity_scores.append(toxicity_result['toxicity'])

        pred_ratings = [df[df["Name"] == d]["Rating"].iloc[0] for d in pred_doctors[:top_k] if d in df["Name"].values]
        gt_ratings = [df[df["Name"] == d]["Rating"].iloc[0] for d in expected_doctors if d in df["Name"].values]
        if pred_ratings and gt_ratings:
            mse = mean_squared_error([np.mean(gt_ratings)] * len(pred_ratings), pred_ratings)
            rmse = np.sqrt(mse)
            mse_scores.append(mse)
            rmse_scores.append(rmse)

        hallucinations = sum(1 for d in pred_doctors if d not in df["Name"].values)
        hallucination_rates.append(hallucinations / top_k if top_k > 0 else 0.0)

        pred_condition = pred["condition"].lower()
        pred_embedding = extract_semantic_features([pred_condition], model, tokenizer, device)[0]
        gt_embedding = extract_semantic_features(["routine check-up" if pred_condition == "general check-up" else pred_condition], model, tokenizer, device)[0]
        personalization = cosine_similarity([pred_embedding], [gt_embedding])[0][0]
        personalization_scores.append(personalization)

        rephrased = " ".join(pred_condition.split()[::-1])
        rephrased_emb = extract_semantic_features([rephrased], model, tokenizer, device)[0]
        robustness = cosine_similarity([pred_embedding], [rephrased_emb])[0][0]
        robustness_scores.append(robustness)

        business_alignment = np.mean([df[df["Name"] == d]["Rating"].iloc[0] for d in pred_doctors[:top_k] if d in df["Name"].values]) / 5.0 if pred_doctors else 0.0
        business_alignment_scores.append(business_alignment)

    process = psutil.Process()
    memory_usage = process.memory_info().rss / (1024 ** 2)

    metrics = {
        "precision@k": float(np.mean(precision_scores)) if precision_scores else 0.0,
        "recall@k": float(np.mean(recall_scores)) if recall_scores else 0.0,
        "f1@k": float(2 * np.mean(precision_scores) * np.mean(recall_scores) / (
            np.mean(precision_scores) + np.mean(recall_scores))) if precision_scores and recall_scores and (
            np.mean(precision_scores) + np.mean(recall_scores)) > 0 else 0.0,
        "ndcg@k": float(np.mean(ndcg_scores)) if ndcg_scores else 0.0,
        "map": float(np.mean(map_scores)) if map_scores else 0.0,
        "hit_rate@k": float(np.mean(hit_rates)) if hit_rates else 0.0,
        "mrr": float(np.mean(mrr_scores)) if mrr_scores else 0.0,
        "bleu": float(np.mean(bleu_scores)) if bleu_scores else 0.0,
        "rougeL": float(np.mean(rouge_scores)) if rouge_scores else 0.0,
        "meteor": float(np.mean(meteor_scores)) if meteor_scores else 0.0,
        "ctr": float(np.mean(ctr_scores)) if ctr_scores else 0.0,
        "coverage": float(len(coverage_set) / len(df["Name"].unique())) if len(df["Name"].unique()) > 0 else 0.0,
        "cold_start_precision": float(np.mean(cold_start_precision)) if cold_start_precision else 0.0,
        "novelty": float(np.mean(novelty_scores)) if novelty_scores else 0.0,
        "serendipity": float(np.mean(serendipity_scores)) if serendipity_scores else 0.0,
        "diversity": float(np.mean(diversity_scores)) if diversity_scores else 0.0,
        "explainability_score": float(np.mean(explainability_scores)) if explainability_scores else 0.0,
        "avg_inference_time": float(np.mean(inference_times)) if inference_times else 0.0,
        "toxicity_score": float(np.mean(toxicity_scores)) if toxicity_scores else 0.0,
        "mse": float(np.mean(mse_scores)) if mse_scores else 0.0,
        "rmse": float(np.mean(rmse_scores)) if rmse_scores else 0.0,
        "hallucination_rate": float(np.mean(hallucination_rates)) if hallucination_rates else 0.0,
        "personalization_score": float(np.mean(personalization_scores)) if personalization_scores else 0.0,
        "robustness_score": float(np.mean(robustness_scores)) if robustness_scores else 0.0,
        "business_alignment_score": float(np.mean(business_alignment_scores)) if business_alignment_scores else 0.0,
        "memory_usage_MB": float(memory_usage)
    }

    try:
        metrics_path = os.path.join(RESULTS_DIR, "metrics.json")
        if not os.access(RESULTS_DIR, os.W_OK):
            logger.error(f"No write permission for {RESULTS_DIR}")
            raise PermissionError(f"Cannot write to {RESULTS_DIR}")
        with open(metrics_path, "w") as f:
            json.dump(metrics, f, indent=2)
        logger.info(f"Metrics saved to {metrics_path}")
    except Exception as e:
        logger.error(f"Failed to save metrics to {metrics_path}: {e}")
        fallback_path = os.path.join(BASE_DIR, "metrics_fallback.json")
        try:
            with open(fallback_path, "w") as f:
                json.dump(metrics, f, indent=2)
            logger.info(f"Metrics saved to fallback: {fallback_path}")
        except Exception as e2:
            logger.error(f"Failed to save metrics to fallback {fallback_path}: {e2}")

    return metrics

# === Visualization Implementation ===
def plot_visualizations(df: pd.DataFrame, metrics: Dict[str, float], doctor_similarity_df: pd.DataFrame):
    if df is None or df.empty:
        logger.error("DataFrame is None or empty in plot_visualizations")
        return []
    
    if not os.access(PLOTS_DIR, os.W_OK):
        logger.error(f"No write permission for {PLOTS_DIR}")
        return []

    plots = []
    training_data = [
        {'loss': 9.167, 'grad_norm': 1.65517495222473, 'learning_rate': 0.0002830507846271, 'epoch': 0.17},
        {'loss': 4.934, 'grad_norm': 1.805, 'learning_rate': 0.0002661016949154, 'epoch': 0.34},
        {'loss': 4.0932, 'grad_norm': 2.147407293319702, 'learning_rate': 0.00024915254237288135, 'epoch': 0.51},
        {'loss': 3.7052, 'grad_norm': 2.4243781334381104, 'learning_rate': 0.00023220338983050845, 'epoch': 0.68},
        {'loss': 3.5349, 'grad_norm': 3.3309762088928223, 'learning_rate': 0.0002152542372881351, 'epoch': 0.85},
        {'loss': 3.391, 'grad_norm': 2.4204895863189697, 'learning_rate': 0.0001983050847457627, 'epoch': 1.02},
        {'loss': 3.3183, 'grad_norm': 2.4626454132995605, 'learning_rate': 0.0001813559322033898, 'epoch': 1.18},
        {'loss': 3.1755, 'grad_norm': 3.7217094561234, 'learning_rate': 0.00016440677966101692, 'epoch': 1.35},
        {'loss': 3.2133, 'grad_norm': 2.6664648056030273, 'learning_rate': 0.00014745762711864405, 'epoch': 1.52},
        {'loss': 3.1098, 'grad_norm': 3.109283685684204, 'learning_rate': 0.00013050847457627118, 'epoch': 1.69},
        {'loss': 3.0918, 'grad_norm': 2.8029, 'learning_rate': 0.0001135593220338983, 'epoch': 1.86},
        {'loss': 3.0737, 'grad_norm': 2.845672369003296, 'learning_rate': 9.661016949152541e-05, 'epoch': 2.03},
        {'loss': 3.0587, 'grad_norm': 2.999819755554199, 'learning_rate': 7.966101694915254e-05, 'epoch': 2.2},
        {'loss': 2.9961, 'grad_norm': 2.6304784178320544, 'learning_rate': 6.271186440677965e-05, 'epoch': 2.37},
        {'loss': 2.9748, 'grad_norm': 2.769517660140991, 'learning_rate': 4.576271186440678e-05, 'epoch': 2.54},
        {'loss': 2.0214, 'grad_norm': 2.9226834774017334, 'learning_rate': 2.8813559322033896e-05, 'epoch': 2.71},
        {'loss': 2.9924, 'grad_norm': 2.7975263595581055, 'learning_rate': 1.1864406779661016e-05, 'epoch': 2.88}
    ]
    eval_data = [
        {'eval_loss': 3.250072717666626, 'eval_accuracy': 0.06725958766036687, 'eval_precision': 0.03675097346218405,
         'eval_recall': 0.06725958866036687, 'eval_f1': 0.046023797680514055, 'eval_perplexity': 643.5369872520871, 'epoch': 1.0},
        {'eval_loss': 2.9628424644470215, 'eval_accuracy': 0.06503699418399111, 'eval_precision': 0.049946783464359896,
         'eval_recall': 0.06503699418399111, 'eval_f1': 0.04872880275336565, 'eval_perplexity': 813.9467927623219, 'epoch': 2.0},
        {'eval_loss': 2.894439697265625, 'eval_accuracy': 0.06670372429127293, 'eval_precision': 0.0523183867882114,
         'eval_recall': 0.06670372429127293, 'eval_f1': 0.050252139229936064, 'eval_perplexity': 850.7546598767408, 'epoch': 3.0}
    ]

    sns.set_style("darkgrid")
    palette = sns.color_palette("husl", 3)

    def save_plot(plt, path, plot_name):
        try:
            if not os.access(PLOTS_DIR, os.W_OK):
                logger.error(f"No write permission for {PLOTS_DIR} when saving {plot_name}")
                return False
            plt.savefig(path, bbox_inches='tight', dpi=300)
            plt.close()
            if os.path.exists(path):
                logger.info(f"Saved {plot_name} to {path}")
                return True
            else:
                logger.error(f"Failed to verify {plot_name} at {path}")
                return False
        except Exception as e:
            logger.error(f"Failed to save {plot_name} to {path}: {e}")
            fallback_path = os.path.join(BASE_DIR, f"temp_{os.path.basename(path)}")
            try:
                plt.savefig(fallback_path, bbox_inches='tight', dpi=300)
                logger.info(f"Saved {plot_name} to fallback: {fallback_path}")
                return True
            except Exception as e2:
                logger.error(f"Failed to save {plot_name} to fallback {fallback_path}: {e2}")
                return False
        finally:
            plt.close()

    try:
        # Loss Curve
        plt.figure(figsize=(8, 6))
        plt.plot([d['epoch'] for d in training_data], [d['loss'] for d in training_data], marker='o', color=palette[0], label="Training Loss")
        plt.plot([d['epoch'] for d in eval_data], [d['eval_loss'] for d in eval_data], marker='^', color=palette[1], label="Evaluation Loss")
        plt.title("Training and Evaluation Loss vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.legend()
        plt.grid(True)
        loss_path = os.path.join(PLOTS_DIR, "loss_curve.png")
        if save_plot(plt, loss_path, "Loss Curve"):
            plots.append(loss_path)

        # Gradient Norm
        plt.figure(figsize=(8, 6))
        plt.plot([d['epoch'] for d in training_data], [d['grad_norm'] for d in training_data], marker='o', color=palette[0])
        plt.title("Gradient Norm vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Gradient Norm")
        plt.grid(True)
        grad_norm_path = os.path.join(PLOTS_DIR, "grad_norm.png")
        if save_plot(plt, grad_norm_path, "Gradient Norm"):
            plots.append(grad_norm_path)

        # Learning Rate
        plt.figure(figsize=(8, 6))
        plt.plot([d['epoch'] for d in training_data], [d['learning_rate'] for d in training_data], marker='o', color='orange')
        plt.title("Learning Rate vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Learning Rate")
        plt.grid(True)
        lr_path = os.path.join(PLOTS_DIR, "learning_rate.png")
        if save_plot(plt, lr_path, "Learning Rate"):
            plots.append(lr_path)

        # Evaluation Accuracy
        plt.figure(figsize=(8, 6))
        plt.plot([d['epoch'] for d in eval_data], [d['eval_accuracy'] for d in eval_data], marker='o', color=palette[0])
        plt.title("Evaluation Accuracy vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.grid(True)
        eval_accuracy_path = os.path.join(PLOTS_DIR, "eval_accuracy.png")
        if save_plot(plt, eval_accuracy_path, "Evaluation Accuracy"):
            plots.append(eval_accuracy_path)

        # Evaluation PRF
        plt.figure(figsize=(10, 6))
        plt.plot([d['epoch'] for d in eval_data], [d['eval_precision'] for d in eval_data], marker='o', label='Precision', color=palette[0])
        plt.plot([d['epoch'] for d in eval_data], [d['eval_recall'] for d in eval_data], marker='^', label='Recall', color=palette[1])
        plt.plot([d['epoch'] for d in eval_data], [d['eval_f1'] for d in eval_data], marker='s', label='F1', color=palette[2])
        plt.title("Evaluation Metrics vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Score")
        plt.legend()
        plt.grid(True)
        eval_prf_path = os.path.join(PLOTS_DIR, "eval_prf.png")
        if save_plot(plt, eval_prf_path, "Evaluation PRF"):
            plots.append(eval_prf_path)

        # Evaluation Perplexity
        plt.figure(figsize=(8, 6))
        plt.plot([d['epoch'] for d in eval_data], [d['eval_perplexity'] for d in eval_data], marker='o', color=palette[0])
        plt.title("Evaluation Perplexity vs. Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Perplexity")
        plt.grid(True)
        eval_perplexity_path = os.path.join(PLOTS_DIR, "eval_perplexity.png")
        if save_plot(plt, eval_perplexity_path, "Evaluation Perplexity"):
            plots.append(eval_perplexity_path)

        # Recommendation Metrics
        plt.figure(figsize=(10, 6))
        plt.bar(['Precision@k', 'Recall@k', 'F1@k'], [metrics.get('precision@k', 0), metrics.get('recall@k', 0), metrics.get('f1@k', 0)], color=[palette[0], palette[1], palette[2]])
        plt.title("Recommendation Metrics")
        plt.ylabel("Score")
        plt.grid(True)
        prf_k_path = os.path.join(PLOTS_DIR, "prf_k.png")
        if save_plot(plt, prf_k_path, "Recommendation Metrics"):
            plots.append(prf_k_path)

        # Ranking Metrics
        plt.figure(figsize=(8, 6))
        plt.bar(['NDCG@k', 'MAP'], [metrics.get('ndcg@k', 0), metrics.get('map', 0)], color=[palette[0], palette[1]])
        plt.title("Ranking Metrics")
        plt.ylabel("Score")
        plt.grid(True)
        ndcg_map_path = os.path.join(PLOTS_DIR, "ndcg_map.png")
        if save_plot(plt, ndcg_map_path, "Ranking Metrics"):
            plots.append(ndcg_map_path)

        # Hit Rate and MRR
        plt.figure(figsize=(8, 6))
        plt.bar(['Hit Rate@k', 'MRR'], [metrics.get('hit_rate@k', 0), metrics.get('mrr', 0)], color=[palette[0], palette[1]])
        plt.title("Hit Rate and MRR")
        plt.ylabel("Score")
        plt.grid(True)
        hit_mrr_path = os.path.join(PLOTS_DIR, "hit_mrr.png")
        if save_plot(plt, hit_mrr_path, "Hit Rate and MRR"):
            plots.append(hit_mrr_path)

        # Text Generation Metrics
        plt.figure(figsize=(10, 6))
        plt.bar(['BLEU', 'ROUGE-L', 'METEOR'], [metrics.get('bleu', 0), metrics.get('rougeL', 0), metrics.get('meteor', 0)], color=[palette[0], palette[1], palette[2]])
        plt.title("Text Generation Metrics")
        plt.ylabel("Score")
        plt.grid(True)
        text_metrics_path = os.path.join(PLOTS_DIR, "text_metrics.png")
        if save_plot(plt, text_metrics_path, "Text Generation Metrics"):
            plots.append(text_metrics_path)

        # Additional Metrics
        plt.figure(figsize=(12, 6))
        plt.bar(['Coverage', 'Novelty', 'Serendipity', 'Diversity'], [metrics.get('coverage', 0), metrics.get('novelty', 0), metrics.get('serendipity', 0), metrics.get('diversity', 0)], color=[palette[0], palette[1], palette[2], 'green'])
        plt.title("Additional Metrics")
        plt.ylabel("Score")
        plt.grid(True)
        additional_metrics_path = os.path.join(PLOTS_DIR, "additional_metrics.png")
        if save_plot(plt, additional_metrics_path, "Additional Metrics"):
            plots.append(additional_metrics_path)

        # Rating Distribution
        plt.figure(figsize=(8, 6))
        sns.histplot(data=df, x='Rating', bins=10, kde=True, color=palette[0])
        plt.title("Doctor Rating Distribution")
        plt.xlabel("Rating")
        plt.ylabel("Count")
        plt.grid(True)
        rating_hist_path = os.path.join(PLOTS_DIR, "rating_hist.png")
        if save_plot(plt, rating_hist_path, "Rating Distribution"):
            plots.append(rating_hist_path)

        # Specialist Distribution
        plt.figure(figsize=(10, 6))
        sns.countplot(data=df, x="Specialist", palette="viridis")
        plt.title("Specialist Distribution")
        plt.xlabel("Specialist")
        plt.ylabel("Count")
        plt.xticks(rotation=45)
        plt.grid(True)
        specialist_hist_path = os.path.join(PLOTS_DIR, "specialist_hist.png")
        if save_plot(plt, specialist_hist_path, "Specialist Distribution"):
            plots.append(specialist_hist_path)

        # t-SNE Plot
        try:
            case_embeddings = np.load(Config.CASE_EMBEDDINGS, allow_pickle=True).astype(np.float32)
            sample_size = min(100, case_embeddings.shape[0])
            if sample_size > 5:
                perplexity = min(5, sample_size // 2)
                tsne = TSNE(n_components=2, random_state=42, perplexity=perplexity)
                tsne_labels = tsne.fit_transform(case_embeddings[:sample_size])
                plt.figure(figsize=(10, 8))
                sns.scatterplot(x=tsne_labels[:, 0], y=tsne_labels[:, 1], hue=df['Specialist'].iloc[:sample_size], palette="viridis")
                plt.title("t-SNE Plot of Case Embeddings")
                plt.xlabel("t-SNE Component 1")
                plt.ylabel("t-SNE Component 2")
                plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
                plt.grid(True)
                tsne_label_path = os.path.join(PLOTS_DIR, "tsne_embeddings.png")
                if save_plot(plt, tsne_label_path, "t-SNE Plot"):
                    plots.append(tsne_label_path)
        except Exception as e:
            logger.error(f"Failed to generate t-SNE plot: {e}")

        # Cold Start Precision
        plt.figure(figsize=(8, 6))
        plt.bar(['Cold Start Precision'], [metrics.get('cold_start_precision', 0)], color=palette[0])
        plt.title("Cold Start Precision")
        plt.ylabel("Score")
        plt.grid(True)
        cold_start_path = os.path.join(PLOTS_DIR, "cold_start_precision.png")
        if save_plot(plt, cold_start_path, "Cold Start Precision"):
            plots.append(cold_start_path)

        # Doctor Similarity Heatmap
        plt.figure(figsize=(10, 8))
        sns.heatmap(doctor_similarity_df.iloc[:10, :10], cmap="viridis", annot=True, fmt=".2f")
        plt.title("Doctor Similarity Heatmap")
        plt.xlabel("Doctors")
        plt.ylabel("Doctors")
        heatmap_path = os.path.join(PLOTS_DIR, "similarity_heatmap.png")
        if save_plot(plt, heatmap_path, "Doctor Similarity Heatmap"):
            plots.append(heatmap_path)

        logger.info(f"Generated {len(plots)} plots in {PLOTS_DIR}")
    except Exception as e:
        logger.error(f"Error in plot_visualizations: {e}")
    
    # Verify all plots exist
    missing_plots = [p for p in plots if not os.path.exists(p)]
    if missing_plots:
        logger.warning(f"Missing plots: {missing_plots}")
    
    return sorted(plots)


# === Inference ===
def inference(patient_data: Dict, df: pd.DataFrame, doc_index: faiss.Index, doc_texts: List[str], doc_ids: List[str],
              doc_metadatas: List[Dict], case_index: faiss.Index, model: AutoModelForCausalLM, tokenizer: AutoTokenizer,
              device: torch.device, doctor_similarity_df: pd.DataFrame) -> Dict:
    if df is None or df.empty:
        logger.error("DataFrame is None or empty in inference")
        return {}
    
    name = patient_data.get("name", "Unknown")
    symptoms = normalize_symptoms(patient_data.get("symptoms", ""))
    city = patient_data.get("city", "unknown").lower()
    logger.info(f"Processing: {name}, symptoms={symptoms}, city={city}")
    
    print(Config.GREETING.format(name, city.capitalize()))
    print(Config.ANALYZING.format(city.capitalize()))
    
    recommendations = []
    seen_doctors = set()
    
    try:
        with sqlite3.connect(Config.DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT symptoms, ratings FROM patients WHERE name = ?", (name,))
            result = cursor.fetchone()
            past_symptoms = json.loads(result[0]) if result else []
            ratings = json.loads(result[1]) if result else {}
    except Exception as e:
        logger.error(f"Database query failed: {e}")
        past_symptoms = []
        ratings = {}
    
    if not symptoms:
        target_specialist = "general physician"
        condition = "General check-up"
        filtered_df = df[df["Specialist"] == target_specialist]
        if city != "unknown":
            filtered_df = filtered_df[filtered_df["City"] == city]
        if filtered_df.empty:
            logger.warning(f"No {target_specialist}s in {city}")
            print(Config.FALLBACK_MESSAGE.format(target_specialist, city.capitalize()))
            filtered_df = df[df["Specialist"] == target_specialist]
        top_doctors = filtered_df.sort_values(by="Rating", ascending=False).head(5)
        for _, doctor in top_doctors.iterrows():
            if doctor["Name"].lower() not in seen_doctors:
                recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                    doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"], condition
                )
                recommendations.append({
                    "doctor": doctor["Name"],
                    "specialist": doctor["Specialist"],
                    "city": doctor["City"],
                    "rating": float(doctor["Rating"]),
                    "recommendation_text": recommendation_text,
                    "disease": condition
                })
                seen_doctors.add(doctor["Name"].lower())
        
        exploratory_df = df[df["Specialist"] != target_specialist]
        if city != "unknown":
            exploratory_df = exploratory_df[exploratory_df["City"] == city]
        exploratory_df = exploratory_df.sort_values(by="Rating", ascending=False)
        exploratory_count = 0
        for _, doctor in exploratory_df.iterrows():
            if doctor["Name"].lower() not in seen_doctors and exploratory_count < Config.EXPLORATORY_K:
                recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                    doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"],
                    f"{doctor['Specialist']} expertise"
                )
                recommendations.append({
                    "doctor": doctor["Name"],
                    "specialist": doctor["Specialist"],
                    "city": doctor["City"],
                    "rating": float(doctor["Rating"]),
                    "recommendation_text": recommendation_text,
                    "disease": "exploratory"
                })
                seen_doctors.add(doctor["Name"].lower())
                exploratory_count += 1
            if exploratory_count >= Config.EXPLORATORY_K:
                break
        
        return {
            "name": name,
            "condition": condition,
            "disease_confidences": [["general check-up", 1.0]],
            "recommendations": recommendations[:Config.TOP_K],
            "advice": Config.DISEASE_ADVICE.get(target_specialist, Config.GENERAL_ADVICE),
            "past_symptoms": past_symptoms,
            "context": "No specific disease information."
        }
    
    query = f"Symptoms: {symptoms}"
    query_embedding = extract_semantic_features([query], model, tokenizer, device)[0].reshape(1, -1).astype(np.float32)
    
    context = ""
    if doc_texts and doc_ids and doc_metadatas:
        D, I = doc_index.search(query_embedding, 5)
        context = " ".join([f"[{doc_metadatas[i]['source']}] {doc_texts[i]}" for i in I[0] if i < len(doc_texts)])
    
    unique_specialists = df["Specialist"].unique()
    specialist_texts = [f"Specialist: {specialist}" for specialist in unique_specialists]
    specialist_embeddings = extract_semantic_features(specialist_texts, model, tokenizer, device, 16)
    similarities = cosine_similarity(query_embedding, specialist_embeddings)[0]
    specialist_confidences = [
        [specialist, float(sim)] for specialist, sim in zip(unique_specialists, similarities)
        if sim >= Config.SIMILARITY_THRESHOLD
    ]
    specialist_confidences = sorted(specialist_confidences, key=lambda x: x[1], reverse=True)[:Config.TOP_K]
    
    predicted_specialists = [sc[0] for sc in specialist_confidences]
    if not predicted_specialists:
        predicted_specialists = ["general physician"]
        specialist_confidences = [["general physician", 0.0]]
        condition = "unknown"
    else:
        condition = specialist_confidences[0][0]
    
    D, I = case_index.search(query_embedding, Config.TOP_K * 2)
    candidate_doctors = df.iloc[I[0]]
    for _, doctor in candidate_doctors.iterrows():
        if doctor["Specialist"].lower() in predicted_specialists and doctor["Name"].lower() not in seen_doctors:
            if city != "unknown" and doctor["City"].lower() != city:
                continue
            recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"], condition
            )
            recommendations.append({
                "doctor": doctor["Name"],
                "specialist": doctor["Specialist"],
                "city": doctor["City"],
                "rating": float(doctor["Rating"]),
                "recommendation_text": recommendation_text,
                "disease": condition
            })
            seen_doctors.add(doctor["Name"].lower())
    
    if len(recommendations) < Config.TOP_K:
        filtered_df = df[df["Specialist"].isin(predicted_specialists)]
        if city != "unknown":
            filtered_df = filtered_df[filtered_df["City"] == city]
        if filtered_df.empty:
            logger.warning(f"No {','.join(predicted_specialists)} in {city}")
            print(Config.FALLBACK_MESSAGE.format(','.join(predicted_specialists), city.capitalize()))
            filtered_df = df[df["Specialist"].isin(predicted_specialists)]
        top_doctors = filtered_df.sort_values(by="Rating", ascending=False).head(Config.TOP_K - len(recommendations))
        for _, doctor in top_doctors.iterrows():
            if doctor["Name"].lower() not in seen_doctors:
                recommendation_text = Config.DOCTOR_RECOMMENDATION.format(
                    doctor["Name"], doctor["Specialist"], doctor["City"], doctor["Rating"], condition
                )
                recommendations.append({
                    "doctor": doctor["Name"],
                    "specialist": doctor["Specialist"],
                    "city": doctor["City"],
                    "rating": float(doctor["Rating"]),
                    "recommendation_text": recommendation_text,
                    "disease": condition
                })
                seen_doctors.add(doctor["Name"].lower())
    
    try:
        with sqlite3.connect(Config.DB_PATH) as conn:
            cursor = conn.cursor()
            past_symptoms.append(symptoms)
            past_symptoms = list(set(past_symptoms))[-10:]
            cursor.execute(
                "UPDATE patients SET symptoms = ? WHERE name = ?",
                (json.dumps(past_symptoms), name)
            )
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to update database for {name}: {e}")
    
    return {
        "name": name,
        "condition": condition,
        "disease_confidences": specialist_confidences,
        "recommendations": recommendations[:Config.TOP_K],
        "advice": Config.DISEASE_ADVICE.get(predicted_specialists[0], Config.GENERAL_ADVICE),
        "past_symptoms": past_symptoms,
        "context": context
    }
# === Main Execution ===
# === Main Execution ===
if __name__ == "__main__":
    try:
        init_environment()
        init_database()
        Config.init_toxicity_model()
        
        doctor_data, disease_docs = fetch_external_data()
        df, doctor_similarity_df = preprocess_data(doctor_data)
        doc_chunks = chunk_documents(disease_docs)
        
        tokenizer, model, device = load_tokenizer_and_model()
        doc_index, doc_texts, doc_ids, doc_metadatas = setup_vector_database(doc_chunks, model, tokenizer, device)
        case_index = load_case_embeddings(df, model, tokenizer, device)
        
        patient_data_list = [
            {"name": "Isaac", "symptoms": "chest pain, shortness of breath", "city": "Chiniot"},
            {"name": "Moafi", "symptoms": "fatigue, increased thirst", "city": "Lahore"},
            {"name": "Sumair", "symptoms": "itchy skin, rash", "city": "Karachi"},
            {"name": "TestUser", "symptoms": "", "city": "Chiniot"}  # Cold-start case
        ]
        
        predictions = []
        for patient_data in tqdm(patient_data_list, desc="Processing patients"):
            pred = inference(
                patient_data, df, doc_index, doc_texts, doc_ids, doc_metadatas,
                case_index, model, tokenizer, device, doctor_similarity_df
            )
            predictions.append(pred)
        
        # Save predictions
        try:
            predictions_path = os.path.join(RESULTS_DIR, "predictions.json")
            if not os.access(RESULTS_DIR, os.W_OK):
                logger.error(f"No write permission for {RESULTS_DIR}")
                raise PermissionError(f"Cannot write to {RESULTS_DIR}")
            with open(predictions_path, "w") as f:
                json.dump(predictions, f, indent=2)
            logger.info(f"Saved predictions to {predictions_path}")
        except Exception as e:
            logger.error(f"Failed to save predictions: {e}")
            fallback_path = os.path.join(FALLBACK_DIR, "predictions_fallback.json")
            try:
                os.makedirs(FALLBACK_DIR, exist_ok=True)
                with open(fallback_path, "w") as f:
                    json.dump(predictions, f, indent=2)
                logger.info(f"Saved predictions to fallback: {fallback_path}")
            except Exception as e2:
                logger.error(f"Failed to save predictions to fallback {fallback_path}: {e2}")
        
        target_specialist = "general physician"  # Default for metrics
        city = "chiniot"  # Default for metrics
        metrics = compute_metrics(
            predictions, df, city, target_specialist, model, tokenizer, device, doctor_similarity_df
        )
        
        plots = plot_visualizations(df, metrics, doctor_similarity_df)
        
        # Verify all outputs
        expected_plots = [
            "loss_curve.png", "grad_norm.png", "learning_rate.png", "eval_accuracy.png",
            "eval_prf.png", "eval_perplexity.png", "prf_k.png", "ndcg_map.png",
            "hit_mrr.png", "text_metrics.png", "additional_metrics.png", "rating_hist.png",
            "specialist_hist.png", "tsne_embeddings.png", "cold_start_precision.png",
            "similarity_heatmap.png"
        ]
        missing_files = []
        for plot in expected_plots:
            plot_path = os.path.join(PLOTS_DIR, plot)
            if not os.path.exists(plot_path):
                missing_files.append(plot_path)
        metrics_path = os.path.join(RESULTS_DIR, "metrics.json")
        if os.path.exists(metrics_path):
            logger.info("metrics.json found")
        else:
            missing_files.append(metrics_path)
        predictions_path = os.path.join(RESULTS_DIR, "predictions.json")
        if os.path.exists(predictions_path):
            logger.info("predictions.json found")
        else:
            missing_files.append(predictions_path)
        
        if missing_files:
            logger.error(f"Missing files: {missing_files}")
            print(f"Error: Missing files: {missing_files}")
        else:
            logger.info("All expected files generated and verified")
            print(f"All outputs successfully saved and verified in {RESULTS_DIR}")
        
    except Exception as e:
        logger.error(f"Main execution failed: {e}")
        print(f"Execution failed: {e}")