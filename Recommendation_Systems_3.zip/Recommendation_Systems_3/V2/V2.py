import os
import sqlite3
import json
import time
import logging
import gc
import math
import random
import base64
from io import BytesIO
from collections import defaultdict
from typing import Dict, List, Tuple, Optional
import pandas as pd
import numpy as np
import nltk
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from torch.utils.data import Dataset
from sklearn.metrics import precision_score, recall_score, f1_score, mean_squared_error, confusion_matrix
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
from transformers import AutoTokenizer, AutoModelForMaskedLM
from transformers.trainer import Trainer, TrainingArguments, EvalPrediction 
from peft import prepare_model_for_kbit_training, LoraConfig, get_peft_model
from huggingface_hub import login
import detoxify
import hnswlib

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
BASE_DIR = "/home/f223085/iqra/Sumair/V2"
os.makedirs(BASE_DIR, exist_ok=True)
file_handler = logging.FileHandler(os.path.join(BASE_DIR, "recommender_hnsw.log"))
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Configuration class
class Config:
    HF_TOKEN = "hf_xxxxxxxxxxxxxxxxxxxxxx"
    DATA_PATH = "/home/f223085/iqra/pd.csv"
    MODEL_NAME = "nlpie/tiny-biobert"
    MODEL_DIR = "/home/f223085/iqra/Sumair/fine_tuned_model"  # Keep original model path
    EMBEDDINGS_PATH = os.path.join(BASE_DIR, "case_embeddings.npy")
    DB_PATH = os.path.join(BASE_DIR, "user_profiles.db")
    HNSW_INDEX_PATH = os.path.join(BASE_DIR, "case_embeddings_hnsw.bin")
    MAX_LENGTH = 64
    NUM_EPOCHS = 2
    TRAIN_BATCH_SIZE = 2
    LEARNING_RATE = 2e-5
    TOP_K = 5
    BATCH_SIZE = 8
    SIMILARITY_THRESHOLD = 0.7
    LR_STEP_SIZE = 1
    LR_GAMMA = 0.1
    TOXICITY_MODEL = None
    EMBEDDING_DIM = None
    HNSW_M = 16
    HNSW_EF_CONSTRUCTION = 200
    HNSW_EF_SEARCH = 50

    @staticmethod
    def init_toxicity_model():
        try:
            Config.TOXICITY_MODEL = detoxify.Detoxify('original')
            logger.info("Detoxify model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Detoxify model: {e}. Skipping toxicity checks.")
            with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                f.write(f"Failed to load Detoxify model: {e}. Skipping toxicity checks.\n")

# Initialize environment
def init_environment():
    os.makedirs(os.path.join(BASE_DIR, "hf_cache"), exist_ok=True)
    os.makedirs(os.path.join(BASE_DIR, "nltk_data"), exist_ok=True)
    os.environ["http_proxy"] = "http://192.168.150.150:3128"
    os.environ["https_proxy"] = "http://192.168.150.150:3128"
    try:
        nltk.download('wordnet', download_dir=os.path.join(BASE_DIR, "nltk_data"), quiet=True)
        logger.info("NLTK wordnet downloaded successfully.")
    except Exception as e:
        logger.error(f"Failed to download NLTK wordnet: {e}. Skipping toxicity checks.")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Failed to download NLTK wordnet: {e}. Skipping toxicity checks.\n")

# Initialize user profile database
def init_database():
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                name TEXT UNIQUE,
                gender TEXT,
                city TEXT,
                past_symptoms TEXT,
                ratings TEXT
            )
        """)
        users = [
            ("1", "Iqra", "Female", "Kabirwala", "[]", "{}"),
            ("2", "Moafi", "Female", "Lahore", "[]", "{}"),
            ("3", "Sumair", "Male", "Quetta", "[]", "{}")
        ]
        cursor.executemany("INSERT OR IGNORE INTO users VALUES (?, ?, ?, ?, ?, ?)", users)
        conn.commit()
    logger.info("Initialized user profile database.")
    with open(os.path.join(BASE_DIR, "output_log.txt"), "a") as f:
        f.write("Initialized user profile database.\n")

# Load and preprocess data
def load_and_preprocess_data() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    try:
        df = pd.read_csv(Config.DATA_PATH)
        if df.empty:
            raise ValueError("Dataset is empty.")
        logger.info(f"Loaded dataset with {len(df)} rows.")
    except FileNotFoundError as e:
        logger.error(f"File {Config.DATA_PATH} not found: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"File {Config.DATA_PATH} not found: {e}\n")
        raise

    required_columns = [
        "CommonAgeGroup", "Sex", "Severity", "Specialist", "Name", "Address/Details",
        "City", "Rating", "Mapped_Category", "Processed_Symptoms", "Processed_Disease",
        "Processed_Treatment"
    ]
    if not all(col in df.columns for col in required_columns):
        raise ValueError("Missing required columns in pd.csv.")

    df = df.dropna(subset=["Processed_Symptoms", "Processed_Disease", "Processed_Treatment"])
    df = df.sample(frac=0.8, random_state=42)
    df["Rating"] = df["Rating"].astype(float)
    df.to_pickle(os.path.join(BASE_DIR, "processed_data.pkl"))

    interaction_matrix = df.pivot_table(index="Processed_Symptoms", columns="Name", values="Rating", fill_value=0)
    doctor_similarity = cosine_similarity(interaction_matrix.T)
    doctor_similarity_df = pd.DataFrame(
        doctor_similarity, index=interaction_matrix.columns, columns=interaction_matrix.columns
    )
    logger.info("Processed dataset and created doctor similarity matrix.")
    return df, doctor_similarity_df, interaction_matrix

# Load model and tokenizer
def load_tokenizer_and_model() -> Tuple[AutoTokenizer, AutoModelForMaskedLM, torch.device]:
    login(token=Config.HF_TOKEN)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")

    try:
        tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_DIR, trust_remote_code=True)
        model = AutoModelForMaskedLM.from_pretrained(
            Config.MODEL_DIR,
            trust_remote_code=True,
            use_safetensors=True
        )
        model = prepare_model_for_kbit_training(model)
        lora_config = LoraConfig(
            r=8,
            lora_alpha=32,
            target_modules=["query", "value"],
            lora_dropout=0.05,
            bias="none",
            task_type="MASKED"
        )
        model = get_peft_model(model, lora_config)
        model.to(device)
        sample_input = tokenizer("test", return_tensors="pt").to(device)
        with torch.no_grad():
            Config.EMBEDDING_DIM = model(**sample_input, output_hidden_states=True).hidden_states[-1].shape[-1]
        logger.info(f"Loaded fine-tuned model from {Config.MODEL_DIR} with LoRA on {device}, EMBEDDING_DIM={Config.EMBEDDING_DIM}")
    except Exception as e:
        logger.error(f"Model loading failed: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Model loading failed: {e}\n")
        raise
    return tokenizer, model, device

# Build HNSW index
def build_hnsw_index(embeddings: np.ndarray) -> hnswlib.Index:
    dim = embeddings.shape[1]
    num_elements = embeddings.shape[0]
    index = hnswlib.Index(space='cosine', dim=dim)
    index.init_index(max_elements=num_elements, ef_construction=Config.HNSW_EF_CONSTRUCTION, M=Config.HNSW_M)
    index.add_items(embeddings, np.arange(num_elements))
    index.save_index(Config.HNSW_INDEX_PATH)
    logger.info(f"Built and saved HNSW index with {num_elements} elements.")
    return index

# Load or build HNSW index
def load_or_build_hnsw_index(embeddings: np.ndarray) -> hnswlib.Index:
    if os.path.exists(Config.HNSW_INDEX_PATH):
        try:
            index = hnswlib.Index(space='cosine', dim=embeddings.shape[1])
            index.load_index(Config.HNSW_INDEX_PATH, max_elements=embeddings.shape[0])
            index.set_ef(Config.HNSW_EF_SEARCH)
            logger.info(f"Loaded HNSW index from {Config.HNSW_INDEX_PATH}.")
            return index
        except Exception as e:
            logger.warning(f"Failed to load HNSW index: {e}. Rebuilding index.")
    return build_hnsw_index(embeddings)

# Extract semantic features
def extract_semantic_features(text: str, model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
                             device: torch.device) -> np.ndarray:
    inputs = tokenizer(
        text, return_tensors="pt", max_length=Config.MAX_LENGTH,
        truncation=True, padding=True
    ).to(device)
    try:
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
            features = torch.mean(outputs.hidden_states[-1], dim=1).to(torch.float32)
            logger.info(f"Extracted features with shape: {features.shape}")
        return features.cpu().numpy().flatten()
    except Exception as e:
        logger.error(f"Error extracting semantic features: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error extracting semantic features: {e}\n")
        return np.zeros(Config.EMBEDDING_DIM)

# Load case embeddings
def load_case_embeddings() -> np.ndarray:
    try:
        embeddings = np.load(Config.EMBEDDINGS_PATH)
        logger.info(f"Loaded case embeddings with shape: {embeddings.shape}")
        return embeddings
    except Exception as e:
        logger.error(f"Error loading case embeddings: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error loading case embeddings: {e}\n")
        raise

# Preprocess input
def preprocess_input(patient_data: Dict) -> str:
    symptoms = patient_data["symptoms"].lower().strip()
    history = patient_data.get("history", "").lower().strip()
    labs = patient_data.get("labs", "").lower().strip()
    return f"Symptoms: {symptoms}. History: {history}. Labs: {labs}."

# Compute metrics
def compute_metrics(recommendations: Dict, df: pd.DataFrame, case_embeddings: np.ndarray,
                    model: AutoModelForMaskedLM, tokenizer: AutoTokenizer, device: torch.device,
                    top_k: int = Config.TOP_K) -> Tuple[Dict, List, List, List]:
    y_true = []
    y_pred = []
    y_scores = []
    latencies = []
    toxicities = []
    ranks = []
    recommended_items = set()
    total_items = len(df["Processed_Disease"].unique())
    item_popularity = df["Processed_Disease"].value_counts().to_dict()
    similarities = []
    personalization_scores = []
    robustness_scores = []
    ctr_simulations = []

    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for name, rec in recommendations.items():
            symptoms = rec["symptoms"]
            predicted_conditions = [cond["Condition"] for cond in rec["likely_conditions"]]
            scores = [cond["Score"] for cond in rec["likely_conditions"]]
            actual_conditions = df[df["Processed_Symptoms"].str.lower() == symptoms.lower()]["Processed_Disease"].values
            actual_condition = actual_conditions[0] if len(actual_conditions) > 0 else "Unknown"

            y_true.append(actual_condition)
            y_pred.append(predicted_conditions[:top_k] if predicted_conditions else ["Unknown"] * top_k)
            y_scores.append(scores[:top_k] if scores else [0.0] * top_k)
            latencies.append(rec["latency"])

            if Config.TOXICITY_MODEL:
                for cond in rec["likely_conditions"][:top_k]:
                    try:
                        toxicities.append(float(Config.TOXICITY_MODEL.predict(cond["Treatment"])["toxicity"]))
                    except Exception as e:
                        logger.warning(f"Error computing toxicity: {e}")
                        toxicities.append(0.0)

            for i, cond in enumerate(predicted_conditions[:top_k], 1):
                if cond == actual_condition:
                    ranks.append(i)
                    break
            else:
                ranks.append(0)

            recommended_items.update(predicted_conditions[:top_k])
            similarities.extend([item_popularity.get(cond, 1) / sum(item_popularity.values()) for cond in predicted_conditions[:top_k]])

            cursor.execute("SELECT past_symptoms FROM users WHERE name=?", (name,))
            result = cursor.fetchone()
            past_symptoms = json.loads(result[0]) if result else []
            personalization_scores.append(len(set(predicted_conditions[:top_k]).intersection(set(past_symptoms))) / top_k if past_symptoms else 0)

            variations = [symptoms, symptoms.replace(",", ", "), symptoms.upper()]
            robust_preds = []
            for var in variations:
                norm_text = preprocess_input({"symptoms": var, "history": "", "labs": ""})
                try:
                    emb = extract_semantic_features(norm_text, model, tokenizer, device)
                    index = load_or_build_hnsw_index(case_embeddings)
                    top_indices, top_similarities = index.knn_query(emb[np.newaxis, :], k=top_k)
                    top_indices = top_indices[0]
                    robust_preds.append([df.iloc[i]["Processed_Disease"] for i in top_indices])
                except Exception as e:
                    logger.error(f"Error during robustness check for {name}: {e}")
                    robust_preds.append(predicted_conditions[:top_k])
            robustness_scores.append(float(np.mean([len(set(predicted_conditions[:top_k]).intersection(set(rp))) / top_k for rp in robust_preds])) if robust_preds else 0.0)

            ctr_simulations.append(random.random() < 0.1 * len(predicted_conditions[:top_k]))

    precision_k = float(np.mean([len(set(p[:top_k]).intersection([t])) / top_k for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    recall_k = float(np.mean([len(set(p[:top_k]).intersection([t])) / len([t]) for p, t in zip(y_pred, y_true) if t != "Unknown"] if y_pred else [0.0]))
    f1 = float(np.mean([f1_score([t], [p[0]], average="weighted", zero_division=0) for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    mse = float(mean_squared_error([1 if t != "Unknown" else 0 for t in y_true], [1 if p[0] != "Unknown" else 0 for p in y_pred]) if y_pred else 0.0)
    rmse = float(np.sqrt(mse))
    ndcg_k = float(np.mean([sum([(2 ** rel - 1) / np.log2(i + 2) for i, rel in enumerate(scores[:top_k])]) /
                            sum([(2 ** 1 - 1) / np.log2(i + 2) for i in range(len(scores[:top_k]))]) for scores in y_scores] if y_scores else [0.0]))
    map_k = float(np.mean([sum([1 / (i + 1) for i, p in enumerate(pred[:top_k]) if p == t]) / top_k for pred, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    hit_rate_k = float(np.mean([1 if t in p[:top_k] else 0 for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    mrr = float(np.mean([1 / r if r > 0 else 0 for r in ranks] if ranks else [0.0]))
    coverage = float(len(recommended_items) / total_items if total_items > 0 else 0.0)
    novelty = float(1 - np.mean(similarities) if similarities else 0.0)
    diversity = float(1 - np.mean([cosine_similarity([case_embeddings[i]], [case_embeddings[j]])[0][0]
                                   for i in range(len(case_embeddings))
                                   for j in range(i + 1, min(len(case_embeddings), i + 10))] if len(case_embeddings) > 1 else [0.0]))
    serendipity = float(novelty * diversity)
    avg_toxicity = float(np.mean(toxicities) if toxicities else 0.0)
    hallucination_rate = float(np.mean([1 if p[0] not in df["Processed_Disease"].values else 0 for p in y_pred] if y_pred else [0.0]))
    personalization = float(np.mean(personalization_scores) if personalization_scores else 0.0)
    robustness = float(np.mean(robustness_scores) if robustness_scores else 0.0)
    ctr = float(np.mean(ctr_simulations) if ctr_simulations else 0.0)
    alignment = float(np.mean([1 if t in p[:top_k] else 0 for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    explainability = 0.8

    metrics = {
        "precision_k": precision_k,
        "recall_k": recall_k,
        "f1_score": f1,
        "mse": mse,
        "rmse": rmse,
        "ndcg_k": ndcg_k,
        "map_k": map_k,
        "hit_rate_k": hit_rate_k,
        "mrr": mrr,
        "coverage": coverage,
        "novelty": novelty,
        "serendipity": serendipity,
        "diversity": diversity,
        "toxicity": avg_toxicity,
        "hallucination_rate": hallucination_rate,
        "personalization": personalization,
        "robustness": robustness,
        "ctr": ctr,
        "explainability": explainability,
        "avg_latency": float(np.mean(latencies) if latencies else 0.0)
    }
    try:
        with open(os.path.join(BASE_DIR, "inference_metrics_hnsw.json"), "w") as f:
            json.dump(metrics, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving inference metrics: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error saving inference metrics: {e}\n")
    return metrics, y_true, y_pred, y_scores

# Inference with HNSW
def inference(patient_data: List[Dict], model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
              df: pd.DataFrame, doctor_similarity_df: pd.DataFrame, case_embeddings: np.ndarray,
              device: torch.device) -> Dict:
    model.eval()
    recommendations = {}
    index = load_or_build_hnsw_index(case_embeddings)
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for patient in patient_data:
            start_time = time.time()
            name = patient["name"]
            symptoms = patient["symptoms"]
            logger.info(f"Processing patient: {name}, Symptoms: {symptoms}")
            print(f"\nProcessing patient: {name}, Symptoms: {symptoms}")

            normalized_text = preprocess_input(patient)
            try:
                patient_embedding = extract_semantic_features(normalized_text, model, tokenizer, device)
                top_indices, top_similarities = index.knn_query(patient_embedding[np.newaxis, :], k=Config.TOP_K)
                top_indices = top_indices[0]
                top_similarities = top_similarities[0]
                similar_cases = df.iloc[top_indices]
                logger.info("Retrieved similar cases using HNSW.")
            except Exception as e:
                logger.error(f"Error during inference: {e}")
                with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                    f.write(f"Error during inference: {e}\n")
                continue

            likely_conditions = []
            seen_conditions = set()
            for idx, sim_score in zip(top_indices, top_similarities):
                if sim_score >= Config.SIMILARITY_THRESHOLD:
                    row = df.iloc[idx]
                    condition = row["Processed_Disease"]
                    if condition not in seen_conditions:
                        seen_conditions.add(condition)
                        likely_conditions.append({
                            "Condition": condition,
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(sim_score)
                        })

            content_doctors = [cond["Doctor"] for cond in likely_conditions]
            cf_conditions = []
            seen_cf_conditions = set()
            for doctor in content_doctors:
                if doctor in doctor_similarity_df.columns:
                    similar_doctors = doctor_similarity_df[doctor].sort_values(ascending=False).head(2).index
                    for sim_doc in similar_doctors:
                        if sim_doc != doctor:
                            sim_row = df[df["Name"] == sim_doc].head(1)
                            if not sim_row.empty:
                                sim_score = doctor_similarity_df.loc[sim_doc, doctor]
                                condition = sim_row["Processed_Disease"].iloc[0]
                                if condition not in seen_conditions and condition not in seen_cf_conditions:
                                    seen_cf_conditions.add(condition)
                                    cf_conditions.append({
                                        "Condition": condition,
                                        "Doctor": sim_row["Name"].iloc[0],
                                        "Treatment": sim_row["Processed_Treatment"].values[0],
                                        "Specialist": sim_row["Specialist"].values[0],
                                        "Rating": float(sim_row["Rating"].values[0]),
                                        "Address": sim_row["Address/Details"].values[0],
                                        "City": sim_row["City"].iloc[0],
                                        "Score": float(sim_score * 0.3)
                                    })

            if not likely_conditions:
                logger.warning(f"Cold start for {name}. Using default recommendations.")
                default_conditions = df.sample(Config.TOP_K)
                likely_conditions = []
                seen_conditions = set()
                for _, row in default_conditions.iterrows():
                    condition = row["Processed_Disease"]
                    if condition not in seen_conditions:
                        seen_conditions.add(condition)
                        likely_conditions.append({
                            "Condition": condition,
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": 0.5
                        })

            likely_condition_names = list(dict.fromkeys([cond["Condition"] for cond in likely_conditions]))
            other_condition_names = list(dict.fromkeys([cond["Condition"] for cond in cf_conditions]))
            specialists = defaultdict(set)
            for cond in likely_conditions:
                specialists[cond["Condition"]].add(cond["Specialist"])

            print("--- Likely Conditions Based on Your Symptoms ---")
            print(", ".join(likely_condition_names) if likely_condition_names else "None")
            print("\n--- Other Conditions You Might Consider ---")
            print(", ".join(other_condition_names) if other_condition_names else "None")
            print("\n--- Specialist Recommendations ---")
            printed_specialists = set()
            for symptom in set(symptoms.strip().split(",")):
                symptom = symptom.strip()
                symptom_conditions = df[
                    df["Processed_Symptoms"].str.contains(symptom.lower(), case=False, na=False)
                ]["Processed_Disease"].tolist()
                for cond in set(symptom_conditions):
                    if cond in specialists:
                        for spec in specialists[cond]:
                            recommendation = f"For {symptom}, consulting a {spec} is recommended."
                            if recommendation not in printed_specialists:
                                print(recommendation)
                                printed_specialists.add(recommendation)

            print("\n--- Doctor and Treatment Recommendations for Likely Conditions ---")
            for cond in likely_conditions:
                print(f"Disease: {cond['Condition']}\nDoctor: {cond['Doctor']}\nSpecialist: {cond['Specialist']}\n"
                      f"Treatment: {cond['Treatment']}\nRating: {cond['Rating']}\nAddress: {cond['Address']}\nCity: {cond['City']}\n{'-' * 36}")

            print("\n--- Recommendations for Other Conditions ---")
            for cond in cf_conditions:
                print(f"Disease: {cond['Condition']}\nDoctor: {cond['Doctor']}\nSpecialist: {cond['Specialist']}\n"
                      f"Treatment: {cond['Treatment']}\nRating: {cond['Rating']}\nAddress: {cond['Address']}\nCity: {cond['City']}\n{'-' * 36}")

            cursor.execute("SELECT past_symptoms, ratings FROM users WHERE name=?", (name,))
            user_data = cursor.fetchone()
            if user_data:
                past_symptoms = json.loads(user_data[0])
                ratings = json.loads(user_data[1])
                past_symptoms.append(symptoms)
                for cond in likely_conditions + cf_conditions:
                    ratings[cond["Doctor"]] = ratings.get(cond["Doctor"], float(cond["Rating"]))
                cursor.execute(
                    "UPDATE users SET past_symptoms=?, ratings=? WHERE name=?",
                    (json.dumps(past_symptoms), json.dumps(ratings), name)
                )
                conn.commit()

            recommendations[name] = {
                "symptoms": symptoms,
                "likely_conditions": likely_conditions,
                "other_conditions": cf_conditions,
                "latency": float(time.time() - start_time)
            }

    logger.info("Inference with HNSW completed successfully.")
    return recommendations

# Plot visualizations
def plot_visualizations(y_true: List, y_pred: List, y_scores: List, df: pd.DataFrame,
                       interaction_matrix: pd.DataFrame, case_embeddings: np.ndarray,
                       learning_rates: List[float], original_latencies: List[float],
                       hnsw_latencies: List[float]) -> Dict[str, str]:
    plots_dir = os.path.join(BASE_DIR, "plots_hnsw")
    os.makedirs(plots_dir, exist_ok=True)

    def plot_to_base64() -> str:
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        buf.seek(0)
        return base64.b64encode(buf.read()).decode("utf-8")

    plots = {}

    # Loss curve (placeholder, using metrics from file)
    try:
        with open(os.path.join(BASE_DIR, "train_eval_results.json"), "r") as f:
            eval_results = json.load(f)
        plt.figure(figsize=(10, 6))
        plt.plot([eval_results.get("eval_loss", 0)], label="Validation Loss")
        plt.xlabel("Evaluation")
        plt.ylabel("Loss")
        plt.title("Validation Loss (From Previous Training)")
        plt.legend()
        plt.savefig(os.path.join(plots_dir, "loss_curve.png"), format="png", bbox_inches="tight")
        plots["loss_curve"] = plot_to_base64()
        plt.close()
        logger.info("Generated loss curve plot.")
    except Exception as e:
        logger.warning(f"Could not load eval results for loss curve: {e}")

    # Accuracy curve (placeholder, using metrics from file)
    try:
        with open(os.path.join(BASE_DIR, "train_eval_results.json"), "r") as f:
            eval_results = json.load(f)
        plt.figure(figsize=(10, 6))
        plt.plot([eval_results.get("eval_accuracy", 0)], label="Accuracy")
        plt.plot([eval_results.get("eval_precision", 0)], label="Precision")
        plt.plot([eval_results.get("eval_recall", 0)], label="Recall")
        plt.xlabel("Evaluation")
        plt.ylabel("Metric")
        plt.title("Validation Metrics (From Previous Training)")
        plt.legend()
        plt.savefig(os.path.join(plots_dir, "accuracy_curve.png"), format="png", bbox_inches="tight")
        plots["accuracy_curve"] = plot_to_base64()
        plt.close()
        logger.info("Generated accuracy curve plot.")
    except Exception as e:
        logger.warning(f"Could not load eval results for accuracy curve: {e}")

    # Confusion matrix
    y_pred_classes = [p[0] if p else "Unknown" for p in y_pred]
    unique_classes = sorted(set(y_true + y_pred_classes))
    if len(unique_classes) > 1:
        cm = confusion_matrix(y_true, y_pred_classes, labels=unique_classes)
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=unique_classes, yticklabels=unique_classes)
        plt.title("Confusion Matrix")
        plt.xlabel("Predicted Label")
        plt.ylabel("True Label")
        plt.savefig(os.path.join(plots_dir, "confusion_matrix.png"), format="png", bbox_inches="tight")
        plots["confusion_matrix"] = plot_to_base64()
        plt.close()
        logger.info("Generated confusion matrix plot.")

    # t-SNE visualization
    if len(case_embeddings) > 0:
        try:
            tsne = TSNE(n_components=2, random_state=42, n_jobs=-1)
            embeddings_2d = tsne.fit_transform(case_embeddings[:500])
            plt.figure(figsize=(10, 6))
            plt.scatter(embeddings_2d[:, 0], embeddings_2d[:, 1], s=50, alpha=0.5)
            plt.title("t-SNE Visualization of Case Embeddings")
            plt.xlabel("Component 1")
            plt.ylabel("Component 2")
            plt.savefig(os.path.join(plots_dir, "tsne_plot.png"), format="png", bbox_inches="tight")
            plots["tsne"] = plot_to_base64()
            plt.close()
            logger.info("Generated t-SNE plot.")
        except Exception as e:
            logger.error(f"Error generating t-SNE: {e}")
            with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                f.write(f"Error generating t-SNE: {e}\n")

    # Learning rate curve
    if len(learning_rates) > 0:
        plt.figure(figsize=(10, 6))
        plt.plot(learning_rates, label="Learning Rate")
        plt.xlabel("Steps")
        plt.ylabel("Learning Rate")
        plt.title("Learning Rate Over Training Steps")
        plt.legend()
        plt.yscale("log")
        plt.savefig(os.path.join(plots_dir, "learning_rate_curve.png"), format="png", bbox_inches="tight")
        plots["learning_rate"] = plot_to_base64()
        plt.close()
        logger.info("Generated learning rate curve plot.")

    # Latency comparison
    if original_latencies and hnsw_latencies:
        plt.figure(figsize=(10, 6))
        plt.plot(original_latencies, label="Original (Cosine Similarity)")
        plt.plot(hnsw_latencies, label="HNSW")
        plt.xlabel("Query Index")
        plt.ylabel("Latency (seconds)")
        plt.title("Latency Comparison: Original vs HNSW")
        plt.legend()
        plt.savefig(os.path.join(plots_dir, "latency_comparison.png"), format="png", bbox_inches="tight")
        plots["latency_comparison"] = plot_to_base64()
        plt.close()
        logger.info("Generated latency comparison plot.")

    try:
        with open(os.path.join(plots_dir, "visualizations_hnsw.json"), "w") as f:
            json.dump(plots, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving visualizations metadata: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error saving visualizations metadata: {e}\n")
    logger.info(f"Saved charts in {plots_dir}")
    return plots

# Main function
def main():
    logger.info("Starting Medical Recommender System with HNSW in V2")
    try:
        init_environment()
        Config.init_toxicity_model()
        init_database()
        df, doctor_similarity_df, interaction_matrix = load_and_preprocess_data()
        tokenizer, model, device = load_tokenizer_and_model()
        case_embeddings = load_case_embeddings()

        learning_rates = []
        for epoch in range(Config.NUM_EPOCHS):
            lr = Config.LEARNING_RATE * (Config.LR_GAMMA ** (epoch // Config.LR_STEP_SIZE))
            learning_rates.extend([lr] * (len(df) // Config.TRAIN_BATCH_SIZE))

        patient_data = [
            {"name": "Iqra", "symptoms": "headache, flu, fever, full body pain", "history": "Previous flu episodes"},
            {"name": "Moafi", "symptoms": "loss appetite, queasiness", "history": "Recent travel"},
            {"name": "Sumair", "symptoms": "chest pain, shortness of breath", "history": "Hypertension"}
        ]

        # Run original inference for latency comparison
        original_latencies = []
        logger.info("Running original inference for latency comparison")
        recommendations_original = inference_original(
            patient_data, model, tokenizer, df, doctor_similarity_df, case_embeddings, device
        )
        for name, rec in recommendations_original.items():
            original_latencies.append(rec["latency"])

        # Run HNSW inference
        recommendations = inference(
            patient_data, model, tokenizer, df, doctor_similarity_df, case_embeddings, device
        )
        metrics, y_true, y_pred, y_scores = compute_metrics(
            recommendations, df, case_embeddings, model, tokenizer, device
        )
        hnsw_latencies = [rec["latency"] for _, rec in recommendations.items()]

        plot_visualizations(
            y_true, y_pred, y_scores, df, interaction_matrix, case_embeddings,
            learning_rates, original_latencies, hnsw_latencies
        )

        print(f"\nEvaluation Metrics with HNSW: {metrics}")
        logger.info("Medical Recommender System with HNSW execution completed successfully")
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error in main execution: {e}\n")
        raise

# Original inference for latency comparison
def inference_original(patient_data: List[Dict], model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
                       df: pd.DataFrame, doctor_similarity_df: pd.DataFrame, case_embeddings: np.ndarray,
                       device: torch.device) -> Dict:
    model.eval()
    recommendations = {}
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for patient in patient_data:
            start_time = time.time()
            name = patient["name"]
            symptoms = patient["symptoms"]
            normalized_text = preprocess_input(patient)
            try:
                patient_embedding = extract_semantic_features(normalized_text, model, tokenizer, device)
                similarities = cosine_similarity([patient_embedding], case_embeddings)[0]
                top_indices = np.argsort(similarities)[-Config.TOP_K:][::-1]
                top_similarities = similarities[top_indices]
                similar_cases = df.iloc[top_indices]
            except Exception as e:
                logger.error(f"Error during original inference: {e}")
                with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                    f.write(f"Error during original inference: {e}\n")
                continue

            likely_conditions = []
            seen_conditions = set()
            for idx, sim_score in zip(top_indices, top_similarities):
                if sim_score >= Config.SIMILARITY_THRESHOLD:
                    row = df.iloc[idx]
                    condition = row["Processed_Disease"]
                    if condition not in seen_conditions:
                        seen_conditions.add(condition)
                        likely_conditions.append({
                            "Condition": condition,
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(sim_score)
                        })

            content_doctors = [cond["Doctor"] for cond in likely_conditions]
            cf_conditions = []
            seen_cf_conditions = set()
            for doctor in content_doctors:
                if doctor in doctor_similarity_df.columns:
                    similar_doctors = doctor_similarity_df[doctor].sort_values(ascending=False).head(2).index
                    for sim_doc in similar_doctors:
                        if sim_doc != doctor:
                            sim_row = df[df["Name"] == sim_doc].head(1)
                            if not sim_row.empty:
                                sim_score = doctor_similarity_df.loc[sim_doc, doctor]
                                condition = sim_row["Processed_Disease"].iloc[0]
                                if condition not in seen_conditions and condition not in seen_cf_conditions:
                                    seen_cf_conditions.add(condition)
                                    cf_conditions.append({
                                        "Condition": condition,
                                        "Doctor": sim_row["Name"].iloc[0],
                                        "Treatment": sim_row["Processed_Treatment"].values[0],
                                        "Specialist": sim_row["Specialist"].values[0],
                                        "Rating": float(sim_row["Rating"].values[0]),
                                        "Address": sim_row["Address/Details"].values[0],
                                        "City": sim_row["City"].iloc[0],
                                        "Score": float(sim_score * 0.3)
                                    })

            recommendations[name] = {
                "symptoms": symptoms,
                "likely_conditions": likely_conditions,
                "other_conditions": cf_conditions,
                "latency": float(time.time() - start_time)
            }
    return recommendations

if __name__ == "__main__":
    main()