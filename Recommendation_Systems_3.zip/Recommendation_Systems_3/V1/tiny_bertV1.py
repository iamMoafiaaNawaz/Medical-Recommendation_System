import os
import sqlite3
import json
import time
import logging
import gc
import math
import random
import base64
from io import BytesIO
from collections import defaultdict
from typing import Dict, List, Tuple, Optional
import pandas as pd
import numpy as np
import nltk
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from torch.utils.data import Dataset
from sklearn.metrics import precision_score, recall_score, f1_score, mean_squared_error, confusion_matrix
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
from transformers import AutoTokenizer, AutoModelForMaskedLM, Trainer, TrainingArguments, EvalPrediction
from peft import prepare_model_for_kbit_training, LoraConfig, get_peft_model
from huggingface_hub import login
import detoxify

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
BASE_DIR = "/home/f223085/iqra/Sumair"
os.makedirs(BASE_DIR, exist_ok=True)
file_handler = logging.FileHandler(os.path.join(BASE_DIR, "recommender.log"))
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)

# Configuration class
class Config:
    HF_TOKEN = "hf_xxxxxxxxxxxxxxxxxxxxxxx"
    DATA_PATH = "/home/f223085/iqra/pd.csv"
    MODEL_NAME = "nlpie/tiny-biobert"
    MODEL_DIR = os.path.join(BASE_DIR, "fine_tuned_model")
    EMBEDDINGS_PATH = os.path.join(BASE_DIR, "case_embeddings.npy")
    DB_PATH = os.path.join(BASE_DIR, "user_profiles.db")
    MAX_LENGTH = 64
    NUM_EPOCHS = 2
    TRAIN_BATCH_SIZE = 2
    LEARNING_RATE = 2e-5
    TOP_K = 5
    BATCH_SIZE = 8
    SIMILARITY_THRESHOLD = 0.7
    LR_STEP_SIZE = 1
    LR_GAMMA = 0.1
    TOXICITY_MODEL = None
    EMBEDDING_DIM = None

    @staticmethod
    def init_toxicity_model():
        try:
            Config.TOXICITY_MODEL = detoxify.Detoxify('original')
            logger.info("Detoxify model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Detoxify model: {e}. Skipping toxicity checks.")
            with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                f.write(f"Failed to load Detoxify model: {e}. Skipping toxicity checks.\n")

# Initialize environment
def init_environment():
    os.makedirs("/home/f223085/hf_cache", exist_ok=True)
    os.makedirs("/home/f223085/nltk_data", exist_ok=True)
    os.environ["http_proxy"] = "http://192.168.150.150:3128"
    os.environ["https_proxy"] = "http://192.168.150.150:3128"
    try:
        nltk.download('wordnet', download_dir="/home/f223085/nltk_data", quiet=True)
        logger.info("NLTK wordnet downloaded successfully.")
    except Exception as e:
        logger.error(f"Failed to download NLTK wordnet: {e}. Skipping toxicity checks.")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Failed to download NLTK wordnet: {e}. Skipping toxicity checks.\n")

# Initialize user profile database
def init_database():
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                name TEXT UNIQUE,
                gender TEXT,
                city TEXT,
                past_symptoms TEXT,
                ratings TEXT
            )
        """)
        users = [
            ("1", "Iqra", "Female", "Kabirwala", "[]", "{}"),
            ("2", "Moafi", "Female", "Lahore", "[]", "{}"),
            ("3", "Sumair", "Male", "Quetta", "[]", "{}")
        ]
        cursor.executemany("INSERT OR IGNORE INTO users VALUES (?, ?, ?, ?, ?, ?)", users)
        conn.commit()
    logger.info("Initialized user profile database.")
    with open(os.path.join(BASE_DIR, "output_log.txt"), "a") as f:
        f.write("Initialized user profile database.\n")

# Load and preprocess data
def load_and_preprocess_data() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    try:
        df = pd.read_csv(Config.DATA_PATH)
        if df.empty:
            raise ValueError("Dataset is empty.")
        logger.info(f"Loaded dataset with {len(df)} rows.")
    except FileNotFoundError as e:
        logger.error(f"File {Config.DATA_PATH} not found: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"File {Config.DATA_PATH} not found: {e}\n")
        raise

    required_columns = [
        "CommonAgeGroup", "Sex", "Severity", "Specialist", "Name", "Address/Details",
        "City", "Rating", "Mapped_Category", "Processed_Symptoms", "Processed_Disease",
        "Processed_Treatment"
    ]
    if not all(col in df.columns for col in required_columns):
        raise ValueError("Missing required columns in pd.csv.")

    df = df.dropna(subset=["Processed_Symptoms", "Processed_Disease", "Processed_Treatment"])
    df = df.sample(frac=0.8, random_state=42)
    df["Rating"] = df["Rating"].astype(float)
    df.to_pickle(os.path.join(BASE_DIR, "processed_data.pkl"))

    interaction_matrix = df.pivot_table(index="Processed_Symptoms", columns="Name", values="Rating", fill_value=0)
    doctor_similarity = cosine_similarity(interaction_matrix.T)
    doctor_similarity_df = pd.DataFrame(
        doctor_similarity, index=interaction_matrix.columns, columns=interaction_matrix.columns
    )
    logger.info("Processed dataset and created doctor similarity matrix.")
    return df, doctor_similarity_df, interaction_matrix

# Load model and tokenizer
def load_tokenizer_and_model() -> Tuple[AutoTokenizer, AutoModelForMaskedLM, torch.device]:
    login(token=Config.HF_TOKEN)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")

    tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_NAME, trust_remote_code=True)
    try:
        model = AutoModelForMaskedLM.from_pretrained(
            Config.MODEL_NAME,
            trust_remote_code=True,
            use_safetensors=False
        )
        model = prepare_model_for_kbit_training(model)
        lora_config = LoraConfig(
            r=8,
            lora_alpha=32,
            target_modules=["query", "value"],
            lora_dropout=0.05,
            bias="none",
            task_type="MASKED"
        )
        model = get_peft_model(model, lora_config)
        model.to(device)
        sample_input = tokenizer("test", return_tensors="pt").to(device)
        with torch.no_grad():
            Config.EMBEDDING_DIM = model(**sample_input, output_hidden_states=True).hidden_states[-1].shape[-1]
        logger.info(f"Loaded {Config.MODEL_NAME} with LoRA on {device}, EMBEDDING_DIM={Config.EMBEDDING_DIM}")
    except Exception as e:
        logger.error(f"Model loading failed: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Model loading failed: {e}\n")
        raise
    return tokenizer, model, device

# Custom dataset for fine-tuning
class MedicalDataset(Dataset):
    def __init__(self, df: pd.DataFrame, tokenizer: AutoTokenizer, max_length: int):
        self.df = df
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]
        input_text = (
            f"Symptoms: {row['Processed_Symptoms']}. Age: {row['CommonAgeGroup']}. "
            f"Sex: {row['Sex']}. Severity: {row['Severity']}."
        )
        target_text = (
            f"Condition: {row['Processed_Disease']}. Doctor: {row['Name']}. "
            f"Treatment: {row['Processed_Treatment']}. Specialist: {row['Specialist']}."
        )
        inputs = self.tokenizer(
            input_text, max_length=self.max_length, padding="max_length",
            truncation=True, return_tensors="pt"
        )
        targets = self.tokenizer(
            target_text, max_length=self.max_length, padding="max_length",
            truncation=True, return_tensors="pt"
        )
        labels = targets["input_ids"].clone()
        labels[labels == self.tokenizer.pad_token_id] = -100
        return {
            "input_ids": inputs["input_ids"].squeeze(),
            "attention_mask": inputs["attention_mask"].squeeze(),
            "labels": labels.squeeze()
        }

# Custom Trainer for evaluation
class CustomEvalPrediction(EvalPrediction):
    def __init__(self, predictions: torch.Tensor, label_ids: torch.Tensor, metrics: Dict, num_samples: int):
        super().__init__(predictions=predictions, label_ids=label_ids)
        self.metrics = metrics
        self.num_samples = num_samples

class CustomTrainer(Trainer):
    def evaluation_loop(self, dataloader, description: str, prediction_loss_only: Optional[bool] = None,
                        ignore_keys: Optional[List[str]] = None, metric_key_prefix: str = "eval") -> CustomEvalPrediction:
        self.model.eval()
        total_eval_loss = 0.0
        total_samples = 0
        all_preds = []
        all_labels = []

        for step, inputs in enumerate(dataloader):
            inputs = self._prepare_inputs(inputs)
            with torch.no_grad():
                outputs = self.model(**inputs)
                loss = outputs.loss
                logits = outputs.logits
                total_eval_loss += loss.item() * inputs["input_ids"].size(0)
                total_samples += inputs["input_ids"].size(0)
                all_preds.append(logits.cpu())
                all_labels.append(inputs["labels"].cpu())

            if (step + 1) % self.args.eval_accumulation_steps == 0:
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

        all_preds = torch.cat(all_preds, dim=0)
        all_labels = torch.cat(all_labels, dim=0)

        metrics = self.compute_metrics(EvalPrediction(predictions=all_preds, label_ids=all_labels)) if self.compute_metrics else {}
        metrics[f"{metric_key_prefix}_loss"] = total_eval_loss / total_samples

        return CustomEvalPrediction(
            predictions=all_preds,
            label_ids=all_labels,
            metrics=metrics,
            num_samples=total_samples
        )

    def compute_metrics(self, eval_pred: EvalPrediction) -> Dict[str, float]:
        predictions, label_ids = eval_pred.predictions, eval_pred.label_ids
        predictions = predictions.argmax(-1).flatten()
        label_ids = label_ids.flatten()
        valid_indices = label_ids != -100
        predictions = predictions[valid_indices]
        label_ids = label_ids[valid_indices]
        return {
            "accuracy": float(np.mean([p == l for p, l in zip(predictions, label_ids)])) if len(predictions) > 0 else 0.0,
            "precision": float(precision_score(label_ids, predictions, average="weighted", zero_division=0)) if len(predictions) > 0 else 0.0,
            "recall": float(recall_score(label_ids, predictions, average="weighted", zero_division=0)) if len(predictions) > 0 else 0.0,
            "f1": float(f1_score(label_ids, predictions, average="weighted", zero_division=0)) if len(predictions) > 0 else 0.0
        }

# Fine-tune model
def fine_tune_model(model: AutoModelForMaskedLM, tokenizer: AutoTokenizer, df: pd.DataFrame,
                    learning_rate: float, device: torch.device) -> CustomTrainer:
    logger.info("Starting training from scratch.")
    train_size = int(0.8 * len(df))
    train_df = df[:train_size]
    val_df = df[train_size:].sample(n=min(500, len(df[train_size:])), random_state=42)
    train_dataset = MedicalDataset(train_df, tokenizer, Config.MAX_LENGTH)
    val_dataset = MedicalDataset(val_df, tokenizer, Config.MAX_LENGTH)

    training_args = TrainingArguments(
        output_dir=os.path.join(BASE_DIR, "results"),
        per_device_train_batch_size=Config.TRAIN_BATCH_SIZE,
        per_device_eval_batch_size=1,
        num_train_epochs=Config.NUM_EPOCHS,
        learning_rate=learning_rate,
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_steps=8,
        save_total_limit=1,
        report_to="none",
        gradient_accumulation_steps=2,
        eval_accumulation_steps=2
    )

    trainer = CustomTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        compute_metrics=lambda eval_pred: {
            "accuracy": float(np.mean([p == l for p, l in zip(eval_pred.predictions.argmax(-1).flatten(), eval_pred.label_ids.flatten())])) if eval_pred.predictions.numel() > 0 else 0.0,
            "precision": float(precision_score(
                eval_pred.label_ids.flatten(), eval_pred.predictions.argmax(-1).flatten(), average="weighted", zero_division=0
            )) if eval_pred.predictions.numel() > 0 else 0.0,
            "recall": float(recall_score(
                eval_pred.label_ids.flatten(), eval_pred.predictions.argmax(-1).flatten(), average="weighted", zero_division=0
            )) if eval_pred.predictions.numel() > 0 else 0.0,
            "f1": float(f1_score(
                eval_pred.label_ids.flatten(), eval_pred.predictions.argmax(-1).flatten(), average="weighted", zero_division=0
            )) if eval_pred.predictions.numel() > 0 else 0.0
        }
    )

    try:
        trainer.train()
        logger.info("Training completed successfully.")
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception as e:
        logger.error(f"Error during training: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error during training: {e}\n")
        raise

    eval_results = trainer.evaluate()
    with open(os.path.join(BASE_DIR, "train_eval_results.json"), "w") as f:
        json.dump(eval_results, f, indent=2)
    model.save_pretrained(Config.MODEL_DIR, safe_serialization=True)
    tokenizer.save_pretrained(Config.MODEL_DIR)
    logger.info("Fine-tuned model and tokenizer saved.")
    return trainer
# Extract semantic features
def extract_semantic_features(text: str, model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
                             device: torch.device) -> np.ndarray:
    inputs = tokenizer(
        text, return_tensors="pt", max_length=Config.MAX_LENGTH,
        truncation=True, padding=True
    ).to(device)
    try:
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
            features = torch.mean(outputs.hidden_states[-1], dim=1).to(torch.float32)
            logger.info(f"Extracted features with shape: {features.shape}")
        return features.cpu().numpy().flatten()
    except Exception as e:
        logger.error(f"Error extracting semantic features: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error extracting semantic features: {e}\n")
        return np.zeros(Config.EMBEDDING_DIM)

# Generate embeddings
def generate_case_embeddings(df: pd.DataFrame, model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
                            device: torch.device) -> np.ndarray:
    model.eval()
    embeddings = []
    max_rows = min(5000, len(df))
    df = df.iloc[:max_rows]

    for i in range(0, len(df), Config.BATCH_SIZE):
        batch_df = df[i:i + Config.BATCH_SIZE]
        batch_embeddings = []
        for _, row in batch_df.iterrows():
            input_text = (
                f"Symptoms: {row['Processed_Symptoms']}. Age: {row['CommonAgeGroup']}. "
                f"Sex: {row['Sex']}. Severity: {row['Severity']}."
            )
            try:
                embedding = extract_semantic_features(input_text, model, tokenizer, device)
                batch_embeddings.append(embedding)
            except Exception as e:
                logger.error(f"Error during embedding generation: {e}")
                with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                    f.write(f"Error during embedding generation: {e}\n")
                batch_embeddings.append(np.zeros(Config.EMBEDDING_DIM))
        embeddings.extend(batch_embeddings)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info(f"Processed batch {i // Config.BATCH_SIZE + 1}/{len(df) // Config.BATCH_SIZE + 1}")

    embeddings = np.array(embeddings, dtype=np.float32)
    np.save(Config.EMBEDDINGS_PATH, embeddings)
    logger.info(f"Generated embeddings with shape: {embeddings.shape}")
    return embeddings

# Preprocess input
def preprocess_input(patient_data: Dict) -> str:
    symptoms = patient_data["symptoms"].lower().strip()
    history = patient_data.get("history", "").lower().strip()
    labs = patient_data.get("labs", "").lower().strip()
    return f"Symptoms: {symptoms}. History: {history}. Labs: {labs}."

# Compute metrics
def compute_metrics(recommendations: Dict, df: pd.DataFrame, case_embeddings: np.ndarray,
                    model: AutoModelForMaskedLM, tokenizer: AutoTokenizer, device: torch.device,
                    top_k: int = Config.TOP_K) -> Tuple[Dict, List, List, List]:
    y_true = []
    y_pred = []
    y_scores = []
    latencies = []
    toxicities = []
    ranks = []
    recommended_items = set()
    total_items = len(df["Processed_Disease"].unique())
    item_popularity = df["Processed_Disease"].value_counts().to_dict()
    similarities = []
    personalization_scores = []
    robustness_scores = []
    ctr_simulations = []

    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for name, rec in recommendations.items():
            symptoms = rec["symptoms"]
            predicted_conditions = [cond["Condition"] for cond in rec["likely_conditions"]]
            scores = [cond["Score"] for cond in rec["likely_conditions"]]
            actual_conditions = df[df["Processed_Symptoms"].str.lower() == symptoms.lower()]["Processed_Disease"].values
            actual_condition = actual_conditions[0] if len(actual_conditions) > 0 else "Unknown"

            y_true.append(actual_condition)
            y_pred.append(predicted_conditions[:top_k] if predicted_conditions else ["Unknown"] * top_k)
            y_scores.append(scores[:top_k] if scores else [0.0] * top_k)
            latencies.append(rec["latency"])

            if Config.TOXICITY_MODEL:
                for cond in rec["likely_conditions"][:top_k]:
                    try:
                        toxicities.append(float(Config.TOXICITY_MODEL.predict(cond["Treatment"])["toxicity"]))
                    except Exception as e:
                        logger.warning(f"Error computing toxicity: {e}")
                        toxicities.append(0.0)

            for i, cond in enumerate(predicted_conditions[:top_k], 1):
                if cond == actual_condition:
                    ranks.append(i)
                    break
            else:
                ranks.append(0)

            recommended_items.update(predicted_conditions[:top_k])
            similarities.extend([item_popularity.get(cond, 1) / sum(item_popularity.values()) for cond in predicted_conditions[:top_k]])

            cursor.execute("SELECT past_symptoms FROM users WHERE name=?", (name,))
            result = cursor.fetchone()
            past_symptoms = json.loads(result[0]) if result else []
            personalization_scores.append(len(set(predicted_conditions[:top_k]).intersection(set(past_symptoms))) / top_k if past_symptoms else 0)

            variations = [symptoms, symptoms.replace(",", ", "), symptoms.upper()]
            robust_preds = []
            for var in variations:
                norm_text = preprocess_input({"symptoms": var, "history": "", "labs": ""})
                try:
                    emb = extract_semantic_features(norm_text, model, tokenizer, device)
                    sims = cosine_similarity([emb], case_embeddings)[0]
                    top_idx = np.argsort(sims)[-top_k:][::-1]
                    robust_preds.append([df.iloc[i]["Processed_Disease"] for i in top_idx])
                except Exception as e:
                    logger.error(f"Error during robustness check for {name}: {e}")
                    robust_preds.append(predicted_conditions[:top_k])
            robustness_scores.append(float(np.mean([len(set(predicted_conditions[:top_k]).intersection(set(rp))) / top_k for rp in robust_preds])) if robust_preds else 0.0)

            ctr_simulations.append(random.random() < 0.1 * len(predicted_conditions[:top_k]))

    precision_k = float(np.mean([len(set(p[:top_k]).intersection([t])) / top_k for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    recall_k = float(np.mean([len(set(p[:top_k]).intersection([t])) / len([t]) for p, t in zip(y_pred, y_true) if t != "Unknown"] if y_pred else [0.0]))
    f1 = float(np.mean([f1_score([t], [p[0]], average="weighted", zero_division=0) for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    mse = float(mean_squared_error([1 if t != "Unknown" else 0 for t in y_true], [1 if p[0] != "Unknown" else 0 for p in y_pred]) if y_pred else 0.0)
    rmse = float(np.sqrt(mse))
    ndcg_k = float(np.mean([sum([(2 ** rel - 1) / np.log2(i + 2) for i, rel in enumerate(scores[:top_k])]) /
                            sum([(2 ** 1 - 1) / np.log2(i + 2) for i in range(len(scores[:top_k]))]) for scores in y_scores] if y_scores else [0.0]))
    map_k = float(np.mean([sum([1 / (i + 1) for i, p in enumerate(pred[:top_k]) if p == t]) / top_k for pred, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    hit_rate_k = float(np.mean([1 if t in p[:top_k] else 0 for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    mrr = float(np.mean([1 / r if r > 0 else 0 for r in ranks] if ranks else [0.0]))
    coverage = float(len(recommended_items) / total_items if total_items > 0 else 0.0)
    novelty = float(1 - np.mean(similarities) if similarities else 0.0)
    diversity = float(1 - np.mean([cosine_similarity([case_embeddings[i]], [case_embeddings[j]])[0][0]
                                   for i in range(len(case_embeddings))
                                   for j in range(i + 1, min(len(case_embeddings), i + 10))] if len(case_embeddings) > 1 else [0.0]))
    serendipity = float(novelty * diversity)
    avg_toxicity = float(np.mean(toxicities) if toxicities else 0.0)
    hallucination_rate = float(np.mean([1 if p[0] not in df["Processed_Disease"].values else 0 for p in y_pred] if y_pred else [0.0]))
    personalization = float(np.mean(personalization_scores) if personalization_scores else 0.0)
    robustness = float(np.mean(robustness_scores) if robustness_scores else 0.0)
    ctr = float(np.mean(ctr_simulations) if ctr_simulations else 0.0)
    alignment = float(np.mean([1 if t in p[:top_k] else 0 for p, t in zip(y_pred, y_true)] if y_pred else [0.0]))
    explainability = 0.8

    metrics = {
        "precision_k": precision_k,
        "recall_k": recall_k,
        "f1_score": f1,
        "mse": mse,
        "rmse": rmse,
        "ndcg_k": ndcg_k,
        "map_k": map_k,
        "hit_rate_k": hit_rate_k,
        "mrr": mrr,
        "coverage": coverage,
        "novelty": novelty,
        "serendipity": serendipity,
        "diversity": diversity,
        "toxicity": avg_toxicity,
        "hallucination_rate": hallucination_rate,
        "personalization": personalization,
        "robustness": robustness,
        "ctr": ctr,
        "explainability": explainability,
        "avg_latency": float(np.mean(latencies) if latencies else 0.0)
    }
    try:
        with open(os.path.join(BASE_DIR, "inference_metrics.json"), "w") as f:
            json.dump(metrics, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving inference metrics: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error saving inference metrics: {e}\n")
    return metrics, y_true, y_pred, y_scores

# Inference
def inference(patient_data: List[Dict], model: AutoModelForMaskedLM, tokenizer: AutoTokenizer,
              df: pd.DataFrame, doctor_similarity_df: pd.DataFrame, case_embeddings: np.ndarray,
              device: torch.device) -> Dict:
    model.eval()
    recommendations = {}
    with sqlite3.connect(Config.DB_PATH) as conn:
        cursor = conn.cursor()
        for patient in patient_data:
            start_time = time.time()
            name = patient["name"]
            symptoms = patient["symptoms"]
            logger.info(f"Processing patient: {name}, Symptoms: {symptoms}")
            print(f"\nProcessing patient: {name}, Symptoms: {symptoms}")

            normalized_text = preprocess_input(patient)
            try:
                patient_embedding = extract_semantic_features(normalized_text, model, tokenizer, device)
                similarities = cosine_similarity([patient_embedding], case_embeddings)[0]
                top_indices = np.argsort(similarities)[-Config.TOP_K:][::-1]
                top_similarities = similarities[top_indices]
                similar_cases = df.iloc[top_indices]
                logger.info("Retrieved similar cases.")
            except Exception as e:
                logger.error(f"Error during inference: {e}")
                with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                    f.write(f"Error during inference: {e}\n")
                continue

            # Remove duplicates in likely_conditions
            likely_conditions = []
            seen_conditions = set()
            for idx, sim_score in zip(top_indices, top_similarities):
                if sim_score >= Config.SIMILARITY_THRESHOLD:
                    row = df.iloc[idx]
                    condition = row["Processed_Disease"]
                    if condition not in seen_conditions:
                        seen_conditions.add(condition)
                        likely_conditions.append({
                            "Condition": condition,
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": float(sim_score)
                        })

            content_doctors = [cond["Doctor"] for cond in likely_conditions]
            # Remove duplicates in cf_conditions
            cf_conditions = []
            seen_cf_conditions = set()
            for doctor in content_doctors:
                if doctor in doctor_similarity_df.columns:
                    similar_doctors = doctor_similarity_df[doctor].sort_values(ascending=False).head(2).index
                    for sim_doc in similar_doctors:
                        if sim_doc != doctor:
                            sim_row = df[df["Name"] == sim_doc].head(1)
                            if not sim_row.empty:
                                sim_score = doctor_similarity_df.loc[sim_doc, doctor]
                                condition = sim_row["Processed_Disease"].iloc[0]
                                if condition not in seen_conditions and condition not in seen_cf_conditions:
                                    seen_cf_conditions.add(condition)
                                    cf_conditions.append({
                                        "Condition": condition,
                                        "Doctor": sim_row["Name"].iloc[0],
                                        "Treatment": sim_row["Processed_Treatment"].values[0],
                                        "Specialist": sim_row["Specialist"].values[0],
                                        "Rating": float(sim_row["Rating"].values[0]),
                                        "Address": sim_row["Address/Details"].values[0],
                                        "City": sim_row["City"].iloc[0],
                                        "Score": float(sim_score * 0.3)
                                    })

            if not likely_conditions:
                logger.warning(f"Cold start for {name}. Using default recommendations.")
                default_conditions = df.sample(Config.TOP_K)
                likely_conditions = []
                seen_conditions = set()
                for _, row in default_conditions.iterrows():
                    condition = row["Processed_Disease"]
                    if condition not in seen_conditions:
                        seen_conditions.add(condition)
                        likely_conditions.append({
                            "Condition": condition,
                            "Doctor": row["Name"],
                            "Treatment": row["Processed_Treatment"],
                            "Specialist": row["Specialist"],
                            "Rating": float(row["Rating"]),
                            "Address": row["Address/Details"],
                            "City": row["City"],
                            "Score": 0.5
                        })

            likely_condition_names = list(dict.fromkeys([cond["Condition"] for cond in likely_conditions]))
            other_condition_names = list(dict.fromkeys([cond["Condition"] for cond in cf_conditions]))
            specialists = defaultdict(set)
            for cond in likely_conditions:
                specialists[cond["Condition"]].add(cond["Specialist"])

            print("--- Likely Conditions Based on Your Symptoms ---")
            print(", ".join(likely_condition_names) if likely_condition_names else "None")
            print("\n--- Other Conditions You Might Consider ---")
            print(", ".join(other_condition_names) if other_condition_names else "None")
            print("\n--- Specialist Recommendations ---")
            printed_specialists = set()  # Track printed recommendations
            for symptom in set(symptoms.strip().split(",")):  # Use set to avoid duplicate symptoms
                symptom = symptom.strip()
                symptom_conditions = df[
                    df["Processed_Symptoms"].str.contains(symptom.lower(), case=False, na=False)
                ]["Processed_Disease"].tolist()
                for cond in set(symptom_conditions):  # Use set to avoid duplicate conditions
                    if cond in specialists:
                        for spec in specialists[cond]:
                            recommendation = f"For {symptom}, consulting a {spec} is recommended."
                            if recommendation not in printed_specialists:
                                print(recommendation)
                                printed_specialists.add(recommendation)

            print("\n--- Doctor and Treatment Recommendations for Likely Conditions ---")
            for cond in likely_conditions:
                print(f"Disease: {cond['Condition']}\nDoctor: {cond['Doctor']}\nSpecialist: {cond['Specialist']}\n"
                      f"Treatment: {cond['Treatment']}\nRating: {cond['Rating']}\nAddress: {cond['Address']}\nCity: {cond['City']}\n{'-' * 36}")

            print("\n--- Recommendations for Other Conditions ---")
            for cond in cf_conditions:
                print(f"Disease: {cond['Condition']}\nDoctor: {cond['Doctor']}\nSpecialist: {cond['Specialist']}\n"
                      f"Treatment: {cond['Treatment']}\nRating: {cond['Rating']}\nAddress: {cond['Address']}\nCity: {cond['City']}\n{'-' * 36}")

            cursor.execute("SELECT past_symptoms, ratings FROM users WHERE name=?", (name,))
            user_data = cursor.fetchone()
            if user_data:
                past_symptoms = json.loads(user_data[0])
                ratings = json.loads(user_data[1])
                past_symptoms.append(symptoms)
                for cond in likely_conditions + cf_conditions:
                    ratings[cond["Doctor"]] = ratings.get(cond["Doctor"], float(cond["Rating"]))
                cursor.execute(
                    "UPDATE users SET past_symptoms=?, ratings=? WHERE name=?",
                    (json.dumps(past_symptoms), json.dumps(ratings), name)
                )
                conn.commit()

            recommendations[name] = {
                "symptoms": symptoms,
                "likely_conditions": likely_conditions,
                "other_conditions": cf_conditions,
                "latency": float(time.time() - start_time)
            }

    logger.info("Inference completed successfully.")
    return recommendations

# Plot visualizations
def plot_visualizations(trainer: CustomTrainer, y_true: List, y_pred: List, y_scores: List,
                       df: pd.DataFrame, interaction_matrix: pd.DataFrame, case_embeddings: np.ndarray,
                       learning_rates: List[float]) -> Dict[str, str]:
    plots_dir = os.path.join(BASE_DIR, "plots")
    os.makedirs(plots_dir, exist_ok=True)

    def plot_to_base64() -> str:
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        buf.seek(0)
        return base64.b64encode(buf.read()).decode("utf-8")

    plots = {}
    log_history = trainer.state.log_history

    # Loss curve
    train_losses = [log["loss"] for log in log_history if "loss" in log]
    eval_losses = [log["eval_loss"] for log in log_history if "eval_loss" in log]
    if train_losses and eval_losses:
        plt.figure(figsize=(10, 6))
        plt.plot(train_losses, label="Training Loss")
        plt.plot(eval_losses, label="Validation Loss")
        plt.xlabel("Steps")
        plt.ylabel("Loss")
        plt.title("Training and Validation Loss Curves")
        plt.legend()
        plt.savefig(os.path.join(plots_dir, "loss_curve.png"), format="png", bbox_inches="tight")
        plots["loss_curve"] = plot_to_base64()
        plt.close()
        logger.info("Generated loss curve plot.")

    # Accuracy curve
    eval_accuracies = [log["eval_accuracy"] for log in log_history if "eval_accuracy" in log]
    eval_precisions = [log["eval_precision"] for log in log_history if "eval_precision" in log]
    eval_recalls = [log["eval_recall"] for log in log_history if "eval_recall" in log]
    if eval_accuracies:
        plt.figure(figsize=(10, 6))
        plt.plot(eval_accuracies, label="Accuracy")
        plt.plot(eval_precisions, label="Precision")
        plt.plot(eval_recalls, label="Recall")
        plt.xlabel("Epochs")
        plt.ylabel("Metric")
        plt.title("Training and Validation Accuracy Curves")
        plt.legend()
        plt.savefig(os.path.join(plots_dir, "accuracy_curve.png"), format="png", bbox_inches="tight")
        plots["accuracy_curve"] = plot_to_base64()
        plt.close()
        logger.info("Accuracy curve plot saved.")

    # Confusion matrix
    y_pred_classes = [p[0] if p else "Unknown" for p in y_pred]
    unique_classes = sorted(set(y_true + y_pred_classes))
    if len(unique_classes) > 1:
        cm = confusion_matrix(y_true, y_pred_classes, labels=unique_classes)
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=unique_classes, yticklabels=unique_classes)
        plt.title("Confusion Matrix")
        plt.xlabel("Predicted Label")
        plt.ylabel("True Label")
        plt.savefig(os.path.join(plots_dir, "confusion_matrix.png"), format="png", bbox_inches="tight")
        plots["confusion_matrix"] = plot_to_base64()
        plt.close()
        logger.info("Saved confusion matrix plot.")

    # t-SNE visualization
    if len(case_embeddings) > 0:
        try:
            tsne = TSNE(n_components=2, random_state=42, n_jobs=-1)
            embeddings_2d = tsne.fit_transform(case_embeddings[:500])  # Limit to 500 for memory
            plt.figure(figsize=(10, 6))
            plt.scatter(embeddings_2d[:, 0], embeddings_2d[:, 1], s=50, alpha=0.5)
            plt.title("t-SNE Visualization of Case Embeddings")
            plt.xlabel("Component 1")
            plt.ylabel("Component 2")
            plt.savefig(os.path.join(plots_dir, "tsne_plot.png"), format="png", bbox_inches="tight")
            plots["tsne"] = plot_to_base64()
            plt.close()
            logger.info("Generated t-SNE plot.")
        except Exception as e:
            logger.error(f"Error generating t-SNE: {e}")
            with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
                f.write(f"Error generating t-SNE: {e}\n")

    # Learning rate curve
    if len(learning_rates) > 0:
        plt.figure(figsize=(10, 6))
        plt.plot(learning_rates, label="Learning Rate")
        plt.xlabel("Steps")
        plt.ylabel("Learning Rate")
        plt.title("Learning Rate Over Training Steps")
        plt.legend()
        plt.yscale("log")
        plt.savefig(os.path.join(plots_dir, "learning_rate_curve.png"), format="png", bbox_inches="tight")
        plots["learning_rate"] = plot_to_base64()
        plt.close()
        logger.info("Generated learning rate curve plot.")

    # Save plots metadata
    try:
        with open(os.path.join(plots_dir, "visualizations.json"), "w") as f:
            json.dump(plots, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving visualizations metadata: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error saving visualizations metadata: {e}\n")
    logger.info(f"Saved charts in {plots_dir}")
    return plots

# Main function
def main():
    logger.info("Starting Medical Recommender System")
    try:
        init_environment()
        Config.init_toxicity_model()
        init_database()
        df, doctor_similarity_df, interaction_matrix = load_and_preprocess_data()
        tokenizer, model, device = load_tokenizer_and_model()

        learning_rates = []
        for epoch in range(Config.NUM_EPOCHS):
            lr = Config.LEARNING_RATE * (Config.LR_GAMMA ** (epoch // Config.LR_STEP_SIZE))
            learning_rates.extend([lr] * (len(df) // Config.TRAIN_BATCH_SIZE))

        trainer = fine_tune_model(model, tokenizer, df, Config.LEARNING_RATE, device)
        case_embeddings = generate_case_embeddings(df, model, tokenizer, device)

        patient_data = [
            {"name": "Iqra", "symptoms": "headache, flu, fever, full body pain", "history": "Previous flu episodes"},
            {"name": "Moafi", "symptoms": "loss appetite, queasiness", "history": "Recent travel"},
            {"name": "Sumair", "symptoms": "chest pain, shortness of breath", "history": "Hypertension"}
        ]

        recommendations = inference(
            patient_data, model, tokenizer, df, doctor_similarity_df, case_embeddings, device
        )
        metrics, y_true, y_pred, y_scores = compute_metrics(
            recommendations, df, case_embeddings, model, tokenizer, device
        )
        plot_visualizations(trainer, y_true, y_pred, y_scores, df, interaction_matrix, case_embeddings, learning_rates)

        print(f"\nEvaluation Metrics: {metrics}")
        logger.info("Medical Recommender System execution completed successfully")
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        with open(os.path.join(BASE_DIR, "error_log.txt"), "a") as f:
            f.write(f"Error in main execution: {e}\n")
        raise

if __name__ == "__main__":
    main()

